import json, logging
from .dbhelper import SqlPooled
from .adlshelper import AdlsHelper
adls_helper_ = AdlsHelper()

from .helper import Common
from .dsp_api_constants import *
db_connection = SqlPooled()
common_ = Common()
query_dict = {
    'case1': QUERYPAT_DSEP_NOID_NRESOURCE,
    # 'case2': QUERYPAT_DSEP_OID_NRESOURCE,
	'case2':QUERYPAT_DSEP_OID_RESOURCENID,
    'case3': QUERYPAT_NDSEP_NOID_NRESOURCE,
    'case4': QUERYPAT_NDSEP_OID_NRESOURCE,
    'case5i': QUERYPAT_DSEP_OID_RESOURCE, # one
    'case5': QUERYPAT_DSEP_OID_RESOURCENID , # two
    'case6i': QUERYPAT_NDSEP_NOID_RESOURCE, # three
    'case6': QUERYPAT_NDSEP_NOID_RESOURCENID,
    'case7i': QUERYPAT_NDSEP_OID_RESOURCE,
    'case7': QUERYPAT_NDSEP_OID_RESOURCENID,
    'case8i': QUERYPAT_DSEP_NOID_RESOURCE,
    'case8': QUERYPAT_DSEP_NOID_RESOURCENID,
	'query_legacy' : QUERYPAT_LEGACY
}

class PatientMysql:
    
	def resource_formatter(self, resource_string):
		resource_subs= RESOURCES_LIST.split(',')
		resource = resource_string.split('&')
		dicter={}
		try:
			for i in resource:
				logging.info(i)
				if '?id' in i:
					dicter[i.split('?id=')[0].lower()]=i.split('?id=')[1]
				else:
					dicter[i.lower()] = "None"
			dicter = {key:val for key, val in dicter.items() if val != '' and key !=''}

			if not set(dicter.keys()).issubset(set(resource_subs)):
				logging.info("Raising Resource Key Error")
				raise KeyError
			if 'patient' in dicter.keys():
				return dicter
			else:
				dicter['patient'] = "None"
				dicter = {"patient": "None"} | dicter
				return dicter
		except Exception as e:
			logging.error(e)

	def query_executor(self, data,db_connection,query,app_settings_dict,client_name):
		try: 
			db_connection._cursor.execute(query, None)
			fetch = db_connection._cursor.fetchall()
			if len(fetch)>0:
				for i in fetch:data.append(json.loads(i['resource_json']))
			return adls_helper_.run_format(data) if data  else  {"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}
		except Exception as e:
			logging.info(e)
			pass

	def query_constructor_body(self, resources_liz,query,query_dict,case_number,formatter_dict_body):
		try:
			for x in resources_liz.keys():
				formatter_dict_body.update({'rid' : resources_liz[x], 't_name' :  x, 'rtype' : str("'") + x + str("'")})
				if x == 'patient': formatter_dict_body.update({'part_by':'dsp_patient_id'})
				if x != 'patient': formatter_dict_body.update({'part_by':'dsp_resource_id'})
				if resources_liz[x] != "None":
					query = query + query_dict[case_number+"i"].format(**formatter_dict_body) if len(query)==0 else query +' UNION '+ query_dict[case_number+"i"].format(**formatter_dict_body)
				else:
					query = query + query_dict[case_number].format(**formatter_dict_body) if len(query)==0 else query + ' UNION ' + query_dict[case_number].format(**formatter_dict_body)

		except Exception as e:
			logging.info(e)
			
		
		return query

	def query_constructor_route(self, dsep_resource_type,dsep_resource_id,query,case_number,formatter_dict_route,rtype,t_name):
		try:
			if str(dsep_resource_type).lower() != 'patient': 
				query = query +  query_dict[case_number].format(**formatter_dict_route,rtype='patient',t_name='patient',part_by='dsp_patient_id')
			if dsep_resource_type is None:
				resource_list = str(RESOURCES_LIST).replace(",","&")
				resource_list = self.resource_formatter(resource_list)
				query = self.query_constructor_body(resource_list,query,query_dict,case_number,formatter_dict_route)
				logging.warn(query)
				return query
			if dsep_resource_id != None:
				query = query + query_dict[case_number+"i"].format(**formatter_dict_route,rtype=rtype,t_name=t_name,part_by='dsp_resource_id') if len(query)==0 else query + ' UNION ' + query_dict[case_number+"i"].format(**formatter_dict_route,rtype=rtype,t_name=t_name,part_by='dsp_resource_id') 
			else:
				query = query + query_dict[case_number].format(**formatter_dict_route,rtype=rtype,t_name=t_name,part_by='dsp_resource_id') if len(query)==0 else query + ' UNION ' + query_dict[case_number].format(**formatter_dict_route,rtype=rtype,t_name=t_name,part_by='dsp_resource_id') 
		
		except Exception as e:
			logging.info(e)
			pass
		return query

	def legacy_mapper(self, db_connection,query):
		db_connection._cursor.execute(query, None)
		logging.info(query)
		fetch = db_connection._cursor.fetchall()
		return fetch

	def request_executor(self, data,query,oid,dsep_patient_id,db_connection,dsep_resource_type,dsep_resource_id,dsp_id,s_oid,resource_string,app_settings_dict,client_name):
		try:
			formatter_dict_basic = {'dsp_id': dsp_id,'s_oid': s_oid}

			if resource_string is None:
				formatter_dict_route = {'dsp_id': dsp_id, 's_oid': s_oid,'rid' : str(dsep_resource_id)}
				rtype = str(dsep_resource_type)
				t_name =  dsep_resource_type
			elif resource_string or resource_string == '':
				formatter_dict_body = {'dsp_id': dsp_id,'s_oid': s_oid}
			
			if dsep_patient_id and not oid:
				logging.info("1")
				if dsep_resource_type:
					case_number = "case8"
					logging.info(case_number)
					query = self.query_constructor_route(dsep_resource_type,dsep_resource_id,query,case_number,formatter_dict_route,rtype,t_name)
					return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
				elif resource_string or resource_string == '':
					case_number = "case8"
					logging.info(case_number)
					resources_liz=self.resource_formatter(resource_string)
					query = self.query_constructor_body(resources_liz,query,query_dict,case_number,formatter_dict_body)
					return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
				elif not dsep_resource_type and not resource_string:
					case_number = "case1"
					logging.info(case_number)
					query =  query_dict[case_number].format(**formatter_dict_basic)
					return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
				
			elif dsep_patient_id and oid:

				if dsep_resource_type:
					case_number = "case5"
					logging.info(case_number)
					query = self.query_constructor_route(dsep_resource_type,dsep_resource_id,query,case_number,formatter_dict_route,rtype,t_name)
					logging.info(query)
					return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
 
				elif resource_string or resource_string == '':
					case_number = "case5"
					logging.info(case_number)
					resources_liz=self.resource_formatter(resource_string)
					query = self.query_constructor_body(resources_liz,query,query_dict,case_number,formatter_dict_body)
					return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
 
				elif not dsep_resource_type and not resource_string:
					case_number = "case2"
					logging.info(case_number)
					query = self.query_constructor_route(dsep_resource_type,dsep_resource_id,query,case_number,formatter_dict_route,rtype,t_name)
					logging.warning(query)
					return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
			
			elif not dsep_patient_id and not oid:
				logging.info("3")

				if dsep_resource_type:
					case_number = "case6"
					logging.info(case_number)
					query = self.query_constructor_route(dsep_resource_type,dsep_resource_id,query,case_number,formatter_dict_route,rtype,t_name)
					return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
				elif resource_string or resource_string == '':
					case_number = "case6"
					logging.info(case_number)
					resources_liz=self.resource_formatter(resource_string)
					query =self.query_constructor_body(resources_liz,query,query_dict,case_number,formatter_dict_body)
					return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
				elif not dsep_resource_type and not resource_string:
					case_number = "case3"
					logging.info(case_number)
					query =  query_dict[case_number].format(**formatter_dict_basic)
					return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
			
			elif not dsep_patient_id and oid:
				logging.info("4")

				if dsep_resource_type:
					case_number = "case7"
					logging.info(case_number)
					query = self.query_constructor_route(dsep_resource_type,dsep_resource_id,query,case_number,formatter_dict_route,rtype,t_name)
					return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
 
				elif resource_string or resource_string == '':
					case_number = "case7"
					logging.info(case_number)
					resources_liz=self.resource_formatter(resource_string)
					query = self.query_constructor_body(resources_liz,query,query_dict,case_number,formatter_dict_body)
					return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
 
				elif not dsep_resource_type and not resource_string:
					case_number = "case4"
					logging.info(case_number)
					query =  query_dict[case_number].format(**formatter_dict_basic)
					return self.query_executor(data,db_connection,query,app_settings_dict,client_name)

		except Exception as e:
			logging.info(f"Error : {str(e)}")
			return {"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}

	def patient_fetcher(self, resource_string,oid,dsep_patient_id,db_connection,dsep_resource_type,dsep_resource_id,app_settings_dict,client_name):
		try:
			data=[]
			query=''
			dsp_id = str(dsep_patient_id) 
			s_oid = str(oid)
			if dsep_patient_id:
				try:
					query_type = common_.is_valid_uuid(dsep_patient_id)
					if not query_type:
						logging.info("Legacy_id_db")
						legacy_map = self.legacy_mapper(db_connection,query_dict['query_legacy'].format(dsp_id = dsp_id,s_oid=s_oid))
						if len(legacy_map)==1:
							dsep_patient_id = legacy_map[0]['dsp_patient_id']
							dsp_id = dsep_patient_id 
						else: return {"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}
				except: return {"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}
			try:return self.request_executor(data,query,oid,dsep_patient_id,db_connection,dsep_resource_type,dsep_resource_id,dsp_id,s_oid,resource_string,app_settings_dict,client_name)
			except:return {"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}
		finally:db_connection._connection.close()
