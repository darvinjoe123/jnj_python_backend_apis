import json, logging
import azure.functions as func
from .dbhelper import SqlPooled, AppSettings
from .adlshelper import AdlsHelper
from .helper import Common
from .legacy import Legacy
from .patient_mysql import PatientMysql
from .non_fhir_mysql import NonFhirMysql
from .master_mysql import NonPatientMysql
from .dsp_api_constants import RESOURCES_LIST, MASTER_RESOURCES_LIST
# Using the class in a function
db_connection_ = SqlPooled()
app_setting_ = AppSettings()
adls_helper_ = AdlsHelper()
non_patient_sql_ = NonPatientMysql()
legacy_ = Legacy()
common_ = Common()
non_fhir_mysql_ = NonFhirMysql()
patient_mysql_ = PatientMysql()

def main (req: func.HttpRequest )-> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    url_address = str(req.url)
    d4c= True
    
    if 'adls' in (url_address.lower()).split('/'): d4c = False
    resource_subs= RESOURCES_LIST.split(',')
    resource_string = None

    oid = common_.jwt_decoder(req)
    
    if oid is None:
        try:
            req_json = req.get_body()
            logging.info(req_json)
            oid= common_.oid_req_json(req_json)
        except:
            pass
    if oid == None or oid == "":
            return func.HttpResponse(json.dumps({"error": "system oid needed"}), status_code=400, mimetype="application/json")
        
    app_settings_dict,client_name = app_setting_.getappset_with_oid(oid)

    try:
        resource_type = str(req.route_params.get("resource_type")).lower()
    except:
        resource_type = None

    if resource_type == "nonfhir" and d4c:
        try:
            t_name = resource_type
            non_fhir_type = req.route_params.get('dsep_resource_id')
            non_fhir_patient_id = req.route_params.get('resource_fetch')
            nfhir_outer = non_fhir_mysql_.non_fhir_fetcher(t_name,non_fhir_type,non_fhir_patient_id,oid,db_connection_,app_settings_dict,client_name)
            return func.HttpResponse(json.dumps(nfhir_outer),status_code=200,mimetype="application/json") if "error" not in nfhir_outer.keys() else func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}),
                                    status_code=400,mimetype="application/json")
        except Exception as e:
            logging.info(e)
            return func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}),
                                 status_code=400,mimetype="application/json")
                                 
    elif resource_type == "nonfhir" and not d4c:
         return func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}),
                                 status_code=400,mimetype="application/json")
                                 
    if resource_type and resource_type in MASTER_RESOURCES_LIST and d4c:
        try: 
            t_name = resource_type
            logging.warning("1")
            resource_id = req.route_params.get('resource_fetch')
            non_patient_outer = non_patient_sql_.non_patient_fetcher(t_name,resource_id,db_connection_,app_settings_dict,client_name)
            return func.HttpResponse(json.dumps(non_patient_outer),status_code=200,mimetype="application/json") if "error" not in non_patient_outer.keys() else func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}),
                                    status_code=400,mimetype="application/json")
        except Exception as e:
            logging.info(e)
            return func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}),
                                 status_code=400,mimetype="application/json")
    elif resource_type in ["location"] and not d4c:
        return func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}),
                                 status_code=400,mimetype="application/json")
    
    try:
        dsep_patient_id,dsep_resource_type,dsep_resource_id = adls_helper_.dsep_search(req)
        if dsep_resource_type != None and str(dsep_resource_type).lower() not in resource_subs:
            return func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_INPUT_PATIENT']}),
                                    status_code=400,mimetype="application/json")
    except:
        return func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_EMPTY_RESOURCE_ERROR']}),
                                    status_code=400,mimetype="application/json")
    
    try:
        if dsep_resource_type is None:
            try:
                req_json = req.get_body()
                resource_string=json.loads(req_json)['entry'][0]['request']['resource']
            except Exception as e:
                logging.warn(e)
        elif dsep_resource_type != None and str(dsep_resource_type).lower() not in resource_subs:
             return func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_INPUT_PATIENT']}),
                                    status_code=400,mimetype="application/json")
    except:
        pass
    
    if d4c:
        try:
            logging.info("d4c exists")
            outer = patient_mysql_.patient_fetcher(resource_string,oid,dsep_patient_id,db_connection_,dsep_resource_type,dsep_resource_id,app_settings_dict,client_name)

            if "error" not in outer.keys():
                return func.HttpResponse(json.dumps(outer,sort_keys=False),status_code=200,mimetype="application/json")
            if "error" in outer.keys(): 
                with_id_dict,without_id = common_.function_patient_seg_resource_and_ids(dsep_resource_type,dsep_resource_id,dsep_patient_id)
                output,patient_exists_legacy = legacy_.Legacy_fetch(with_id_dict,without_id,dsep_patient_id,app_settings_dict,client_name)
                return func.HttpResponse(json.dumps(output,sort_keys=False),status_code=200,mimetype="application/json") if patient_exists_legacy else func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_INPUT_PATIENT']}),status_code=400,mimetype="application/json")
        except:
             return func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_INPUT_PATIENT']}),status_code=400,mimetype="application/json")
            
    try:
        output,with_id_dict,without_id,patient_exists_adls=adls_helper_.adls_data_fetch(resource_string,oid,dsep_patient_id,dsep_resource_type,dsep_resource_id,app_settings_dict,client_name)
        
        if output != False:
            return func.HttpResponse(json.dumps(output),status_code=200,
                                    mimetype="application/json")

        logging.warning("proceeding to legacy" )
        if dsep_patient_id :
            logging.warning("1")
            logging.info("with_id is %s and without_id is %r",with_id_dict,without_id)
            output,patient_exists_legacy = legacy_.Legacy_fetch(with_id_dict,without_id,dsep_patient_id,app_settings_dict,client_name)
            if patient_exists_adls == False:
                if patient_exists_legacy :
                    return    func.HttpResponse(json.dumps(output),status_code=200,
                                            mimetype="application/json")
                else:
                    logging.warning("patient_exists_legacy does not exist")
                    if oid:
                        if len(adls_helper_.fetch_adls_blobs_names(f"v1/{oid}",app_settings_dict,client_name)) == 0:
                            return func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_INPUT_JSON']}),
                                 status_code=400,mimetype="application/json")
                    return func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_INPUT_PATIENT']}),
                                        status_code=400,mimetype="application/json")
        else:
            if oid:
                if len(adls_helper_.fetch_adls_blobs_names(f"v1/{oid}",app_settings_dict,client_name)) == 0:
                    return func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_INPUT_JSON']}),
                                 status_code=400,mimetype="application/json")
            output=[]
            return func.HttpResponse(json.dumps(adls_helper_.run_format(output)),status_code=200,
                                    mimetype="application/json")
    except:
        return func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_INPUT_JSON']}),
                                 status_code=400,mimetype="application/json")