import json
import os,re
import logging
import azure.functions as func
from azure.storage.blob import BlobServiceClient
from .dsp_api_constants import RESOURCES_LIST




def create_blob_client(connection_string):
    blob_service_client =  BlobServiceClient.from_connection_string(
        connection_string)
    return blob_service_client


def oid_req_json(req_json):
    try:
        oid = json.loads(req_json)["oid"]
    except:
        oid=None
    return oid

def dsep_patient_id_search(req):
    try:
        dsep_patient_id=req.route_params.get("dsep_resource_id")
        resource_type=req.route_params.get("resource")
        resource_id=req.route_params.get("resource_id")
        return dsep_patient_id,resource_type,resource_id
    except:
        dsep_patient_id=None
    logging.info(dsep_patient_id)
    return dsep_patient_id

def list_blobs_criteria(oid,dsep_patient_id):
    try:
        if dsep_patient_id:
            if oid:
                logging.warning("oid and pid")
                criteria=f"v1/{oid}/{dsep_patient_id}"
            else:
                logging.warning("only pid")
                criteria=f"v1/"
        else:
            if oid:
                logging.warning("only oid")
                criteria=f"v1/{oid}/"
            else:
                logging.warning("only everything")
                criteria=f"v1/"
    except:
        return logging.error("Connection_not established with container")

    logging.info("logs for list_blobs_based_on_oid %s",criteria)
    return criteria

def fetch_adls_blobs_names(criteria,app_settings_dict,client_name):
    # container_adls_connection_strn=app_settings_dict[f'{client_name}_VELYS_CONNECTION_STRING']
    container_adls_connection_strn=os.environ['VELYS_CONNECTION_STRING']
    container_adls=app_settings_dict[f"{client_name}_DSEP_CONTAINER"]
    service_client =  BlobServiceClient.from_connection_string(container_adls_connection_strn)
    container_client = service_client.get_container_client(container=container_adls)
    files_blobs=container_client.list_blobs(criteria)
    blob_names = []
    for blob in files_blobs:
        blob_names.append(blob.name)
    return blob_names

def function_toseggregate_with_ids_without_ids(resource_string):
    resource_subs= RESOURCES_LIST.split(',')
    resource_subs.append('')
    resource_type = set(resource_string.rsplit("&"))
    resource_type= list(filter(lambda k: "patient" not in k.lower(),resource_type))
    without_id=[]
    with_id_dict={}
    for resource in resource_type:
        res= resource if (resource in '?id=') else resource.split('?id=')[0]
        if res.lower() not in resource_subs:
            raise KeyError
        if '?id=' in resource:
            with_id_dict.update({resource.split('?id=')[0].lower():resource.split('?id=')[1]})
        else :
            without_id.append(resource.lower())
    return with_id_dict,without_id

def check_bools_based_request(resource_string,resource_type,resource_id,dsep_patient_id):
    logging.warning("check_bools_based_request(resource_string)")
    isidfilters = False
    isfilterwithoutid = False
    with_id_dict=[]
    without_id=['']
    logging.info("before function_toseggregate_with_ids_without_ids")
    if resource_string:
        with_id_dict,without_id=function_toseggregate_with_ids_without_ids(resource_string)
    elif resource_type== None and resource_id== None:
        return isidfilters,isfilterwithoutid,with_id_dict,without_id
    elif resource_string == None:
        with_id_dict,without_id=function_patient_seg_resource_and_ids(resource_type,resource_id,dsep_patient_id)
    logging.info("lenght of with_id %s",len(with_id_dict))
    if len(with_id_dict) !=0:
        isidfilters = True
    if len(without_id) !=0  :
        isfilterwithoutid = True

    logging.info("isidfilters %s",isidfilters)
    logging.info("isfilterwithoutid %s",isfilterwithoutid)
    logging.info("with_id %s",with_id_dict)
    logging.info("without_id %s",without_id)
    return isidfilters,isfilterwithoutid,with_id_dict,without_id


def blob_iterate(resource_string,criteria,oid,dsep_patient_id,resource_type,resource_id,app_settings_dict,client_name):
    patient_adls_exists = True
    # with_id_id_absent=False
    main=[]
    list_of_blobs=fetch_adls_blobs_names(criteria,app_settings_dict,client_name)
    logging.warning("before check_bools_based_request ")
    isidfilters,isfilterwithoutid,with_id_dict,without_id=check_bools_based_request(resource_string,resource_type,resource_id,dsep_patient_id)
    logging.warning("after check_bools_based_request ")
    if dsep_patient_id:
        if oid:
            logging.info("oid : %s",oid)
            blob_name_search=f"v1/{oid}/{dsep_patient_id}/patient/patient_{dsep_patient_id}_"
            blobs = list(filter(lambda k: blob_name_search in k, list_of_blobs))
            if len(blobs)== 0:
                patient_adls_exists = False
            main.extend(blobs)
        else:
            logging.info("oid not present")
            blob_name_search=f"/patient/patient_{dsep_patient_id}_"
            blobs = list(filter(lambda k: blob_name_search in k, list_of_blobs))
            if len(blobs) == 0:
                patient_adls_exists = False
            for blob_ in blobs:
                main.append(blob_)
    else:
        logging.info("oid not present")
        blob_name_search=f"/patient/patient_"
        blobs = list(filter(lambda k: blob_name_search in k, list_of_blobs))
        patient_adls_exists = True
        for blob_ in blobs:
            main.append(blob_)

    if isidfilters :
        logging.info("isidfilters initiate %s",with_id_dict)
        for ids , vals in with_id_dict.items():
            if dsep_patient_id:
                blob_name_search=f"{dsep_patient_id}/{ids}/{ids}_{vals}.json"
            else :
                blob_name_search=f"/{ids}/{ids}_{vals}.json"
            blobs=list(filter(lambda k: blob_name_search in k , list_of_blobs))
            logging.warning("len(with_id_dict) %s",len(with_id_dict))
            main.extend(blobs)

    if isfilterwithoutid :
        logging.info("without_id : %s",without_id)
        if dsep_patient_id:
            if oid:
                logging.warning("if oid and dsep_patient_id:")
                for ids in  without_id:
                    blob_name_search=f"{oid}/{dsep_patient_id}/{ids}/"
                    logging.info("blob_name_search %s",blob_name_search)
                    blobs=list(filter(lambda k: blob_name_search in k, list_of_blobs))
                    main.extend(blobs)
            else:
                logging.warning("if not oid and dsep_patient_id:")
                for ids in  without_id:
                    blob_name_search=f"{dsep_patient_id}/{ids}/"
                    logging.info("blob_name_search %s",blob_name_search)
                    blobs=list(filter(lambda k: blob_name_search in k, list_of_blobs))
                    main.extend(blobs)

        else:
            logging.warning("if not oid and not dsep_patient_id:")
            for ids in  without_id:
                blob_name_search=f"/{ids}/"
                logging.info("blob_name_search %s",blob_name_search)
                blobs=list(filter(lambda k: blob_name_search in k, list_of_blobs))
                main.extend(blobs)

    return main,with_id_dict,without_id,patient_adls_exists

def get_blob_json(container_client, blob_name):
    try:
        blob_client = container_client.get_blob_client(blob=blob_name)
    except:
        logging.error("container_client failed")
    try:
        raw_data = blob_client.download_blob().readall()
    except:
        logging.error("blob_client download failed")
        return None


    return json.loads(raw_data)

def run_format(data_bundles):
    output={
            "resourceType": "Bundle",
            "type": "transaction-response",
            "entry": data_bundles
            }
    return output

def ADls_data(main,app_settings_dict,client_name):
    container_adls_connection_strn=os.environ['VELYS_CONNECTION_STRING']
    container_adls=app_settings_dict[f'{client_name}_DSEP_CONTAINER']

    container_client_strn= create_blob_client(container_adls_connection_strn)
    container_client= container_client_strn.get_container_client(container_adls)
    logging.warning("ADls_data(main)")
    data=[]
    for blobs_ in main:
        data.append(get_blob_json(container_client, blobs_))
    logging.warning("after (main) append")
    logging.warning("len(data) %s",len(data))
    if len(data) == 0 :
        logging.info("return false")
        return False
    return run_format(data)


def adls_data_fetch(resource_string,oid,dsep_patient_id,resource_type,resource_id,app_settings_dict,client_name):
    logging.warning("adls_data_fetch(resource_string,oid,dsep_patient_id)")
    criteria=list_blobs_criteria(oid,dsep_patient_id)
    blobs,with_id_dict,without_id,patient_exists=blob_iterate(resource_string,criteria,oid,dsep_patient_id,resource_type,resource_id,app_settings_dict,client_name)
    return ADls_data(blobs,app_settings_dict,client_name),with_id_dict,without_id,patient_exists


def function_patient_seg_resource_and_ids(resource_type,resource_id,dsep_patient_id):
    resource_subs= RESOURCES_LIST.split(',')
    without_id=[]
    with_id_dict={}
    if resource_type != None and str(resource_type).lower() not in resource_subs:
        raise KeyError
    if resource_type != None and resource_id == None and str(resource_type).lower() != 'patient':
        without_id.append(resource_type)
    elif resource_type != None and resource_id !=None and str(resource_type).lower() != 'patient':
        with_id_dict.update({str(resource_type).lower():resource_id})
    # else:
    #     with_id_dict.update({"patient":dsep_patient_id})
    return with_id_dict,without_id


# Scenario 1
# list_blob(<>)  return <list_of_blobs>
# isidfilters = False
# isfilterwithoutid = False
# iterate the blob (eliminating master, practitioner, ..)
#    raw_data(blob_name) return <raw json of the resources>
#    append all _ data return resource bundle


# Scenario 2
# list_blob(<v1/<oid>)  return <list_of_blobs> - oid, all resource
# isidfilters = False
# isfilterwithoutid = False
# iterate the blob (eliminating master, practitioner, ..)  filter based on resources
#    raw_data(blob_name) return <raw json of the resources>
#    append all _ data return resource bundle

# Scenario 3
# list_blob(<v1/<oid>/<dsep_patient>)  return <list_of_blobs> - oid, all resource
# isidfilters = False
# isfilterwithoutid = False
# iterate the blob (eliminating master, practitioner, ..)  filter based on resources
#    raw_data(blob_name) return <raw json of the resources>
#    append all _ data return resource bundle

