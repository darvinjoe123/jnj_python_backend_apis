import uuid,requests,logging,json,jwt
from .all_resources_map import _resource_lists_
from .dsp_api_constants import RESOURCES_LIST


eval_sjj= _resource_lists_()

class Common:
    def is_valid_uuid(self, val):
        try:
            uuid.UUID(str(val))
            return True
        except ValueError:
            return False
        
    def get(self, url, headers, payload):
        return requests.request("GET", url, headers=headers, data=payload)

    def generate_jwt(self, url, headers, payload):
        logging.info("async def generate_jwt(url, headers, payload):")
        response = self.get(url, headers, payload)
        return response.headers['jwt-token']

    def get_fhir_resources(self, url, headers, url_params):

        logging.info("get_fhir_resources(url, headers, url_params)")
        # async with aiohttp.ClientSession() as session:
        payload = json.dumps({
        "resourceType": "Bundle",
        "id": "bundle-transaction",
        "type": "transaction",
        "entry": [
            {
            "request": {
                "method": "GET",
                "url": url_params
            }
            }
        ]
        })
        result = {}
        try:
            result=[]
            logging.info("before response get_fhir_resources ")
            response =  requests.request("POST", url, headers=headers, data=payload)
            result = response.json()["entry"][0]["resource"]
            logging.info("before response get_fhir_resources getting result")
        except:
            pass
            logging.error("FHIR legacy get failed for get_fhir_resources")
        return  result

    def fhir_url_gen_withoutid(self, resource,val,pid):
        # async with aiohttp.ClientSession() as session:
        logging.info(" initiated fhir_url_gen_withoutid(resource,val,pid)")
        for i in range(len(eval_sjj)):
            if eval_sjj[i].lower()== resource.lower():
                resource_eval = eval_sjj[i]
                break
        relation_dict = {"observation":"subject",
                        "condition":"subject",
                        "procedure":"subject",
                        "appointment":"actor",
                        "coverage":"beneficiary",
                        "medicationadministration":"subject",
                        "medicationrequest":"subject",
                        "diagnosticreport":"subject",
                        "encounter":"subject",
                        "allergyintolerance":"patient"}
        relation=relation_dict[str(resource.lower())]
        if val== None:
            url_wouldbe = f'{resource_eval}?{relation}=Patient/{pid}'
        else:
            url_wouldbe = f'{resource_eval}?{relation}=Patient/{pid}&_id={val}'

        logging.warning("url_wouldbe %s",url_wouldbe)

        return url_wouldbe

    def url_params_generator(self, with_id,without_id,dsep_patient_id,url_getfhir, headers_getfhir):
        logging.warning("url_params_generator(with_id,without_id,dsep_patient_id,url_getfhir, headers_getfhir)")
        url_list=[]

        ### URL WITH WITHOUT
        url_list_with=[]
        logging.info("len(with_id) %s",len(with_id))
        if len(with_id) > 0:
            for resource,val in with_id.items():
                url_list_with.append(self.fhir_url_gen_withoutid(resource,val,dsep_patient_id))
            for url in url_list_with:
                data = self.get_fhir_resources(url_getfhir, headers_getfhir, url)
                url_list.append(data['entry'][0]["resource"])


        url_list_without=[]
        if without_id !=[''] and len(without_id)>0:
            val=None
            for resource in without_id:
                url_list_without.append(self.fhir_url_gen_withoutid(resource,val,dsep_patient_id))
            for url in url_list_without:
                logging.info("before getting data")
                data=self.get_fhir_resources(url_getfhir, headers_getfhir, url)
                logging.info("after getting data")
                for entry_ in data['entry']:
                    url_list.append(entry_['resource'])
        return url_list

    def oid_req_json(self, req_json):
        try:
            oid = json.loads(req_json)["oid"]
        except:
            oid=None
        return oid

    def dsep_patient_id_search(self, req):
        try:
            dsep_patient_id=req.route_params.get("dsep_resource_id")
            resource_type=req.route_params.get("resource")
            resource_id=req.route_params.get("resource_id")
            return dsep_patient_id,resource_type,resource_id
        except:
            dsep_patient_id=None
        logging.info(dsep_patient_id)
        return dsep_patient_id

    
    def function_toseggregate_with_ids_without_ids(self, resource_string):
        resource_subs= RESOURCES_LIST.split(',')
        resource_subs.append('')
        resource_type = set(resource_string.rsplit("&"))
        resource_type= list(filter(lambda k: "patient" not in k.lower(),resource_type))
        without_id=[]
        with_id_dict={}
        for resource in resource_type:
            res= resource if (resource in '?id=') else resource.split('?id=')[0]
            if res.lower() not in resource_subs:
                raise KeyError
            if '?id=' in resource:
                with_id_dict.update({resource.split('?id=')[0].lower():resource.split('?id=')[1]})
            else :
                without_id.append(resource.lower())
        return with_id_dict,without_id

    def check_bools_based_request(self, resource_string,resource_type,resource_id,dsep_patient_id):
        logging.warning("check_bools_based_request(resource_string)")
        isidfilters = False
        isfilterwithoutid = False
        with_id_dict=[]
        without_id=['']
        logging.info("before function_toseggregate_with_ids_without_ids")
        if resource_string:
            with_id_dict,without_id=self.function_toseggregate_with_ids_without_ids(resource_string)
        elif resource_type== None and resource_id== None:
            return isidfilters,isfilterwithoutid,with_id_dict,without_id
        elif resource_string == None:
            with_id_dict,without_id=self.function_patient_seg_resource_and_ids(resource_type,resource_id,dsep_patient_id)
        logging.info("lenght of with_id %s",len(with_id_dict))
        if len(with_id_dict) !=0:
            isidfilters = True
        if len(without_id) !=0  :
            isfilterwithoutid = True

        logging.info("isidfilters %s",isidfilters)
        logging.info("isfilterwithoutid %s",isfilterwithoutid)
        logging.info("with_id %s",with_id_dict)
        logging.info("without_id %s",without_id)
        return isidfilters,isfilterwithoutid,with_id_dict,without_id


    def function_patient_seg_resource_and_ids(self, resource_type,resource_id,dsep_patient_id):
        resource_subs= RESOURCES_LIST.split(',')
        without_id=[]
        with_id_dict={}
        if resource_type != None and str(resource_type).lower() not in resource_subs:
            raise KeyError
        if resource_type != None and resource_id == None and str(resource_type).lower() != 'patient':
            without_id.append(resource_type)
        elif resource_type != None and resource_id !=None and str(resource_type).lower() != 'patient':
            with_id_dict.update({str(resource_type).lower():resource_id})
        # else:
        #     with_id_dict.update({"patient":dsep_patient_id})
        return with_id_dict,without_id
    
    def jwt_decoder(self, req):
        try:
            token= req.headers['Authorization'].lstrip('Bearer').strip()
            token_decode = jwt.decode(token, options={"verify_signature": False})
            oid = token_decode["oid"]
        except:
            oid = None
        return oid 
