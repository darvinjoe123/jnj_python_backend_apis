import os,logging
from .all_resources_map import _resource_lists_
from .helper import Common
from .adlshelper import AdlsHelper
adls_helper_ = AdlsHelper()

eval_sjj= _resource_lists_()
common_ = Common()
class Legacy:
    # function to return jwt-token from Apigee url
    def Legacy_fetch(self, with_id,without_id,dsep_patient_id,app_settings_dict,client_name):
        url_jwt= app_settings_dict[f"{client_name}_GENERATE_JWT_URL"]
        payload_jwt={}
        headers_jwt = {
                'client_id':app_settings_dict[f'{client_name}_CLIENT_ID'],
                'client_secret': app_settings_dict[f'{client_name}_CLIENT_SECRET']
                }
        logging.warning("Legacy_fetch - with_id,without_id,dsep_patient_id")
        jwt_token = common_.generate_jwt(url_jwt, headers_jwt, payload_jwt)
        url_getfhir = app_settings_dict[f"{client_name}_LEGACY_API_URL"]
        headers_getfhir = {
            'PurposeOfUse': app_settings_dict[f"{client_name}_PURPOSE_OF_USE"],
            'UserID': app_settings_dict[f"{client_name}_USER_ID"],
            'Source': app_settings_dict[f"{client_name}_SOURCE"],
            'Product': app_settings_dict[f"{client_name}_PRODUCT"],
            'Application': app_settings_dict[f"{client_name}_APPLICATION"],
            'Content-Type': app_settings_dict[f"{client_name}_CONTENT_TYPE"],
            'Authorization': 'Bearer ' +  jwt_token
            }
        data_files=[]
        patient_exists = True
        pid_url= f"Patient?_id={dsep_patient_id}"
        data=common_.get_fhir_resources(url_getfhir, headers_getfhir, pid_url)
        try:
            for entry_ in data['entry']:
                data_files.append(entry_['resource'])
        except:
            logging.warning("patient_exception")
            patient_exists=False

        if patient_exists:
            # data.append(get_fhir_resources(url_getfhir, headers_getfhir, url_params=pid_url))
            urls=common_.url_params_generator(with_id,without_id,dsep_patient_id,url_getfhir, headers_getfhir)
            data_files.extend(urls)
            # for task in urls:
            #     data.append(get_fhir_resources(url_getfhir, headers_getfhir, task))

        return adls_helper_.run_format(data_files),patient_exists
