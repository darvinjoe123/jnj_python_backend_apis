import logging, json 
from .helper import Common
from .dsp_api_constants import *
from .adlshelper import AdlsHelper

adls_helper_ = AdlsHelper()
non_patient_query_dict = {
	'case1': QUERY_MASTER_RESOURCES_NID,
	'case2': QUERY_MASTER_RESOURCES_ID,

}
# adls_helper = AdlsHelper()
common_ = Common()
class NonPatientMysql:
    
	def query_executor(self, data,db_connection,query,app_settings_dict,client_name):
		try: 
			logging.info(query)
			db_connection._cursor.execute(query, None)
			fetch = db_connection._cursor.fetchall()
			if len(fetch)>0:
				for i in fetch:
					try:
						data.append(json.loads(i['resource_json']))
					except Exception as e:
						print(e)
						pass
			return adls_helper_.run_format(data) if data  else  {"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}
		except Exception as e:
			logging.info(e)
			pass

	def non_patient_fetcher(self,t_name,resource_id,db_connection,app_settings_dict,client_name):
		try:
			data = []
			if not resource_id:
				case_number = "case1"
				logging.info(case_number)
				query =  non_patient_query_dict[case_number].format(resource_type=t_name)
				logging.warning(query)
				return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
			elif resource_id:
				case_number = "case2"
				logging.info(case_number)
				query =  non_patient_query_dict[case_number].format(rid=resource_id,resource_type=t_name)
				logging.warning(query)
				return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
		except Exception as e:
			logging.info(e)
			return {"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}
		finally:db_connection._connection.close()
