import logging, json
from .dsp_api_constants import * 
from .adlshelper import AdlsHelper
adls_helper_ = AdlsHelper()
nfhir_query_dict = {
	'case1': QUERY_NOID_NNFHIRTYPE_NID,
	'case2': QUERY_NOID_NNFHIRTYPE_ID,
	'case3': QUERY_NOID_NFHIRTYPE_NID,
	'case4': QUERY_NOID_NFHIRTYPE_ID, 
	'case5': QUERY_OID_NNFHIRTYPE_NID , 
	'case6': QUERY_OID_NNFHIRTYPE_ID,
	'case7': QUERY_OID_NFHIRTYPE_NID,
	'case8': QUERY_OID_NFHIRTYPE_ID
}

class NonFhirMysql:
    
	def query_executor(self, data,db_connection,query,app_settings_dict,client_name):
		try: 
			logging.info(query)
			db_connection._cursor.execute(query, None)
			fetch = db_connection._cursor.fetchall()
			if len(fetch)>0:
				for i in fetch:data.append(json.loads(i['resource_json']))
			return adls_helper_.run_format(data) if data  else  {"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}
		except Exception as e:
			logging.info(e)
			pass

	def non_fhir_fetcher(self, t_name,non_fhir_type,non_fhir_patient_id,oid,db_connection,app_settings_dict,client_name):
		try:
			data = []
			formatter_dict_basic = {'r_type': str(non_fhir_type),'s_oid': str(oid), 'r_id': str(non_fhir_patient_id)}
			if not oid and not non_fhir_type and not non_fhir_patient_id:
				case_number = "case1"
				logging.info(case_number)
				query =  nfhir_query_dict[case_number]
				return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
			elif not oid and not non_fhir_type and non_fhir_patient_id:
				case_number = "case2"
				logging.info(case_number)
				query =  nfhir_query_dict[case_number].format(**formatter_dict_basic)
				return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
			elif not oid and non_fhir_type and not non_fhir_patient_id:
				case_number = "case3"
				logging.info(case_number)
				query =  nfhir_query_dict[case_number].format(**formatter_dict_basic)
				return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
			elif not oid and non_fhir_type and non_fhir_patient_id:
				case_number = "case4"
				logging.info(case_number)
				query =  nfhir_query_dict[case_number].format(**formatter_dict_basic)
				return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
			elif oid and not non_fhir_type and not non_fhir_patient_id:
				case_number = "case5"
				logging.info(case_number)
				query =  nfhir_query_dict[case_number].format(**formatter_dict_basic)
				return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
			elif oid and not non_fhir_type and non_fhir_patient_id:
				case_number = "case6"
				logging.info(case_number)
				query =  nfhir_query_dict[case_number].format(**formatter_dict_basic)
				return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
			elif oid and non_fhir_type and not non_fhir_patient_id:
				case_number = "case7"
				logging.info(case_number)
				query =  nfhir_query_dict[case_number].format(**formatter_dict_basic)
				return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
			elif oid and non_fhir_type and non_fhir_patient_id:
				case_number = 'case8'
				logging.info(case_number)
				query =  nfhir_query_dict[case_number].format(**formatter_dict_basic)
				return self.query_executor(data,db_connection,query,app_settings_dict,client_name)
		except Exception as e:
			logging.info(e)
			return {"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}
		finally: db_connection._connection.close()
