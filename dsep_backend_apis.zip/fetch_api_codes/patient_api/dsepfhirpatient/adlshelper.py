import json, logging,os
from azure.storage.blob import BlobServiceClient
from .dsp_api_constants import RESOURCES_LIST
from .helper import Common
from azure.identity import ManagedIdentityCredential
from azure.keyvault.secrets import SecretClient
from azure.storage.blob import BlobServiceClient
common_ = Common()
class AdlsHelper:
    
    def create_blob_client(self, connection_string):
        blob_service_client =  BlobServiceClient.from_connection_string(
            connection_string)
        return blob_service_client

    def fetch_adls_blobs_names(self, criteria,app_settings_dict,client_name):
        container_adls=app_settings_dict[f"{client_name}_DSEP_CONTAINER"]
        container_adls_connection_strn=app_settings_dict[f'{client_name}_VELYS_CONNECTION_STRING']
        service_client =  BlobServiceClient.from_connection_string(container_adls_connection_strn)
        container_client = service_client.get_container_client(container=container_adls)
        files_blobs=container_client.list_blobs(criteria)
        blob_names = []
        for blob in files_blobs:
            blob_names.append(blob.name)
        return blob_names


    def get_blob_json(self, container_client, blob_name):
        try:
            blob_client = container_client.get_blob_client(blob=blob_name)
        except:
            logging.error("container_client failed")
        try:
            raw_data = blob_client.download_blob().readall()
        except:
            logging.error("blob_client download failed")
            return None
        return json.loads(raw_data)

    def dsep_search(self, req):
        try:
            dsep_patient_id=req.route_params.get("resource_type")
            if dsep_patient_id.lower() == "adls": dsep_patient_id=None
        except: dsep_patient_id=None
        logging.info(dsep_patient_id)
        try:
            resource_type = req.route_params.get("resource_fetch").lower()
            if resource_type == "adls": resource_type=None
        except: resource_type = None
        try:
            resource_id = req.route_params.get("resource_fetch_id")
            if  resource_id.lower() == "adls":  resource_id=None
        except: resource_id = None 
        return dsep_patient_id, resource_type, resource_id

    def ADls_data(self, main,app_settings_dict,client_name):
        container_adls_connection_strn=app_settings_dict[f'{client_name}_VELYS_CONNECTION_STRING']
        container_adls=app_settings_dict[f"{client_name}_DSEP_CONTAINER"]

        container_client_strn= self.create_blob_client(container_adls_connection_strn)
        container_client= container_client_strn.get_container_client(container_adls)
        logging.warning("ADls_data(main)")
        data=[]
        for blobs_ in main:
            data.append(self.get_blob_json(container_client, blobs_))
        logging.warning("after (main) append")
        logging.warning("len(data) %s",len(data))
        if len(data) == 0 :
            logging.info("return false")
            return False
        return self.run_format(data)

        
    def run_format(self, data_bundles):
        output={
                "resourceType": "Bundle",
                "type": "transaction-response",
                "entry": data_bundles,

                }
        return output
    
    def adls_data_fetch(self, resource_string,oid,dsep_patient_id,resource_type,resource_id,app_settings_dict,client_name):
        try:
            logging.warning("adls_data_fetch(resource_string,oid,dsep_patient_id)")
            criteria=self.list_blobs_criteria(oid,dsep_patient_id)
            blobs,with_id_dict,without_id,patient_exists=self.blob_iterate(resource_string,criteria,oid,dsep_patient_id,resource_type,resource_id,app_settings_dict,client_name)
            return self.ADls_data(blobs,app_settings_dict,client_name),with_id_dict,without_id,patient_exists
        except Exception as e:
            logging.warning(e)

    def blob_iterate(self, resource_string,criteria,oid,dsep_patient_id,resource_type,resource_id,app_settings_dict,client_name):
        patient_adls_exists = True
        # with_id_id_absent=False
        main=[]
        list_of_blobs=self.fetch_adls_blobs_names(criteria,app_settings_dict,client_name)
        logging.warning("before check_bools_based_request ")
        isidfilters,isfilterwithoutid,with_id_dict,without_id=common_.check_bools_based_request(resource_string,resource_type,resource_id,dsep_patient_id)
        logging.warning("after check_bools_based_request ")
        if dsep_patient_id:
            if oid:
                logging.info("oid : %s",oid)
                blob_name_search=f"v1/{oid}/{dsep_patient_id}/patient/patient_{dsep_patient_id}_"
                blobs = list(filter(lambda k: blob_name_search in k, list_of_blobs))
                if len(blobs)== 0:
                    patient_adls_exists = False
                main.extend(blobs)
            else:
                logging.info("oid not present")
                blob_name_search=f"/patient/patient_{dsep_patient_id}_"
                blobs = list(filter(lambda k: blob_name_search in k, list_of_blobs))
                if len(blobs) == 0:
                    patient_adls_exists = False
                for blob_ in blobs:
                    main.append(blob_)
        else:
            logging.info("oid not present")
            blob_name_search=f"/patient/patient_"
            blobs = list(filter(lambda k: blob_name_search in k, list_of_blobs))
            patient_adls_exists = True
            for blob_ in blobs:
                main.append(blob_)

        if isidfilters :
            logging.info("isidfilters initiate %s",with_id_dict)
            for ids , vals in with_id_dict.items():
                if dsep_patient_id:
                    blob_name_search=f"{dsep_patient_id}/{ids}/{ids}_{vals}.json"
                else :
                    blob_name_search=f"/{ids}/{ids}_{vals}.json"
                blobs=list(filter(lambda k: blob_name_search in k , list_of_blobs))
                logging.warning("len(with_id_dict) %s",len(with_id_dict))
                main.extend(blobs)

        if isfilterwithoutid :
            logging.info("without_id : %s",without_id)
            if dsep_patient_id:
                if oid:
                    logging.warning("if oid and dsep_patient_id:")
                    for ids in  without_id:
                        blob_name_search=f"{oid}/{dsep_patient_id}/{ids}/"
                        logging.info("blob_name_search %s",blob_name_search)
                        blobs=list(filter(lambda k: blob_name_search in k, list_of_blobs))
                        main.extend(blobs)
                else:
                    logging.warning("if not oid and dsep_patient_id:")
                    for ids in  without_id:
                        blob_name_search=f"{dsep_patient_id}/{ids}/"
                        logging.info("blob_name_search %s",blob_name_search)
                        blobs=list(filter(lambda k: blob_name_search in k, list_of_blobs))
                        main.extend(blobs)

            else:
                logging.warning("if not oid and not dsep_patient_id:")
                for ids in  without_id:
                    blob_name_search=f"/{ids}/"
                    logging.info("blob_name_search %s",blob_name_search)
                    blobs=list(filter(lambda k: blob_name_search in k, list_of_blobs))
                    main.extend(blobs)

        return main,with_id_dict,without_id,patient_adls_exists

    
    def list_blobs_criteria(self, oid,dsep_patient_id):
        try:
            if dsep_patient_id:
                if oid:
                    logging.warning("oid and pid")
                    criteria=f"v1/{oid}/{dsep_patient_id}"
                else:
                    logging.warning("only pid")
                    criteria=f"v1/"
            else:
                if oid:
                    logging.warning("only oid")
                    criteria=f"v1/{oid}/"
                else:
                    logging.warning("only everything")
                    criteria=f"v1/"
        except:
            return logging.error("Connection_not established with container")

        logging.info("logs for list_blobs_based_on_oid %s",criteria)
        return criteria

    
    # def decrypt_appsettings(self, s):
    #     s = (s.split("("))[1].split(")")[0]
    #     s = s.split(";")
    #     s0 = s[0].split("=")
    #     s1 = s[1].split("=")
    #     logging.info(s0[1])
    #     logging.info(s1[1])
    #     KVUri = f"https://{s0[1]}.vault.azure.net"
    #     logging.info(KVUri)
    #     managed_identity = ManagedIdentityCredential()
    #     client = SecretClient(vault_url=KVUri, credential=managed_identity)
    #     retrieved_secret = client.get_secret(s1[1])
    #     secret_value = retrieved_secret.value
    #     logging.warning(secret_value)
    #     return secret_value



# Scenario 1
# list_blob(<>)  return <list_of_blobs>
# isidfilters = False
# isfilterwithoutid = False
# iterate the blob (eliminating master, practitioner, ..)
#    raw_data(blob_name) return <raw json of the resources>
#    append all _ data return resource bundle


# Scenario 2
# list_blob(<v1/<oid>)  return <list_of_blobs> - oid, all resource
# isidfilters = False
# isfilterwithoutid = False
# iterate the blob (eliminating master, practitioner, ..)  filter based on resources
#    raw_data(blob_name) return <raw json of the resources>
#    append all _ data return resource bundle

# Scenario 3
# list_blob(<v1/<oid>/<dsep_patient>)  return <list_of_blobs> - oid, all resource
# isidfilters = False
# isfilterwithoutid = False
# iterate the blob (eliminating master, practitioner, ..)  filter based on resources
#    raw_data(blob_name) return <raw json of the resources>
#    append all _ data return resource bundle

