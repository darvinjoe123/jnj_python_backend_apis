import json
import logging
import jwt
import pymysql
import os
from dbutils.pooled_db import PooledDB
import ast

db_details = os.environ['DB_DETAILS'].split(',')
pool_config = os.environ['POOLING_DETAILS'].split(',')
MYSQL_CONFIG = {
    "host": db_details[0],
    "port": int(db_details[1]),
    "db": db_details[2],
    "password": os.environ['DB_PASSWORD'],
    "user": os.environ['DB_USER_NAME'],
    "charset": db_details[3],
    "cursorclass": pymysql.cursors.DictCursor,
    "autocommit": ast.literal_eval(db_details[4]),
}
POOL_CONFIG = {
    # Modules using linked databases
    "creator": pymysql,
    "maxconnections": int(pool_config[0]),
    "mincached": int(pool_config[1]),
    "maxcached": int(pool_config[2]),
    "maxshared": int(pool_config[3]),
    "blocking": ast.literal_eval(pool_config[4]),
    "maxusage": ast.literal_eval(pool_config[5]),
    "setsession": [],
    "ping": int(pool_config[6]),
}

POOL = PooledDB(**MYSQL_CONFIG, **POOL_CONFIG)


class SqlPooled:
    def __init__(self):
        self._connection = POOL.connection()
        self._cursor = self._connection.cursor()

    def fetch_one(self, sql, args):
        self._cursor.execute(sql, args)
        result = self._cursor.fetchone()
        return result

    def fetch_all(self, sql, args):
        self._cursor.execute(sql, args)
        result = self._cursor.fetchall()
        return result

    def __del__(self):
        self._connection.close()
            
def oid_req(req_json):
    try:
        oid = json.loads(req_json)["oid"]
    except:
        oid=None
    return oid

def dsep_search(req):
    try:
        dsep_patient_id=req.route_params.get("dsep_resource_id")
        if dsep_patient_id.lower() == "adls": dsep_patient_id=None
    except: dsep_patient_id=None
    logging.info(dsep_patient_id)
    try:
        resource_type = req.route_params.get("resource_fetch").lower()
        if resource_type == "adls": resource_type=None
    except: resource_type = None
    try:
        resource_id = req.route_params.get("resource_fetch_id")
        if  resource_id.lower() == "adls":  resource_id=None
    except: resource_id = None 
    return dsep_patient_id, resource_type, resource_id


def jwt_decoder(req):
	try:
		token= req.headers['Authorization'].lstrip('Bearer').strip()
		token_decode = jwt.decode(token, options={"verify_signature": False})
		oid = token_decode["oid"]
	except:
		oid = None
	return oid 

def run_format(data_bundles):
    output={
            "resourceType": "Bundle",
            "type": "transaction-response",
            "entry": data_bundles,

            }
    return output

