#patient
QUERYPAT_DSEP_NOID_NRESOURCE = "(SELECT resource_json FROM d4c_fhir_datastore.patient where (dsp_patient_id ='{dsp_id}' order by modified_on desc, id desc limit 1)"

QUERYPAT_DSEP_OID_NRESOURCE = "(SELECT resource_json FROM d4c_fhir_datastore.patient where dsp_patient_id ='{dsp_id}' and system_oid  ='{s_oid}' order by modified_on desc, id desc limit 1)"

QUERYPAT_NDSEP_NOID_NRESOURCE = "(SELECT resource_json FROM (SELECT  resource_json, ROW_NUMBER() OVER (PARTITION BY {part_by} ORDER BY modified_on desc, id desc ) AS RowNo FROM d4c_fhir_datastore.patient) x WHERE x.RowNo = 1)"

QUERYPAT_NDSEP_OID_NRESOURCE =  "(SELECT resource_json FROM (SELECT  resource_json, ROW_NUMBER() OVER (PARTITION BY dsp_patient_id ORDER BY modified_on desc, id desc ) AS RowNo FROM d4c_fhir_datastore.patient where system_oid = '{s_oid}') x WHERE x.RowNo = 1)"  

QUERYPAT_DSEP_OID_RESOURCE = "(SELECT resource_json FROM d4c_fhir_datastore.{t_name} where dsp_patient_id ='{dsp_id}' and (lmi_resource_id='{rid}' or dsp_resource_id='{rid}') and system_oid ='{s_oid}' order by modified_on desc, id desc limit 1)"  

QUERYPAT_DSEP_OID_RESOURCENID = "(SELECT resource_json FROM (SELECT resource_json, ROW_NUMBER() OVER (PARTITION BY {part_by} ORDER BY modified_on desc, id desc ) AS RowNo FROM d4c_fhir_datastore.{t_name} where dsp_patient_id ='{dsp_id}' and system_oid ='{s_oid}') x WHERE x.RowNo = 1)"  

QUERYPAT_NDSEP_NOID_RESOURCE = "(SELECT resource_json FROM d4c_fhir_datastore.{t_name} where (lmi_resource_id='{rid}' or dsp_resource_id='{rid}') order by modified_on desc, id desc limit 1)"  

QUERYPAT_NDSEP_NOID_RESOURCENID= "(SELECT resource_json FROM (SELECT resource_json,  ROW_NUMBER() OVER (PARTITION BY {part_by} ORDER BY modified_on desc, id desc ) AS RowNo FROM d4c_fhir_datastore.{t_name})  x WHERE x.RowNo = 1)"  

QUERYPAT_NDSEP_OID_RESOURCE = "(SELECT resource_json FROM d4c_fhir_datastore.{t_name} where (lmi_resource_id='{rid}' or dsp_resource_id='{rid}') and system_oid ='{s_oid}' order by modified_on desc, id desc limit 1)"  

QUERYPAT_NDSEP_OID_RESOURCENID = "(SELECT resource_json FROM (SELECT resource_json, ROW_NUMBER() OVER (PARTITION BY {part_by} ORDER BY modified_on desc, id desc ) AS RowNo FROM d4c_fhir_datastore.{t_name} where system_oid ='{s_oid}') x WHERE x.RowNo = 1)"  

QUERYPAT_DSEP_NOID_RESOURCE = "(SELECT resource_json FROM d4c_fhir_datastore.{t_name} where dsp_patient_id ='{dsp_id}' and (lmi_resource_id='{rid}' or dsp_resource_id='{rid}')  order by modified_on desc, id desc limit 1)"  

QUERYPAT_DSEP_NOID_RESOURCENID = "(SELECT resource_json FROM (SELECT  resource_json, ROW_NUMBER() OVER (PARTITION BY {part_by} ORDER BY modified_on desc, id desc ) AS RowNo  FROM d4c_fhir_datastore.{t_name} where dsp_patient_id ='{dsp_id}') x WHERE x.RowNo = 1)" 
 
QUERYPAT_LEGACY = "(SELECT dsp_patient_id FROM d4c_fhir_datastore.patient where (lmi_resource_id='{dsp_id}' or mrn='{dsp_id}') order by modified_on desc, id desc limit 1)" 
#non-fhir
QUERY_NOID_NNFHIRTYPE_NID =  "(SELECT resource_json FROM (SELECT resource_json, ROW_NUMBER() OVER (PARTITION BY transaction_id ORDER BY modified_on desc, id desc ) AS RowNo FROM d4c_fhir_datastore.non_fhir) x WHERE x.RowNo = 1)"
QUERY_NOID_NNFHIRTYPE_ID = "(SELECT resource_json FROM d4c_fhir_datastore.non_fhir where transaction_id='{r_id}' order by modified_on desc, id desc limit 1)" 
QUERY_NOID_NFHIRTYPE_NID = "(SELECT resource_json FROM (SELECT resource_json, ROW_NUMBER() OVER (PARTITION BY transaction_id ORDER BY modified_on desc, id desc ) AS RowNo FROM d4c_fhir_datastore.non_fhir where resource_type='{r_type}') x WHERE x.RowNo = 1)" 
QUERY_NOID_NFHIRTYPE_ID = "(SELECT resource_json FROM d4c_fhir_datastore.non_fhir where transaction_id='{r_id}' and resource_type='{r_type}' order by modified_on desc, id desc limit 1)" 
QUERY_OID_NNFHIRTYPE_NID =  "(SELECT resource_json FROM (SELECT resource_json, ROW_NUMBER() OVER (PARTITION BY transaction_id ORDER BY modified_on desc, id desc ) AS RowNo FROM d4c_fhir_datastore.non_fhir where system_oid='{s_oid}') x WHERE x.RowNo = 1)"
QUERY_OID_NNFHIRTYPE_ID = "(SELECT resource_json FROM d4c_fhir_datastore.non_fhir where transaction_id='{r_id}' and system_oid='{s_oid}' order by modified_on desc, id desc limit 1)"
QUERY_OID_NFHIRTYPE_NID = "(SELECT resource_json FROM (SELECT resource_json, ROW_NUMBER() OVER (PARTITION BY transaction_id ORDER BY modified_on desc, id desc ) AS RowNo FROM d4c_fhir_datastore.non_fhir where resource_type='{r_type}' and system_oid='{s_oid}') x WHERE x.RowNo = 1)"
QUERY_OID_NFHIRTYPE_ID = "(SELECT resource_json FROM d4c_fhir_datastore.non_fhir where transaction_id='{r_id}' and system_oid='{s_oid}' and resource_type='{r_type}' order by modified_on desc, id desc limit 1)"

#master-resources
QUERY_MASTER_RESOURCES_NID ="(SELECT resource_json FROM (SELECT resource_json, ROW_NUMBER() OVER (PARTITION BY lmi_resource_id ORDER BY modified_on desc, id desc ) AS RowNo FROM d4c_fhir_datastore.{resource_type}) x WHERE x.RowNo = 1)"
QUERY_MASTER_RESOURCES_ID ="(SELECT resource_json FROM d4c_fhir_datastore.{resource_type} where (lmi_resource_id='{rid}' or dsp_resource_id='{rid}') order by modified_on desc, id desc limit 1)"
#Resources
RESOURCES_LIST = "allergyintolerance,appointment,condition,coverage,diagnosticreport,encounter,immunization,medicationadministration,medicationrequest,medicationstatement,observation,patient,procedure,servicerequest,specimen,account,relatedperson,practitionerrole,careplan,measurereport,familymemberhistory,medicationdispense"

MASTER_RESOURCES_LIST =["location","medication","device"]