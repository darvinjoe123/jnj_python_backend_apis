import logging
import os
import json
import requests
import jwt
from azure.storage.blob import BlobServiceClient


def utils_create_blob_client(connection_string):
    blob_service_client = BlobServiceClient.from_connection_string(
        connection_string)
    return blob_service_client

def utils_get_blob_data(container_client, blob_name):
    blob_client = container_client.get_blob_client(blob=blob_name)
    raw_data = blob_client.download_blob().readall()
    return raw_data

def utils_generate_jwt(client_name,app_settings_dict):
    url = app_settings_dict[f'{client_name}_GENERATE_JWT_URL']
    payload = {}
    headers = {
        'client_id': os.environ['CLIENT_ID'],
        'client_secret': os.environ['CLIENT_SECRET']
    }
    response = requests.request("GET", url, headers=headers, data=payload)
    logging.info(response.headers)
    return response.headers['jwt-token']

def utils_generate_payload_headers(url_params,client_name,app_settings_dict):
    payload = json.dumps({
        "resourceType": "Bundle",
        "id": "bundle-transaction",
        "type": "transaction",
        "entry": [
            {
                "request": {
                    "method": "GET",
                    "url": url_params
                }
            }
        ]
    })

    headers = {
        'PurposeOfUse': app_settings_dict[f"{client_name}_PURPOSE_OF_USE"],
        'UserID': app_settings_dict[f"{client_name}_USER_ID"],
        'Source': app_settings_dict[f"{client_name}_SOURCE"],
        'Product': app_settings_dict[f"{client_name}_PRODUCT"],
        'Application': app_settings_dict[f"{client_name}_APPLICATION"],
        'Content-Type': app_settings_dict[f"{client_name}_CONTENT_TYPE"],
        'Authorization': 'Bearer ' + utils_generate_jwt(client_name,app_settings_dict)
    }

    return payload, headers

def utils_filter_token_for_oid(req):
    jwt_token = req.headers.get('Authorization')[7:]
    decoded = jwt.decode(jwt_token, options={"verify_signature": False})
    oid = decoded['oid']
    return oid

def utils_route_param_fetch(req):
    try:
        dsep_resource_id = req.route_params.get('dsep_resource_id')
        if  dsep_resource_id.lower() == "adls":  dsep_resource_id=None
    except: dsep_resource_id = None
    try:
        resource_fetch = req.route_params.get('resource_fetch').lower()
        if  resource_fetch == "adls":  resource_fetch=None
    except: resource_fetch = None
    try:
        resource_fetch_id = req.route_params.get('resource_fetch_id')
        if resource_fetch_id.lower() == 'adls': resource_fetch_id = None
    except: resource_fetch = None
    return dsep_resource_id, resource_fetch, resource_fetch_id

def utils_format_output(practitioner_data, resource_data):
    output = []
    formatted_output = []
    output.extend(practitioner_data)
    # output.extend(resource_data)

    for i in range(len(output)):
        if 'resource' in output[i]:
            formatted_output.append(
                output[i])
        else:
            formatted_output.append(
                {"resource": output[i]})
    return {
        "resourceType": "Bundle",
        "type": "transaction-response",
        "entry": formatted_output
    }
