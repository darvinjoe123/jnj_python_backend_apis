import json
import os 
import logging 
import ast 

without_id_query        = "(SELECT resource_json FROM (SELECT resource_json, ROW_NUMBER() OVER (PARTITION BY dsp_practitioner_id ORDER BY modified_on desc, id desc ) AS RowNo FROM d4c_fhir_datastore.practitioner) x WHERE x.RowNo = 1)"
practitioner_query      = "(SELECT resource_json FROM d4c_fhir_datastore.practitioner where (dsp_practitioner_id = '{dsp_prac_id}' or npi = '{dsp_prac_id}' or vendor_resource_id='{dsp_prac_id}') order by modified_on desc, id desc limit 1)"
practitioner_oid_query  = "(SELECT resource_json FROM d4c_fhir_datastore.practitioner where (dsp_practitioner_id = '{dsp_prac_id}' or npi = '{dsp_prac_id}' or vendor_resource_id='{dsp_prac_id}') and system_oid = '{s_oid}' order by modified_on desc, id desc limit 1)"



def fetch_practitioner(dsep_pract_id,oid,db_connection):
	try:
		formatted_files_list = []
		formatter_dict_basic = {'dsp_prac_id':str(dsep_pract_id),'s_oid':str(oid)}
		if dsep_pract_id is None:
			query = without_id_query
			db_connection._cursor.execute(query, None)
			df = db_connection._cursor.fetchall()
			if len(df) > 0:
				for data in df:
					formatted_files_list.append(json.loads(str(data['resource_json'])))
		else:
			if oid:
				db_connection._cursor.execute(practitioner_oid_query.format(**formatter_dict_basic), None)
				df = db_connection._cursor.fetchall()
			else:
				db_connection._cursor.execute(practitioner_query.format(**formatter_dict_basic), None)
				df = db_connection._cursor.fetchall()
			if len(df) > 0:
				formatted_files_list.append(json.loads(df[0]["resource_json"]))
			return formatted_files_list
		return formatted_files_list
	except Exception as e:
		logging.info(e)
		formatted_files_list = []
		return formatted_files_list
	finally:db_connection._connection.close()