import logging
from .practitioner import resource_type_check
from .utils import *
from .practitioner import *
import azure.functions as func
from .practitioner_db import * 
import pymysql
from dbutils.pooled_db import PooledDB
from .commons import SqlPooled,jwt_decoder
import ast
from  .app_settings  import getappset_with_oid

# Using the class in a function
db_connection = SqlPooled()

def main(req: func.HttpRequest) -> func.HttpResponse:
    practitioner_id, resource_type, resource_id = utils.utils_route_param_fetch(req)
    url_address = str(req.url).lower()
    req_oid = jwt_decoder(req)
    app_settings_dict,client_name = getappset_with_oid(req_oid)
    if 'adls' in (url_address.lower()).split('/'): d4c = False
    if resource_type != None and resource_type_check(resource_type,app_settings_dict,client_name) is False:
        return func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}), status_code=400, mimetype="application/json")
    d4c=True
    if req_oid is None:
        try:
            req_body = json.loads(req.get_body())
            req_oid = req_body["oid"]
        except:
            req_oid = None
    if d4c:
        # get from mysql
        logging.info(f"d4c:{d4c}")
        practitioner_data = fetch_practitioner(dsep_pract_id=practitioner_id,oid=req_oid,db_connection=db_connection)
    else:
        unbundle_container_client = utils.utils_create_blob_client(os.environ['VELYS_CONNECTION_STRING']).get_container_client(container=app_settings_dict[f'{client_name}_DSEP_CONTAINER'])
        # get from container
        logging.info(f"d4c:{d4c}")
        practitioner_data = practitioner.search_practitioner_by_indentifier(
            unbundle_container_client,
            req_oid,
            app_settings_dict[f'{client_name}_PRACTITIONER_IDENTIFIER'],
            practitioner_id
        )
    if len(practitioner_data) == 0 or practitioner_id is None:
        logging.info('legacy_check')
        if practitioner_id is None:
            practitioner_data.extend(practitioner.get_legacy_resource(f'Practitioner',app_settings_dict[f'{client_name}_LEGACY_API_URL_PRACTITIONER'],client_name,app_settings_dict))
        else:
            practitioner_data = practitioner.get_legacy_resource(f'Practitioner?identifier={practitioner_id}',app_settings_dict[f'{client_name}_LEGACY_API_URL_PRACTITIONER'],client_name,app_settings_dict)
    if len(practitioner_data) == 0:
        return func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}), status_code=400, mimetype="application/json")
    return func.HttpResponse(json.dumps(utils.utils_format_output(practitioner_data, None)), status_code=200, mimetype="application/json")