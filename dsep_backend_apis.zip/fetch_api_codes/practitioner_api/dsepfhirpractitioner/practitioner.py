from http import client
import logging
import os
from azure.storage.blob import BlobServiceClient
import json
from . utils import *

def resource_type_check(resource_type,app_settings_dict,client_name):
    if resource_type in app_settings_dict[f'{client_name}_PRACTITIONER_RESOURCES'].split(','):
        return True
    else:
        return False

def search_practitioner_by_indentifier(unbundle_container_client, oid, identifier_type, practitioner_id):
    files_list = []
    formatted_files_list = []
    isNpi = True
    if practitioner_id == None:
        isNpi = True
    elif '-' in practitioner_id:
        isNpi = False
    if isNpi is True:
        for blob in unbundle_container_client.list_blobs() if oid is None else unbundle_container_client.list_blobs(name_starts_with=f"v1/{oid}"):
            if practitioner_id is None:
                if 'practitioner/practitioner_' in blob.name:
                    files_list.append(json.loads(utils_get_blob_data(
                        unbundle_container_client, blob.name)))
            else:
                if f'practitioner/practitioner_{practitioner_id}' in blob.name:
                    files_list.append(json.loads(utils_get_blob_data(
                        unbundle_container_client, blob.name)))
    elif isNpi is False:
        for blob in unbundle_container_client.list_blobs() if oid is None else unbundle_container_client.list_blobs(name_starts_with=f"v1/{oid}"):
            if f'practitioner/dsep/practitioner_{practitioner_id}' in blob.name:
                files_list.append(json.loads(utils_get_blob_data(
                    unbundle_container_client, blob.name)))
    files_list = list(filter(None, files_list))
    for i in range(len(files_list)):
        if 'resource' in files_list[i]:
            formatted_files_list.append(
                files_list[i])
        else:
            formatted_files_list.append(
                {"resource": files_list[i]})
    return formatted_files_list

def get_legacy_resource(url_params,base_url,client_name,app_settings_dict):
    logging.info("_get_legacy_resources initiated %s", url_params)
    url = base_url
    payload, headers = utils_generate_payload_headers(url_params,client_name,app_settings_dict)
    response = requests.request("POST", url, headers=headers, data=payload)
    bundle = json.loads(response.text)
    resources = []
    data_bundles = []
    try:
        resources = bundle["entry"][0]["resource"]["entry"]
    except KeyError:
        if bundle["entry"][0]["resource"]["resourceType"] == 'Patient':
            resources = bundle["entry"][0]
            del resources["response"]
            return resources
    for resource in resources:
        del resource["search"]
        del resource["fullUrl"]
        data_bundles.append(resource)
    return data_bundles


def form_url_practitioner(resource_type, resource_id, practitioner_id,app_settings_dict,client_name):
    url_type = ''
    if resource_id is None:
        url_type = "no_id"
    else:
        url_type = "id"
    filtered_list = []
    element = app_settings_dict[f"{client_name}_PRACTITIONER_RESOURCE_EXCEPTIONS"].lower().split(",")
    for jelement in app_settings_dict[f"{client_name}_PRACTITIONER_RESOURCES"].lower().split(","):
        if jelement not in element:
            filtered_list.append(jelement)
    relation_resource = app_settings_dict[f"{client_name}_RELATION_DICT_PRACTITIONER"].lower().split(
        ",")
    relation_dict = dict(s.split('-', 1) for s in relation_resource)
    dict_id_noid = {}
    for resource_, relation in relation_dict.items():
        if resource_ in filtered_list:
            dict_id_noid.update({f"{resource_}": {
                'id': f'{resource_.capitalize()}?{relation}=Practitioner/{practitioner_id}&_id={resource_id}',
                'no_id': f'{resource_.capitalize()}?{relation}=Practitioner/{practitioner_id}'
            }})
    url_dict = dict_id_noid
    return url_dict.get(resource_type).get(url_type)
