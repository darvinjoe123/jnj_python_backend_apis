import logging
import datetime
from threading import ExceptHookArgs
from .s3_export_constants import *
from pytz import timezone
import importlib
import json
import uuid

def _save_error_db(raw_data, txn_id, type_, error_message, db_connection):
    query = insert_dsp_error_query
    if type_ == "dlq":
        query = insert_dsp_dlq_query
        value = (txn_id,error_message.replace("'", '"'),json.dumps(raw_data,sort_keys=False),type_,get_date())
    else:
        my_json = json.loads(raw_data)
        value = (txn_id,error_message,json.dumps(my_json),type_,get_date())
    logging.info(query)
    logging.info(value)
    db_connection._cursor.execute(query+ str(value))
    return "success"
def resource_validator(fhir_type,resource_payload,db_connection):
    fhir_module=importlib.import_module(f'fhir.resources.{str(fhir_type).lower()}')
    fhir_function = getattr(fhir_module, fhir_type)
    try:
        fhir_function(**resource_payload)
        return True
    except Exception as e:
        logging.info(e)
        txn_id = str(uuid.uuid4()) 
        _save_error_db(resource_payload, txn_id,"dlq", f"FHIR Error : {str(e)}", db_connection)
        return False

def get_date():
    tz = timezone('US/Eastern')
    time_stamp = str(datetime.datetime.now(tz))[:-13]
    return time_stamp

def s3_status_update(uuid, s3_status,resource_table_name,db_connection):
    print("values set in S3")
    try:
        db_connection._cursor.execute(s3_update_d4cfhir_query.format(
            str("'")+s3_status+str("'"),
            str("'")+uuid+str("'")))
    except Exception as e:
        logging.info(e)
    return "success"

def _save_to_d4cfhirdatastore_other_resource(system_oid, organization_oid, resource_id,dsp_patient_id, resource_type, resource_json, transaction_id, s3_status, db_connection, new_dsp_resource_id):
    insert_resource_query = insert_d4cfhir_other_resource.format(resource_type)
    try:
        value = (system_oid,organization_oid,resource_id, "",dsp_patient_id,resource_type,resource_json,transaction_id,new_dsp_resource_id,"Legacy",get_date(),get_date())
        db_connection._cursor.execute(insert_resource_query + str(value))
        logging.info("data inserted successfully !! ")
    except Exception as e:
        logging.warn(e)
    return "success"


def _save_to_d4cfhirdatastore_patient(system_oid, organization_oid, resource_id, dsp_patient_id, mrn, resource_type, resource_json, transaction_id, db_connection):
    try:
        value = (organization_oid, dsp_patient_id, resource_id, mrn , "", resource_type,resource_json, transaction_id,"Legacy",get_date(),get_date())
        db_connection._cursor.execute(insert_d4cfhir_query_patient + str(value))
        logging.info("data inserted successfully !! to s3_export")
    except Exception as e:
        logging.warn(e)
    return "success"


def _save_to_d4cfhirdatastore_practitioner(system_oid, organization_oid, resource_id, npi, dsp_practitioner_id, resource_type, resource_json, transaction_id, s3_status, db_connection):
    value = (system_oid,organization_oid,resource_id,dsp_practitioner_id,npi,"",resource_type,resource_json, transaction_id,"Legacy",get_date(),get_date())
    db_connection._cursor.execute(insert_d4cfhir_query_practitioner + str(value))
    logging.info("data inserted successfully !! practitioner ")
    return "success"


def _save_to_d4cfhirdatastore_org(system_oid, resource_id, resource_type, resource_json, transaction_id, s3_status,dsp_org_id, db_connection):
    value = (system_oid,resource_id,resource_type,resource_json,transaction_id,dsp_org_id,"Legacy",get_date(),get_date())
    db_connection._cursor.execute(insert_d4cfhir_query_organization + str(value))
    logging.info("data inserted successfully !! ")
    return "success"

def  _save_to_d4cfhirdatastore_med(resource_json, transaction_id, filename, resource_type, resource_id,dsp_med_id, db_connection):
        v = str(resource_json)
        value = (resource_id, resource_type, v, transaction_id, dsp_med_id, "Legacy",get_date(),get_date())
        logging.warn(insert_d4cfhir_query_med + str(value))
        db_connection._cursor.execute(insert_d4cfhir_query_med + str(value))
        logging.info("data inserted successfully !! ")
        return "success"