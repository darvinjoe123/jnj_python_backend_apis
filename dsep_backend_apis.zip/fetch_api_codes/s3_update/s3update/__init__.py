import logging
import json
import uuid
import os
import azure.functions as func
from . import patient
from .commons import SqlPooled,jwt_decoder
from .s3_export_constants import resources
from .save_db import (resource_validator)
# Using the class in a function
db_connection = SqlPooled()

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        req_body = req.get_json()
    except:
        return func.HttpResponse(json.dumps({"error" : os.environ['EMPTY_REQUEST_ERROR']}), status_code=400, mimetype="application/json")
    resource_type = req.route_params.get('resource_type')
    id = req.route_params.get('id')
    # validity = resource_validator(resource_type,req_body,db_connection)
    # logging.info(f"FHIR Validity: {str(validity)}")
    if resource_type is not None and id is not None and req_body is not None:
        if req_body:
            txn_id = str(uuid.uuid4())
            try:
                resource_json = req_body
                logging.warning("resource_json >> %s",resource_json)
                if resource_type != resource_json["resourceType"] or id != resource_json["id"]:
                    return func.HttpResponse(json.dumps({"error" : os.environ['MISMATCH_RESOURCES']}), status_code=400, mimetype="application/json")
                if resource_type == "Patient" and (id.isdigit()):
                    resource_json = patient._new_patient(resource_json, txn_id, id, db_connection)
                elif resource_type in resources and (id.isdigit()):
                    return func.HttpResponse(json.dumps(patient._other_resources(resource_json, txn_id, db_connection,id,resource_type)),status_code=200, mimetype="application/json")
                elif resource_type.lower() == "practitioner":
                    logging.info("practitioner")
                    return func.HttpResponse(json.dumps(patient._practitioner_resource(resource_json, txn_id, db_connection)),status_code=200, mimetype="application/json")
                elif resource_type.lower() == "organization":
                    logging.info("organization")
                    logging.warning(f"incoming {resource_json} and {txn_id}")
                    return func.HttpResponse(json.dumps(patient._organization_resource(resource_json, txn_id, db_connection)),status_code=200, mimetype="application/json")
                elif resource_type.lower() == "medication":
                    logging.info("medication")
                    logging.warning(f"incoming {resource_json} and {txn_id}")
                    return func.HttpResponse(json.dumps(patient._medication_resource(resource_json, txn_id,resource_type, db_connection)),status_code=200, mimetype="application/json")
                else:
                    return func.HttpResponse(
                json.dumps(  { "error" : os.environ['INVALID_RESOURCE_ID']}),
                status_code=400, mimetype="application/json"
            )
                return func.HttpResponse(json.dumps(resource_json),status_code=200, mimetype="application/json")

            except Exception as e:
                logging.error(e)
                return func.HttpResponse(
                    json.dumps(patient.error_acknowledgement(txn_id)),
                    status_code=400, mimetype="application/json"
                )
        return func.HttpResponse(json.dumps({"error" : os.environ['BAD_REQUEST']}), status_code=400, mimetype="application/json")

    return func.HttpResponse(
                json.dumps( { "error" : os.environ['EMPTY_RESOURCE_ERROR']} ),
                status_code=400, mimetype="application/json"
            )