# Sql Syntax
select_by_organization_id_query = "SELECT id from d4c_fhir_datastore.s3_export where vendor_resource_id = {} and resource_type = {} limit 1"
select_by_patient_id_query = "SELECT id from d4c_fhir_datastore.s3_export where vendor_resource_id = {} and dsp_patient_id = {} and resource_type = {} limit 1"
select_by_practitioner_id_query = "SELECT id from d4c_fhir_datastore.s3_export where vendor_resource_id = {} and dsp_practitioner_id = {} and resource_type = {} limit 1"
s3_update_d4cfhir_query = "UPDATE d4c_fhir_datastore.s3_export SET s3_status= {} WHERE transaction_id = {};"
select_by_other_resource_id_query = "SELECT id from d4c_fhir_datastore.s3_export where vendor_resource_id = {} and dsp_patient_id = {} and resource_type = {} limit 1"
update_d4cfhir_query_patient = update_d4cfhir_query_organization = update_d4cfhir_query_practitioner = update_d4cfhir_query = "UPDATE d4c_fhir_datastore.s3_export SET system_oid = %s, organization_oid = %s, vendor_resource_id = %s, dsp_patient_id = %s, transaction_id = %s, resource_type = %s, dsp_resource_id=%s,  mrn = %s, dsp_practitioner_id = %s, npi=%s, resource_json = %s, vendor_name = %s , modified_on = %s WHERE id = %s;"
insert_d4cfhir_query = "INSERT INTO d4c_fhir_datastore.s3_export (system_oid, organization_oid, vendor_resource_id, dsp_patient_id, transaction_id, resource_type, dsp_resource_id,  mrn, dsp_practitioner_id, npi, resource_json, vendor_name, created_on, modified_on,s3_status) VALUES"
insert_d4cfhir_other_resource =  "INSERT INTO d4c_fhir_datastore.{} (system_oid, organization_oid, vendor_resource_id, client_id, dsp_patient_id, resource_type, resource_json, transaction_id, dsp_resource_id, vendor_name, created_on, modified_on) VALUES "
insert_d4cfhir_query_patient = "INSERT INTO d4c_fhir_datastore.patient (organization_oid,  dsp_patient_id, vendor_resource_id, mrn, client_id, resource_type, resource_json, transaction_id, vendor_name, created_on, modified_on ) VALUES "
insert_d4cfhir_query_practitioner = "INSERT INTO d4c_fhir_datastore.practitioner (system_oid, organization_oid, vendor_resource_id, dsp_practitioner_id, npi, client_id, resource_type, resource_json, transaction_id, vendor_name, created_on, modified_on) VALUES"
insert_d4cfhir_query_organization =  "INSERT INTO d4c_fhir_datastore.organization (system_oid, vendor_resource_id, resource_type, resource_json, transaction_id,dsp_organization_id, vendor_name, created_on, modified_on) VALUES"
insert_d4cfhir_query_med = "INSERT INTO d4c_fhir_datastore.medication (vendor_resource_id, resource_type, resource_json, transaction_id, dsp_resource_id, vendor_name, created_on, modified_on) VALUES"
insert_dsp_error_query =  "INSERT INTO error_processing(transaction_id, error, file, type,created_on)VALUES"
insert_dsp_dlq_query =  "INSERT INTO dlq (transaction_id, error, file, type, created_on)VALUES"
resources = ["Appointment", "Procedure", "Coverage", "Condition",
             "Observation", "MedicationAdministration", "MedicationRequest",
             "DiagnosticReport", "AllergyIntolerance", "Encounter", "ServiceRequest"]
# dsp_patient_identifier = {
#                 "system": "DSEP_Patient_ID",
#                 "value": "dsp_id",
#                 "assigner": {
#                     "reference" : "DSEP"
#                 }
#             }

# def s3_identifier_format(resource_kind,dsp_id):
#     if resource_kind == 'patient':
#             new_dsep_identifier =  {
#                 "system": "DSEP_Patient_ID",
#                 "value": str(dsp_id),
#                 "assigner": {
#                     "reference" : "DSEP"
#                 }
#             }
#             return new_dsep_identifier

#     if resource_kind not in "patient,practitioner,medication,organization".split():
