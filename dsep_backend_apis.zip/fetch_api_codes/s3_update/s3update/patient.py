import logging
import os
import json
import uuid
import ast
import boto3
import requests
from datetime import datetime
from benedict import benedict
from azure.storage.blob import BlobServiceClient
from . import post_legacy_fhir
from . import identifier_genetor 
from fhir.resources.organization import Organization
import azure.functions as func
from .save_db import (_save_to_d4cfhirdatastore_org,
                      _save_to_d4cfhirdatastore_practitioner,
                      _save_to_d4cfhirdatastore_other_resource,
                      _save_to_d4cfhirdatastore_patient,
                      _save_to_d4cfhirdatastore_med, 
                      s3_status_update
                      )
from .move_to_look import move_to_look_up_file, search_json 
import time


def c_create_blob_client(connection_string):
    blob_service_client = BlobServiceClient.from_connection_string(
        connection_string)
    return blob_service_client

def utils_generate_jwt():
    url = os.environ['GENERATE_JWT_URL']
    payload = {}
    headers = {
        'client_id': os.environ['CLIENT_ID'],
        'client_secret': os.environ['CLIENT_SECRET']
    }
    response = requests.request("GET", url, headers=headers, data=payload)
    logging.info(response.headers)
    return response.headers['jwt-token']

def utils_generate_payload_headers(url_params):
    payload = json.dumps({
        "resourceType": "Bundle",
        "id": "bundle-transaction",
        "type": "transaction",
        "entry": [
            {
                "request": {
                    "method": "GET",
                    "url": url_params
                }
            }
        ]
    })

    headers = {
        'PurposeOfUse': os.environ["PURPOSE_OF_USE"],
        'UserID': os.environ["USER_ID"],
        'Source': os.environ["SOURCE"],
        'Product': os.environ["PRODUCT"],
        'Application': os.environ["APPLICATION"],
        'Content-Type': os.environ["CONTENT_TYPE"],
        'Authorization': 'Bearer ' + utils_generate_jwt()
    }

    return payload, headers

def generate_org_data(oid,url_param,base_url):
    payload,headers=utils_generate_payload_headers(url_param.format(oid=oid))
    url = base_url
    response = requests.request("POST", url, headers=headers, data=payload)
    bundle = json.loads(response.text)
    return bundle

def check_care_coordination_consent(bundle_data):
    bundle = Organization(**bundle_data)
    if bundle.resource_type == "Organization":
        logging.info("bundle.extension >> %s",bundle.extension[0].url)
        if bundle.extension[0].url== os.environ["CARE_CONSENT_URL"]:
                return  bundle.extension[0].valueBoolean

def error_acknowledgement(txn_id):
    new_patient_acknowledgement = {
        "transaction_id": txn_id,
        "dsep_patient_id": "",
        "uri": ""
    }
    id_update_url = os.environ['DSEP_ID_UPDATE_URL']
    #response = requests.post(id_update_url + txn_id + "-ACK.json", json.dumps(new_patient_acknowledgement))
    return new_patient_acknowledgement

def _save_to_container(data, container_client, blob_name):
    blob_client = container_client.get_blob_client(blob=blob_name)
    blob_client.upload_blob(data, overwrite=True)

def _create_blob_client(storage_account_name, connection_string):
    #account_url = f'https://{storage_account_name}.blob.core.windows.net/'
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    return blob_service_client

def move_bundle_to_client_container_other(data, txn_id, filename, resource_id, resource_type, dsp_patient_id,coordination_consent, db_connection, new_dsp_resource_id):
    dsp_fhir_blob_client = _create_blob_client(os.environ['EXTERNAL_STORAGE_ACCOUNT_NAME'], os.environ['EXTERNAL_CONNECTION_STRING'])
    #dsp_fhir_blob_container_client = dsp_fhir_blob_client.get_container_client(container=os.environ['DSP_FHIR_CONTAINER'])
    #_save_to_container(json.dumps(data), dsp_fhir_blob_container_client, txn_id + ".json")
    dsp_fhir_blob_container_client = dsp_fhir_blob_client.get_container_client(container=os.environ['S3_CONTAINER'])
    if os.environ['IS_FHIR_D4C']:
        _save_to_d4cfhirdatastore_other_resource("", "",resource_id, dsp_patient_id, resource_type, json.dumps(data,sort_keys=False), txn_id, "0", db_connection, new_dsp_resource_id)
    if coordination_consent == True : _save_to_container(json.dumps(data), dsp_fhir_blob_container_client, filename)

def move_bundle_to_client_container(data, txn_id, filename):
    dsp_fhir_blob_client = _create_blob_client(os.environ['EXTERNAL_STORAGE_ACCOUNT_NAME'], os.environ['EXTERNAL_CONNECTION_STRING'])
    #dsp_fhir_blob_container_client = dsp_fhir_blob_client.get_container_client(container=os.environ['DSP_FHIR_CONTAINER'])
    #_save_to_container(json.dumps(data), dsp_fhir_blob_container_client, txn_id + ".json")
    dsp_fhir_blob_container_client = dsp_fhir_blob_client.get_container_client(container=os.environ['S3_CONTAINER'])
    _save_to_container(json.dumps(data), dsp_fhir_blob_container_client, filename)

def move_bundle_to_client_container_patient(data, txn_id, filename,resource_id, dsep_id, resource_type, mrn, internal_oid,coordination_consent, db_connection):
    dsp_fhir_blob_client = _create_blob_client(os.environ['EXTERNAL_STORAGE_ACCOUNT_NAME'], os.environ['EXTERNAL_CONNECTION_STRING'])
    #dsp_fhir_blob_container_client = dsp_fhir_blob_client.get_container_client(container=os.environ['DSP_FHIR_CONTAINER'])
    #_save_to_container(json.dumps(data), dsp_fhir_blob_container_client, txn_id + ".json")
    dsp_fhir_blob_container_client = dsp_fhir_blob_client.get_container_client(container=os.environ['S3_CONTAINER'])
    if ast.literal_eval(os.environ['IS_FHIR_D4C']):
        _save_to_d4cfhirdatastore_patient("", internal_oid, resource_id, dsep_id, mrn, resource_type, json.dumps(data,sort_keys=False), txn_id, db_connection, )
    if coordination_consent == True: _save_to_container(json.dumps(data), dsp_fhir_blob_container_client, filename)


def move_bundle_to_client_container_practitioner(data, txn_id, filename, resource_id, resource_type, dsep_id, npi_id, db_connection):
    dsp_fhir_blob_client = _create_blob_client(os.environ['EXTERNAL_STORAGE_ACCOUNT_NAME'], os.environ['EXTERNAL_CONNECTION_STRING'])
    #dsp_fhir_blob_container_client = dsp_fhir_blob_client.get_container_client(container=os.environ['DSP_FHIR_CONTAINER'])
    #_save_to_container(json.dumps(data), dsp_fhir_blob_container_client, txn_id + ".json")
    dsp_fhir_blob_container_client = dsp_fhir_blob_client.get_container_client(container=os.environ['S3_CONTAINER'])
    if ast.literal_eval(os.environ['IS_FHIR_D4C']):
        _save_to_d4cfhirdatastore_practitioner("", "", resource_id, npi_id, dsep_id, resource_type, json.dumps(data,sort_keys=False), txn_id, "0", db_connection) 
    _save_to_container(json.dumps(data), dsp_fhir_blob_container_client, filename)

def move_bundle_to_client_container_org(data, txn_id, filename, resource_type, resource_id, vendor_oid,coordination_consent,dsp_org_id, db_connection):
    dsp_fhir_blob_client = _create_blob_client(os.environ['EXTERNAL_STORAGE_ACCOUNT_NAME'], os.environ['EXTERNAL_CONNECTION_STRING'])
    #dsp_fhir_blob_container_client = dsp_fhir_blob_client.get_container_client(container=os.environ['DSP_FHIR_CONTAINER'])
    #_save_to_container(json.dumps(data), dsp_fhir_blob_container_client, txn_id + ".json")
    dsp_fhir_blob_container_client = dsp_fhir_blob_client.get_container_client(container=os.environ['S3_CONTAINER'])
    if ast.literal_eval(os.environ['IS_FHIR_D4C']):
        _save_to_d4cfhirdatastore_org(vendor_oid, resource_id, resource_type, json.dumps(data,sort_keys=False), txn_id, "0", dsp_org_id, db_connection) 
    if coordination_consent == True: _save_to_container(json.dumps(data), dsp_fhir_blob_container_client, filename)

def move_bundle_to_client_container_med(resource_json, transaction_id, filename, resource_type, resource_id,dsp_med_id, db_connection):
    try:
        if ast.literal_eval(os.environ['IS_FHIR_D4C']):
            _save_to_d4cfhirdatastore_med(resource_json, transaction_id, filename, resource_type, resource_id,dsp_med_id, db_connection)    
    except Exception as e:
        logging.warn(e)
    try:
        dsp_fhir_blob_client = _create_blob_client(os.environ['EXTERNAL_STORAGE_ACCOUNT_NAME'], os.environ['EXTERNAL_CONNECTION_STRING'])
        dsp_fhir_blob_container_client = dsp_fhir_blob_client.get_container_client(container=os.environ['S3_CONTAINER'])
        _save_to_container(json.dumps(resource_json), dsp_fhir_blob_container_client, filename)
    except Exception as e:
        logging.info(e)
    return "success"
def move_bundle_s3(data, filename, txn_id,resource_type,db_connection):
    # failing in here now
    try:
        logging.info("its into s3 bucket ")
        aws_bucket = boto3.resource('s3', aws_access_key_id=os.environ["AWS_ACCESS_KEY"],
                                    aws_secret_access_key=os.environ["AWS_SECRET_KEY"])
        aws_bucket.Object(os.environ['S3_BUCKET_NAME'],
                          '{resource_file}'.format(resource_file=filename)).put(Body=json.dumps(data))
        logging.warn("moved to s3 bucket")
        logging.error(data)
        logging.error(filename)
        # s3_status_update(txn_id, "2",resource_type,db_connection)
    except:
        logging.error(data)
        logging.error(filename)
        logging.error("Key Error")
        # s3_status_update(txn_id, "1",resource_type,db_connection)

def _fetch_patient_id_by_resource(data):

    data_resourceType = data['resourceType'].lower()
    try:
        if(data_resourceType in os.environ['ACTOR_FHIR'].lower().split(',')):
            return data["participant"][0]["actor"]["reference"]
        elif(data_resourceType in os.environ['BENEFICIARY_FHIR'].lower().split(',')):
            return data["beneficiary"]["reference"]
        elif(data_resourceType in os.environ['SUBJECT_FHIR'].lower().split(',')):
            return data["subject"]["reference"]
        elif(data_resourceType == 'diagnosticreport'):
            return data['subject']['reference']
        elif(data_resourceType == 'allergyintolerance'):
            return data["patient"]["reference"]
        elif(data_resourceType == "servicerequest"):
            return data['subject']['reference']
        elif(data_resourceType == "encounter"):
            return data['subject']['reference']
    except KeyError as e:
        logging.error(f"Key error: {e}")




def _wrap_bundle(data_resources):
    output = {
        "resourceType": "Bundle",
        "id": "f8c66b88-de6d-45df-a040-cda75fbe1ee4",
        "type": "collection",
        "timestamp": f"{datetime.now()}",
        "link": [
            {
                "relation": "self",
                "url": "https://dsep-fhir-server.api-apd-fhr.thesurgicalnet.com/fhir"
            }
        ],
        "entry": [
            {
                "resource":  data_resources
            }]
    }
    return output

def swap_fhir_id(patient_data, resource_id, dsep_patient_id,r_type):
    docspera_identifier = identifier_genetor.docspera_identifier(resource_id,r_type)
    patient_data["id"] = dsep_patient_id
    if "identifier" not in (patient_data):
        patient_data["identifier"] = []
    if(f"FHIR_{r_type}_ID" not in str(patient_data["identifier"])):
        print("docspera does not exists")
        patient_data['identifier'].append(docspera_identifier)
    return patient_data



def get_new_patient_id():
    try:
        patient_id_gen_url = os.environ['DSEP_PATIENT_ID_GENERATOR_URL']
        response = requests.get(patient_id_gen_url, timeout=30)
        response.raise_for_status()
        new_id = response.text
        return new_id
    except requests.exceptions.RequestException as exception:
        logging.error("There was an error when generating a new UUID using API endpoint: %s", patient_id_gen_url)
        raise SystemExit(exception)

def isValueExists(patient_json, key_string):
    try:
        list_assigners = patient_json["identifier"]
        list_string = []
        for assign in list_assigners:
            try:
                if key_string in str(assign["system"]):
                    return str(assign["value"])
            except:
                logging.error("error")
        return ""
    except:
        logging.error("Something went wrong")
        return ""
def isOrgExists(patient_json, key_string):
    try:
        list_assigners = patient_json["identifier"]
        list_string = []
        for assign in list_assigners:
            try:
                if key_string in str(assign["assigner"]["reference"]):
                    return str(assign["assigner"]["reference"].split('/')[1])
            except:
                logging.error("error")
        return ""
    except:
        logging.error("Something went wrong")
        return ""

def isValueExists_prac(practitioner_json,key_string):
    try:
        list_assigners = practitioner_json["identifier"]
        list_string = []
        for assign in list_assigners:
            try:
                if key_string in str(assign["system"]):
                    return str(assign["value"])
            except:
                logging.error("error")
        return ""
    except:
        logging.error("Something went wrong")
        return ""

def get_values(data):
    npi_id,urn_oid="",""
    for iterblock in data["identifier"]:
        if "Medical record number" in str(iterblock):
            npi_id=iterblock["value"]
            break
    d = benedict(data)
    r =  d.search("urn:oid", in_keys=False, in_values=True, exact=False, case_sensitive=False)
    urn_oid = r[0][0]["system"][8:]
    return npi_id, urn_oid

def _other_resources(data, txn_id, db_connection,id,resource_type):
    url_params = _fetch_patient_id_by_resource(data)
    patient_json = post_legacy_fhir._get_patient_resources(url_params)
    organization_id = isOrgExists(patient_json,"Organization")
    oid_url_param=os.environ["OID_SEARCH_QUERY"]
    oid_base_url= os.environ["LEGACY_API_URL_ORG"]
    organization_data=generate_org_data(organization_id,oid_url_param,oid_base_url)
    try:
        coordination_consent=check_care_coordination_consent(organization_data['entry'][0]['resource']['entry'][0]['resource'])
    except:
        coordination_consent = False
  
    dsep_patient_id = isValueExists(patient_json, "DSEP")
    if(dsep_patient_id == ""):       
        new_dsep_patient_id = get_new_patient_id()
        dsep_patient_id = new_dsep_patient_id
        new_dsep_identifier = identifier_genetor.dsep_pat_identifier(new_dsep_patient_id)

        filename =  txn_id + "_" + new_dsep_patient_id + ".json"
        #filename = new_dsep_patient_id + "/" + txn_id + ".json"
        patient_json['identifier'].append(new_dsep_identifier)
        post_legacy_fhir._post_patient(patient_json, url_params)
        # try:
        #     if "identifier" in data:
        #         logging.info("identifier exists")
        #     else:
        #         data["identifier"] = []
        # except:
        #     logging.error("identifier error")
        # #data['identifier'].append(new_dsep_identifier)
        # move_bundle_to_client_container(data, txn_id, filename)
        # move_bundle_s3(data, filename,txn_id,resource_type,db_connection)
    #else:
    # mrn,urn_oid = get_values(data)
    data_resourceType = data['resourceType'].lower()
    oid_resource = data['id']
    list_keys = os.environ["IDENTIFIER_KEYS"].split(",")
    list_assigners = patient_json["identifier"]
    try:
        if "identifier" in data:
            logging.info("identifier exists")
        else:
            data["identifier"] = []
    except:
        logging.error("identifier error")
    for assign in list_assigners:
        try:
            if("system" in assign):
                if assign["system"] in list_keys and assign["system"] not in str(data["identifier"]):# removed DSEP_Patient_ID, from list_keys osenv
                    data["identifier"].append(assign)
            elif("type" in assign):
                if assign["type"]["text"] in list_keys and assign["type"]["text"] not in str(data["identifier"]):
                    data["identifier"].append(assign)
        except:
            logging.error("error")
    new_dsep_identifier = identifier_genetor.dsep_pat_identifier(dsep_patient_id)
    
    if(data_resourceType in os.environ['ACTOR_FHIR'].lower().split(',')):
        for entry in range(len(data["participant"])):
            if "Patient/" in str(data["participant"][entry]):
                if "identifier" in str(data["participant"][entry]):
                    iden = data["participant"][entry]["actor"]["identifier"]
                    data["participant"][entry]["actor"]["identifier"]=[]
                    data["participant"][entry]["actor"]["identifier"].append(iden)
                    if "DSEP_Patient_ID" not in str(data["participant"][entry]["actor"]["identifier"]):
                        data["participant"][entry]["actor"]["identifier"].append(new_dsep_identifier)
                elif "identifier" not in str(data["participant"][entry]):
                    data["participant"][entry]["actor"]["identifier"]=[]
                    data["participant"][entry]["actor"]["identifier"].append(new_dsep_identifier)
                break
    elif(data_resourceType in os.environ['BENEFICIARY_FHIR'].lower().split(',')):
        if "identifier"  in str(data["beneficiary"]):
            iden = data["beneficiary"]["identifier"]
            data["beneficiary"]["identifier"]=[]
            data["beneficiary"]["identifier"].append(iden)
            if "DSEP_Patient_ID" not in str(data["beneficiary"]["identifier"]):
                data["beneficiary"]["identifier"].append(new_dsep_identifier)
        elif "identifier" not in str(data["beneficiary"]):
            data["beneficiary"]["identifier"]=[]
            data["beneficiary"]["identifier"].append(new_dsep_identifier)
    elif(data_resourceType in os.environ['SUBJECT_FHIR'].lower().split(',')):
        if "identifier" in str(data["subject"]):
            iden = data["subject"]["identifier"]
            data["subject"]["identifier"]=[]
            data["subject"]["identifier"].append(iden)
            if "DSEP_Patient_ID" not in str(data["subject"]["identifier"]):
                data["subject"]["identifier"].append(new_dsep_identifier)
        elif "identifier" not in str(data["subject"]):
            data["subject"]["identifier"]=[]
            data["subject"]["identifier"].append(new_dsep_identifier)
    elif(data_resourceType == 'diagnosticreport'):
        if "identifier" in str(data["subject"]):
            iden = data["subject"]["identifier"]
            data["subject"]["identifier"]=[]
            data["subject"]["identifier"].append(iden)
            if "DSEP_Patient_ID" not in str(data["subject"]["identifier"]):
                data["subject"]["identifier"].append(new_dsep_identifier)
        elif "identifier" not in str(data["subject"]):
            data["subject"]["identifier"]=[]
            data["subject"]["identifier"].append(new_dsep_identifier)
    elif(data_resourceType == 'allergyintolerance'):
        if "identifier"  in str(data["patient"]):
            iden = data["patient"]["identifier"]
            data["patient"]["identifier"]=[]
            data["patient"]["identifier"].append(iden)
            if "DSEP_Patient_ID" not in str(data["patient"]["identifier"]):
                data["patient"]["identifier"].append(new_dsep_identifier)
        elif "identifier" not  in str(data["patient"]):
            data["patient"]["identifier"]=[]
            data["patient"]["identifier"].append(new_dsep_identifier)
    elif(data_resourceType == "servicerequest"):
        if "identifier" in str(data["subject"]):
            iden = data["subject"]["identifier"]
            data["subject"]["identifier"]=[]
            data["subject"]["identifier"].append(iden)
            if "DSEP_Patient_ID" not in str(data["subject"]["identifier"]):
                data["subject"]["identifier"].append(new_dsep_identifier)
        elif "identifier" not in str(data["subject"]):
            data["subject"]["identifier"]=[]
            data["subject"]["identifier"].append(new_dsep_identifier)
    elif(data_resourceType == "encounter"):
        if "identifier" in str(data["subject"]):
            iden = data["subject"]["identifier"]
            data["subject"]["identifier"]=[]
            data["subject"]["identifier"].append(iden)
            if "DSEP_Patient_ID" not in str(data["subject"]["identifier"]):
                data["subject"]["identifier"].append(new_dsep_identifier)
        elif "identifier" not in str(data["subject"]):
            data["subject"]["identifier"]=[]
            data["subject"]["identifier"].append(new_dsep_identifier)
    data , new_dsp_resource_id = dsp_resource_swap(data, id, resource_type)
    logging.warning("resource_json > %s",data)# Post back to fhir other patient resources
    # post_legacy_fhir._post_patient(data, f"{resource_type}/{id}")
    filename =  txn_id + "_" +  dsep_patient_id + ".json"
    #filename = dsep_patient_id + "/" + txn_id + ".json"
    logging.warn("moving other resources to bucket")
    move_bundle_to_client_container_other(data, txn_id, filename, oid_resource, data_resourceType, dsep_patient_id,coordination_consent, db_connection, new_dsp_resource_id)
    if coordination_consent == True : move_bundle_s3(data, filename, txn_id,resource_type,db_connection)
    return data

def dsp_resource_swap(data, id, resource_type):
    try:
        new_dsp_resource_id = get_new_patient_id()
        fhir_resource_identifier = 	identifier_genetor.fhir_identifer(resource_type)
        new_resource_identifier =  identifier_genetor.new_resource_identifier(resource_type,new_dsp_resource_id)
        if(f"DSP_{resource_type}_ID" not in str(data["identifier"])):
            data['identifier'].append(new_resource_identifier)
            # post_legacy_fhir._post_patient(data, f"{resource_type}/{id}")
        else:
            d = benedict(data)
            r =  d.search(f"DSP_{resource_type}_ID", in_keys=False, in_values=True, exact=True, case_sensitive=False) 
            if r:
                new_dsp_resource_id = r[0][0]["value"]
        data["id"] = new_dsp_resource_id
        if(f"FHIR_{resource_type}_ID" not in str(data["identifier"])):
            data['identifier'].append(fhir_resource_identifier)
    except Exception as e:
        logging.warn(e)
    
    return data, new_dsp_resource_id

def _new_patient(patient_json, txn_id, patient_internal_id, db_connection):
    organization_id = isOrgExists(patient_json,"Organization")
    oid_url_param=os.environ["OID_SEARCH_QUERY"]
    oid_base_url= os.environ["LEGACY_API_URL_ORG"]
    organization_data=generate_org_data(organization_id,oid_url_param,oid_base_url)
    try:
        coordination_consent=check_care_coordination_consent(organization_data['entry'][0]['resource']['entry'][0]['resource'])
    except:
        coordination_consent = False
    dsep_patient_id = isValueExists(patient_json, "DSEP")
    try:
        if dsep_patient_id == "":
            new_dsep_patient_id = get_new_patient_id()
            new_dsep_identifier =  identifier_genetor.dsep_pat_identifier(new_dsep_patient_id)
            #filename = new_dsep_patient_id + "/" + txn_id + ".json"
            filename =  txn_id + "_" + new_dsep_patient_id + ".json"
            if "identifier" not in patient_json: patient_json['identifier'] = []
            patient_json['identifier'].insert(0, new_dsep_identifier)
            logging.warning("patient_json > %s",patient_json)# Post back to fhir patient resources
            post_legacy_fhir._post_patient(patient_json, f"Patient/{patient_internal_id}")
            return patient_json
        else:
            mrn,urn_oid = get_values(patient_json)
            resource_id = patient_json['id']
            type = patient_json['resourceType'].lower()
            try: filename =  txn_id + "_" + dsep_patient_id + ".json"  
            except Exception as e: logging.info(e)
            enrich_data = swap_fhir_id(patient_json, resource_id, dsep_patient_id,patient_json['resourceType'])
            move_bundle_to_client_container_patient((enrich_data), txn_id, filename,resource_id,dsep_patient_id, type, mrn, urn_oid,coordination_consent,db_connection)
            if coordination_consent == True: move_bundle_s3(enrich_data, filename, txn_id,type,db_connection)
            docspera_id = search_json(enrich_data, search_string="DocSpera MR ID",search_in_key="identifier", where="type")
            try:
                logging.info(docspera_id)
                logging.info("moving to look up file")
                move_to_look_up_file(dsep_patient_id, "None", docspera_id, None)
            except Exception as e:
                logging.info(e)
            return enrich_data
    except Exception as e:
        return { "error", "Invalid input JSON"}

def fetch_npi_files_adls(unbundle_container_client,npi_id):
    blob_structure= "v1/"
    for blob in unbundle_container_client.list_blobs(name_starts_with=blob_structure):
        if f"practitioner/practitioner_{npi_id}" in blob.name:
            return False
    return True


def isPracExists_adls(practitioner_json):
    npi_id,dsep_practitioner_id="",""
    for iterblock in practitioner_json["identifier"]:
        if "National Provider Identifier" in str(iterblock):
            npi_id=iterblock["value"]
            break
    for jterblock in practitioner_json["identifier"]:
        if "DSEP_Practitioner_ID" in  jterblock["system"]:
            dsep_practitioner_id= jterblock["value"]
            break 
    # unbundle_container_client = _create_blob_client(os.environ['EXTERNAL_STORAGE_ACCOUNT_NAME'], os.environ['EXTERNAL_CONNECTION_STRING'])

    unbundle_container_client=_create_blob_client(os.environ['EXTERNAL_STORAGE_ACCOUNT_NAME'], os.environ['VELYS_CONNECTION_STRING']).get_container_client(container=os.environ['DSEP_CONTAINER'],)
    booled=fetch_npi_files_adls(unbundle_container_client,npi_id)
    logging.warning("pracexists")
    return dsep_practitioner_id,npi_id,booled

## confirm changes check adls , then only then proceed
def _practitioner_resource(practitioner_json, txn_id, db_connection):
    logging.info("practitioner_json >>> %s",practitioner_json)
    dsep_practitioner_id,npi_id,booled = isPracExists_adls(practitioner_json)
    logging.warning("dsep_practitioner_id %s",dsep_practitioner_id)
    logging.warning("npi_id %s",npi_id)
    logging.warning("booled %s",booled)

    if booled:

        try:
            if dsep_practitioner_id == "":
                new_dsep_practitioner_id = get_new_patient_id()
                logging.info("new_dsep_practitioner_id %s",new_dsep_practitioner_id)
                new_dsep_identifier =identifier_genetor.dsep_pract_identifier(new_dsep_practitioner_id)
                filename = txn_id + "_" + new_dsep_practitioner_id + ".json"
                #filename = new_dsep_practitioner_id + "/" + txn_id + ".json"
                logging.warning("filename %s",filename)
                if "identifier" not in  practitioner_json:  practitioner_json['identifier'] = []
                practitioner_json['identifier'].insert(0, new_dsep_identifier)
                #practitioner_json['identifier'].append(new_dsep_identifier)
                # Post back to fhir patient resources
                logging.warning("expected >> %s",practitioner_json)
                practitioner_resource_id=practitioner_json["id"]
                post_legacy_fhir._post_practitioner(practitioner_json,f"Practitioner/{practitioner_resource_id}")
                logging.warning("final %s",practitioner_json)
                return practitioner_json
            else:
                resource_type= practitioner_json['resourceType'].lower()
                practitioner_resource_id=practitioner_json["id"]
                filename = txn_id + "_" + dsep_practitioner_id + ".json"
                #filename = dsep_practitioner_id + "/" + txn_id + ".json"
                enrich_data = swap_fhir_id(practitioner_json, practitioner_resource_id, dsep_practitioner_id,practitioner_json['resourceType'])
                move_bundle_to_client_container_practitioner((enrich_data), txn_id, filename, practitioner_resource_id, resource_type, dsep_practitioner_id, npi_id, db_connection)
                move_bundle_s3(enrich_data, filename, txn_id,resource_type,db_connection)
                logging.warning("final %s",enrich_data)
                return enrich_data
        except Exception as e:
            return practitioner_json

def get_vendor_oid(oraganization_json):
    vendor_oid = ""
    for iterblock in oraganization_json["identifier"]:
        if "OID_for_DocSpera" in str(iterblock):
            vendor_oid=iterblock["value"][8:]
            return vendor_oid

def _organization_resource(oraganization_json,txn_id, db_connection):
    logging.warning("oid_resource %s",oraganization_json["id"])
    oid_resource=oraganization_json["id"]
    resource_type = oraganization_json['resourceType'].lower()
    try:
        coordination_consent=check_care_coordination_consent(oraganization_json)
    except:
        coordination_consent = False
    dsp_org_id = isValueExists(oraganization_json, "DSEP")
    try:
        if dsp_org_id == "":
            dsp_org_id = get_new_patient_id()
            new_dsep_identifier =  identifier_genetor.org_identifier(dsp_org_id)
            #filename = new_dsep_patient_id + "/" + txn_id + ".json"
            if "identifier" not in oraganization_json: oraganization_json['identifier'] = []
            oraganization_json['identifier'].insert(0, new_dsep_identifier)
            #post_legacy_fhir._post_patient(patient_json, f"Patient/{patient_internal_id}")
            #return patient_json
    except Exception as e:
        logging.info(e)
        pass
    vendor_oid = get_vendor_oid(oraganization_json)
    filename = txn_id + "_" +  oid_resource + ".json"
    #filename = oid_resource + "/" + txn_id + ".json"
    logging.info(filename)
    enrich_data = swap_fhir_id(oraganization_json, oid_resource, dsp_org_id,oraganization_json['resourceType'])
    move_bundle_to_client_container_org((enrich_data), txn_id, filename, resource_type, oid_resource, vendor_oid, coordination_consent,dsp_org_id, db_connection)
    if coordination_consent == True: move_bundle_s3(enrich_data, filename, txn_id,resource_type,db_connection)
    logging.warning(enrich_data)
    return enrich_data

def _medication_resource(medication_json,txn_id, resource_type, db_connection):
    logging.warning("oid_resource %s",medication_json["id"])
    r_type= medication_json['resourceType'].lower()
    med_resource=medication_json["id"]
    dsp_med_id = isValueExists(medication_json, "DSEP")
    try:
        if dsp_med_id == "":
            dsp_med_id = get_new_patient_id()
            new_dsep_identifier =  identifier_genetor.med_identifier(dsp_med_id)
            if "identifier" not in medication_json: medication_json['identifier'] = []
            medication_json['identifier'].insert(0, new_dsep_identifier)
            #post_legacy_fhir._post_patient(patient_json, f"Patient/{patient_internal_id}")
            #return patient_json
    except Exception as e:
        logging.info(e)
        pass
    try:
        filename = txn_id + "_" + med_resource + ".json"
        #filename = oid_resource + "/" + txn_id + ".json"
        enrich_data = swap_fhir_id(medication_json, med_resource, dsp_med_id,medication_json['resourceType'])
        move_bundle_to_client_container_med(enrich_data, txn_id, filename, r_type, med_resource,dsp_med_id,db_connection)
        move_bundle_s3(enrich_data, filename, txn_id,"medication",db_connection)
        logging.warning(enrich_data)
        return enrich_data   
    except Exception as e:
        logging.info("medication exception")
        return medication_json
    
        

