import logging
from benedict import benedict
import json
from azure.storage.blob import BlobServiceClient, BlobClient, ContentSettings
import os

search_string_present_but_null = "__search-string-present-but-null__"

def _create_blob_client(storage_account_name, connection_string):
    account_url = f'https://{storage_account_name}.blob.core.windows.net/'
    logging.info('%s', account_url)
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    return blob_service_client

def gen_dict_extract(extract_from_dict, key):
    try:
        if hasattr(extract_from_dict, 'items'):
            for k, v in extract_from_dict.items():
                if k.lower() == key:
                    yield v
                if isinstance(v, dict):
                    for result in gen_dict_extract(v, key):
                        yield result
                elif isinstance(v, list):
                    for d in v:
                        for result in gen_dict_extract(d, key):
                            yield result
    except Exception as e:
        logging.error(e)


def search_json(json_to_search, search_string="",
                search_in_key="", where=""):
    if search_string:
        normalized_search_string = ''.join(filter(str.isalnum, search_string.lower().replace(" ", "")))
        return_string = ""
        for i in gen_dict_extract(json_to_search, search_in_key):
            try:
                if isinstance(i, list) and isinstance(i[0], dict):
                    for index, j in enumerate(i):

                        if not where:
                            normalized_strings_in_list = list(
                                map(lambda x: ''.join(filter(str.isalnum, x.lower().replace(" ", ""))),
                                    filter(lambda y: isinstance(y, str), i[index].values())))
                        else:
                            normalized_strings_in_list = list(
                                map(lambda x: ''.join(filter(str.isalnum, x.lower().replace(" ", ""))),
                                    filter(lambda y: isinstance(y, str), i[index][where].values())))

                        if normalized_search_string in normalized_strings_in_list:
                            logging.info('%s', j)
                            if not i[index]['value']:
                                return search_string_present_but_null
                            return i[index]['value']

                elif isinstance(i, dict):
                    if not where:
                        normalized_strings_in_dict = list(
                            map(lambda x: ''.join(filter(str.isalnum, x.lower().replace(" ", ""))),
                                filter(lambda y: isinstance(y, str), i.values())))
                    else:
                        normalized_strings_in_dict = list(
                            map(lambda x: ''.join(filter(str.isalnum, x.lower().replace(" ", ""))),
                                filter(lambda y: isinstance(y, str), i[where].values())))

                    if normalized_search_string in normalized_strings_in_dict:
                        if not i['value']:
                            return search_string_present_but_null
                        return i['value']
            except AttributeError:
                pass
            except IndexError:
                pass
            except KeyError:
                pass
        return return_string

def create_jdcosp_dict(param_uuid, practitioner_id, docspera_id, is_single_practitioner):
    jdocsp_dict = {}
    jdocsp_details = {}
    if is_single_practitioner:
        jdocsp_details["dsep_practitioner_id"] = practitioner_id
    else:
        jdocsp_details["docspera_id"] = docspera_id
        jdocsp_details["dsep_patient_id"] = param_uuid
    # jdocsp_dict[docspera_id] = jdocsp_details
    return jdocsp_details

def _get_blob_data(container_client, blob_name):
    blob_client = container_client.get_blob_client(blob=blob_name)
    raw_data = blob_client.download_blob().readall()
    return raw_data

def _save_to_container(data, container_client, blob_name):
    cnt_settings = ContentSettings(content_type="application/json")
    blob_client = container_client.get_blob_client(blob=blob_name)
    blob_client.upload_blob(data, content_settings=cnt_settings, overwrite=True)




def s3_lookup_check(search_id,json_dict):
        try:
            d = benedict(json.dumps(json_dict))
            if search_id  != None : r =  d.search(search_id, in_keys=False, in_values=True, exact=True, case_sensitive=False) 
            if len(r)>0:
                return r[0][-1]
            return False
        except:
            pass



def move_to_look_up_file(param_uuid, practitioner_id, docspera_id, is_single_practitioner):
    dsep_initial_dir = "v1"
    oid = os.environ["DOCSPERA_OID"]
    lookup_filename = "docspera_id_lookup.json"
    dsp_velys_blob_client = _create_blob_client(os.environ['VELYS_STORAGE_ACCOUNT_NAME'],
                                            os.environ['VELYS_CONNECTION_STRING'])
    unbundle_container_client = dsp_velys_blob_client.get_container_client(container=os.environ['DSEP_CONTAINER'])
    jdocsp_dict = create_jdcosp_dict(param_uuid, practitioner_id, docspera_id, is_single_practitioner)
    json_dict = (_get_blob_data(unbundle_container_client, f"{dsep_initial_dir}/{oid}/{lookup_filename}"))
    logging.warn("------------------BEFORE APPENDING-------------------")
    try:
        json_dict = json.loads(json.loads(json.dumps(json_dict)))
    except:
        json_dict = json.loads(json.loads(json.dumps(json_dict.decode("utf-8"))))
    a = s3_lookup_check(param_uuid,json_dict)
    if not a:
        logging.info("no dsep found")
        json_dict.append(jdocsp_dict)
        logging.info(json_dict)
        _save_to_container(json.dumps(json_dict), unbundle_container_client,
                        f"{dsep_initial_dir}/{oid}/{lookup_filename}")
