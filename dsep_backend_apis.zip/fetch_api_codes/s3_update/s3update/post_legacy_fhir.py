import json
import os
import logging
from boto3 import resource
import requests


def _get_headers():
    return {
    'PurposeOfUse': os.environ["PURPOSE_OF_USE"],
    'UserID': os.environ["USER_ID"],
    'Source': os.environ["SOURCE"],
    'Product': os.environ["PRODUCT"],
    'Application': os.environ["APPLICATION"],
    'Content-Type': os.environ["CONTENT_TYPE"],
    'Authorization': 'Bearer ' + _generate_jwt()
    }

def _generate_jwt():
    url = os.environ["GENERATE_JWT_URL"]
    payload={}
    headers = {
    'client_id': os.environ["CLIENT_ID"],
    'client_secret': os.environ["CLIENT_SECRET"]
    }
    response = requests.request("GET", url, headers=headers, data=payload)
    logging.info(response.headers)
    return response.headers['jwt-token']

def _get_patient_resources(url_params):
    url = os.environ["FHIR_PATIENT_URL"]
    payload = json.dumps({
    "resourceType": "Bundle",
    "id": "bundle-transaction",
    "type": "transaction",
    "entry": [
        {
        "request": {
            "method": "GET",
            "url": url_params
        }
        }
    ]
    })
    response = requests.request("POST", url, headers=_get_headers(), data=payload)
    bundle = response.json()
    logging.info(bundle["resourceType"])
    logging.info(bundle["entry"][0]["resource"])
    patient_json = bundle["entry"][0]["resource"]
    return patient_json

def _post_patient(data, url_params):
    logging.info("post data >> " + json.dumps(data))
    url = os.environ["FHIR_PATIENT_URL"]
    response = ""
    if(data):
        payload = {
        "resourceType": "Bundle",
        "id": "bundle-transaction",
        "type": "transaction",
        "entry": [{ "resource" : data
            ,"request": {
                "method": "PUT",
                "url": url_params
            }
        }]
        }
        print("payload 1>> " + str(payload))
        print("payload 2>> " + json.dumps(payload))
        try:
            response = requests.request("POST", url, headers=_get_headers(), data=json.dumps(payload))
            logging.info(response.text)
            return json.dumps(response.text)
        except:
            logging.info("Post to legacy FHIR Error")
    return json.dumps(response)

def _post_practitioner(resource, url_params):
#TODO env variable have to be created for "url"
    url = os.environ["FHIR_PRACTITIONER_URL"]
    response = ""
    try:
        data_push=resource
    except:
        data_push=resource["resource"]
    if(resource):
        payload ={
        "resourceType": "Bundle",
        "id": "bundle-transaction",
        "type": "transaction",
        "entry": [{ "resource" : data_push
            ,"request": {
                "method": "PUT",
                "url": url_params
            }
        }]
        }
        print("payload 1>> " + str(payload))
        print("payload 2>> " + json.dumps(payload))
        try:
            logging.info("Sync Fhir Legacy. Payload: ", payload)
            response=requests.post( url, headers=_get_headers(), json=payload )
            logging.info(" payload_res : %s",response.text)
            print(response.text)
            return json.dumps(response.text)
        except:
            print("Post to legacy FHIR Error")
            logging.exception("Error Message: ")
    return json.dumps(response)

