def dsep_pat_identifier(new_dsep_patient_id):
    return {
        "system": "DSEP_Patient_ID",
        "value": str(new_dsep_patient_id),
        "assigner": {
            "reference": "DSEP"
        }
    }


def dsep_pract_identifier(new_dsep_practitioner_id):
    return {
        "system": "DSEP_Practitioner_ID",
        "value": str(new_dsep_practitioner_id),
        "assigner": {
            "reference": "DSEP"
        }
    }


def docspera_identifier(resource_id,r_type):
    return {
        "system": f"FHIR_{r_type}_ID",
        "value": str(resource_id),
        "assigner": {
            "reference": "VELYS"
        }
    }


def fhir_identifer(resource_type):
    return {
        "system": f"FHIR_{resource_type}_ID",
        "value": str(id),
        "assigner": {
            "reference": "VELYS"
        }
    }


def med_identifier(dsp_med_id):
    return {
        "system": "DSEP_Medication_ID",
        "value": str(dsp_med_id),
        "assigner": {
            "reference": "DSEP"
        }
    }


def new_resource_identifier(resource_type, new_dsp_resource_id):
    return {
        "system": f"DSP_{resource_type}_ID",
        "value": str(new_dsp_resource_id),
        "assigner": {
            "reference": "DSP"
        }
    }


def org_identifier(dsp_org_id):
    return {
        "system": "DSEP_Organization_ID",
        "value": str(dsp_org_id),
        "assigner": {
            "reference": "DSEP"
        }
    }
