import logging
import requests
import os,json
# from azure.identity import ManagedIdentityCredential
# from azure.keyvault.secrets import SecretClient

class Helper:
    def __init__(self):
        logging.warning("this is adl helper")
 
    def utils_generate_jwt(self,app_settings_dict,client_name):
        url = app_settings_dict[f'{client_name}_GENERATE_JWT_URL']
        payload = {}
        headers = {
            # 'client_id': app_settings_dict[f'{client_name}_CLIENT_ID'],
            'client_id': os.environ['CLIENT_ID'],
            # 'client_secret':app_settings_dict[f'{client_name}_CLIENT_SECRET']
            'client_secret':os.environ['CLIENT_SECRET']
        }
        response = requests.request("GET", url, headers=headers, data=payload)
        logging.info(response.headers)
        return response.headers['jwt-token']

    def utils_generate_payload_headers(self,url_params,app_settings_dict,client_name):
        payload = json.dumps({
            "resourceType": "Bundle",
            "id": "bundle-transaction",
            "type": "transaction",
            "entry": [
                {
                    "request": {
                        "method": "GET",
                        "url": url_params
                    }
                }
            ]
        })

        headers = {
            'PurposeOfUse':app_settings_dict[f"{client_name}_PURPOSE_OF_USE"],
            'UserID': app_settings_dict[f"{client_name}_USER_ID"],
            'Source': app_settings_dict[f"{client_name}_SOURCE"],
            'Product': app_settings_dict[f"{client_name}_PRODUCT"],
            'Application': app_settings_dict[f"{client_name}_APPLICATION"],
            'Content-Type': app_settings_dict[f"{client_name}_CONTENT_TYPE"],
            'Authorization': 'Bearer ' + self.utils_generate_jwt(app_settings_dict,client_name)
        }

        return payload, headers

    # def decrypt_appsettings(self, s):
    #     s = (s.split("("))[1].split(")")[0]
    #     s = s.split(";")
    #     s0 = s[0].split("=")
    #     s1 = s[1].split("=")
    #     logging.info(s0[1])
    #     logging.info(s1[1])
    #     KVUri = f"https://{s0[1]}.vault.azure.net"
    #     logging.info(KVUri)
    #     managed_identity = ManagedIdentityCredential()
    #     client = SecretClient(vault_url=KVUri, credential=managed_identity)
    #     retrieved_secret = client.get_secret(s1[1])
    #     secret_value = retrieved_secret.value
    #     logging.warning(secret_value)
    #     return secret_value


Adl_Helper_Obj = Helper()