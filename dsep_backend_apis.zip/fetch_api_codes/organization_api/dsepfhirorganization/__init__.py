import json,os
import logging
import azure.functions as func
from .organization import OrganizationFetch
from . organization_mysql import OrganizationFetchD4C
from .Db_Helper import DBHelper,AppSettings
from .Helper import Common
# Using the class in a function


db_connection = DBHelper()
app_settings = AppSettings()
organization_fetch_d4c = OrganizationFetchD4C()
organization_fetch = OrganizationFetch()
helper = Common()

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    url_address = str(req.url)
    resources_append=[]
    # organization_id=req.route_params.get('organization_id')
    organization_id,resource_type,resource_id = helper.dsep_search(req)
    oid = helper.jwt_decoder(req)
    if oid == None:
        oid = req.params.get('oid')  
    if oid == None:
        return func.HttpResponse(json.dumps({"error": "oid must be needed"}), status_code=400, mimetype="application/json")
    app_settings_dict=None
    client_name=None
    try:
        app_settings_dict,client_name = app_settings.getappset_with_oid(oid)
    except Exception as e :
        logging.warn(e)
    oid_url_param=app_settings_dict[f"{client_name}_OID_SEARCH_QUERY"]
    urn_oid_url_param=app_settings_dict[f"{client_name}_URN_OID_SEARCH_QUERY"]
    oid_base_url= app_settings_dict[f"{client_name}_LEGACY_API_URL_ORG"]
    all_org_param = app_settings_dict[f"{client_name}_ALL_ORG_QUERY"]
    d4c= True
    if "?"in url_address:
        splited_url=(url_address.lower()).split('?')[0].split("/")
    else:
        splited_url=(url_address.lower()).split('/')
    if 'adls' in splited_url: d4c = False
    if d4c:
        org_data = organization_fetch_d4c.fetch_organization(organization_id,db_connection)
        if len(org_data) != 0:
            return func.HttpResponse(json.dumps(organization_fetch.output_format(org_data)), status_code=200, mimetype="application/json")
        else:
            return func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}), status_code=400, mimetype="application/json")
        
    try:
        if organization_id == None:
            organization_data=organization_fetch.generate_org_data(organization_id, all_org_param, oid_base_url,app_settings_dict,client_name)
        elif "." in organization_id:
            organization_data=organization_fetch.generate_org_data(organization_id, urn_oid_url_param, oid_base_url,app_settings_dict,client_name)
        else:
            organization_data=organization_fetch.generate_org_data(organization_id,oid_url_param,oid_base_url,app_settings_dict,client_name)

        if organization_id != None:
            logging.info('not nice')
            organization_data=organization_data["entry"][0]["resource"]["entry"][0]["resource"]
            #organization_urn_oid = organization_data["identifier"][0]["value"]
            #organization_id = organization_urn_oid.split(':')[2]
            # organization_resource_id=organization_data["id"]
            resources_append.append({"resource":organization_data})
            return func.HttpResponse(json.dumps(organization_fetch.output_format(resources_append)), status_code=200, mimetype="application/json")
        else:
            for organization in organization_data["entry"][0]["resource"]["entry"]:
                resources_append.append({"resource":organization["resource"]})           
            return func.HttpResponse(json.dumps(organization_fetch.output_format(resources_append)), status_code=200, mimetype="application/json")

    except:
        error_response = {
                        "result": app_settings_dict[f"{client_name}_INVALID_INPUT_ROUTE"]
                    }
        return func.HttpResponse(json.dumps(error_response), status_code=400, mimetype="application/json")
