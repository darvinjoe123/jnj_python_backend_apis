from .Helper import *
from .Adl_Helper import *
import logging
from fhir.resources.organization import Organization

helper=Helper()

class OrganizationFetch:
    def __init__(self):
        logging.warn("this is OrganizationFetch")

    def generate_org_data(self,oid,url_param,base_url,app_settings_dict,client_name):
        payload,headers=helper.utils_generate_payload_headers(url_param.format(oid=oid),app_settings_dict,client_name)
        url = base_url
        response = requests.request("POST", url, headers=headers, data=payload)
        bundle = json.loads(response.text)
        return bundle

    def check_care_coordination_consent(self,bundle_data):
        bundle = Organization(**bundle_data)
        if bundle.resource_type == "Organization":
            logging.info("bundle.extension >> %s",bundle.extension[0].url)
            if bundle.extension[0].url== os.environ["CARE_CONSENT_URL"]:
                    return  bundle.extension[0].valueBoolean

    def processed_data(self,data):
        if 'resource' in data:
            return data
        return {"resource": data}

    def output_format(self,list):
        return {
            "resourceType": "Bundle",
            "type": "transaction-response",
            "entry": list
        }
