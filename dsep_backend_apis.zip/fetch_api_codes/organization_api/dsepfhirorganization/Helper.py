import logging
import json
import jwt


class Common:
    def __init__(self):
        logging.warn("this is helper")

    def oid_req(self,req_json):
        try:
            oid = json.loads(req_json)["oid"]
        except:
            oid=None
        return oid

    def dsep_search(self,req):
        try:
            organization_id=req.route_params.get("organization_id")
            if organization_id.lower() == "adls": organization_id=None
        except: organization_id=None
        logging.info(organization_id)
        try:
            resource_type = req.route_params.get("resource_type").lower()
            if resource_type == "adls": resource_type=None
        except: resource_type = None
        try:
            resource_id = req.route_params.get("resource_type_id")
            if  resource_id.lower() == "adls":  resource_id=None
        except: resource_id = None 
        return organization_id, resource_type, resource_id

    def jwt_decoder(self,req):
        try:
            token= req.headers['Authorization'].lstrip('Bearer').strip()
            token_decode = jwt.decode(token, options={"verify_signature": False})
            oid = token_decode["oid"]
        except:
            oid = None
        return oid 

    def run_format(self,data_bundles):
        output={
                "resourceType": "Bundle",
                "type": "transaction-response",
                "entry": data_bundles,

                }
        return output
