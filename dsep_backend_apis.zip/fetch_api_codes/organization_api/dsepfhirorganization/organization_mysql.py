
import json
import logging


without_id_query_org = "(SELECT resource_json FROM (SELECT resource_json, ROW_NUMBER() OVER (PARTITION BY system_oid ORDER BY modified_on desc, id desc ) AS RowNo FROM d4c_fhir_datastore.organization) x WHERE x.RowNo = 1)"
organization_query =  "(SELECT resource_json FROM d4c_fhir_datastore.organization where (system_oid = '{org_id}' or lmi_resource_id = '{org_id}' or dsp_resource_id = '{org_id}') order by modified_on desc, id desc limit 1)"
# organization_urn_oid_query = "SELECT * FROM d4cfhir where resource_type = 'organization' and resource_json ->>'$.resource.identifier[0].value' = 'urn:oid:"

# without_id_query        = "(SELECT resource_json FROM (SELECT resource_json, ROW_NUMBER() OVER (PARTITION BY dsp_practitioner_id ORDER BY modified_on desc, id desc ) AS RowNo FROM d4c_fhir_datastore.practitioner) x WHERE x.RowNo = 1)"
# practitioner_query      = "(SELECT resource_json FROM d4c_fhir_datastore.practitioner where (dsp_practitioner_id = {dsp_prac_id} or npi = {dsp_prac_id}) order by modified_on desc, id desc limit 1)"
# practitioner_oid_query  = "(SELECT resource_json FROM d4c_fhir_datastore.practitioner where (dsp_practitioner_id = {dsp_prac_id} or npi = {dsp_prac_id} ) and system_oid = {s_oid} order by modified_on desc, id desc limit 1)"

class OrganizationFetchD4C:
    def __init__(self):
        logging.warn("this is OrganizationFetchD4C")

    def fetch_organization(self,organization_id,db_connection):# used to get data from Mysql d4cfhir
        try:
            formatted_files_list = []
            if organization_id is None:
                query = without_id_query_org
                logging.info(query)
                db_connection._cursor.execute(query, None)
                df = db_connection._cursor.fetchall()
                if len(df) > 0:
                    for data in df:
                        formatted_files_list.append(json.loads(str(data['resource_json'])))
                return formatted_files_list
            else:
                query = organization_query.format(org_id = organization_id )
                logging.info(query)
                db_connection._cursor.execute(query, None)
                df = db_connection._cursor.fetchall()
                if len(df) > 0:
                    for data in df:
                        formatted_files_list.append(json.loads(str(data['resource_json'])))
                return formatted_files_list 
        except Exception as e:
            logging.info(e)
            formatted_files_list = []
            return formatted_files_list
        finally:db_connection._connection.close()
