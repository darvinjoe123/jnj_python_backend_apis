import logging
from azure.storage.blob import BlobServiceClient
from azure.identity import ManagedIdentityCredential
from azure.keyvault.secrets import SecretClient
from datetime import datetime
import re
import json


class AdlHelper:
    def __init__(self):
        logging.warning("this is adl helper")

    def create_blob_client(self,storage_account_name, connection_string):
        # account_url = f'https://{storage_account_name}.blob.core.windows.net/'
        # logging.info("credentials >> " + str(credential.get_token))
        blob_service_client = BlobServiceClient.from_connection_string(connection_string)
        # BlobServiceClient(account_url=account_url, credential=credential)
        return blob_service_client

    def get_lastmodified_files(self,epoch_from, epoch_to, connection_instance, azure_acc_url, container_name, blob_path):
        try:
            blob_name_list = []
            source_blob_list = connection_instance.list_blobs()   # name_starts_with=blob_path

            org_id = blob_path.rsplit('/', 1)[1]
            epoch_from = int(epoch_from)
            epoch_to = round(epoch_to)
            for blob in source_blob_list:
                if ('.json' in blob.name):
                    if (float(datetime.timestamp(blob['last_modified']) >= epoch_from)):
                        if (datetime.timestamp(blob['last_modified']) < epoch_to):
                            blob_dict = {}
                            logging.info("inside if blob name >> " + blob.name)
                            resource_types = ['allergyintolerance', 'appointment', 'condition', 'coverage', 'device', 'diagnosticreport',
                                            'encounter', 'immunization', 'medication', 'medicationadministration', 'medicationrequest',
                                            'medicationstatement', 'observation', 'organization', 'patient', 'practitioner', 'practitionerrole',
                                            'procedure', 'servicerequest', 'specimen', 'location']
                            non_fhir_resources = ["checklist", "intake", "intake_smart_scheduler"]
                        # hard coded docspera_id_lookup
                            if (f"/{org_id}/") in blob.name and ("docspera_id_lookup" not in blob.name):
                                if any(resource+"_" in blob.name for resource in resource_types):
                                    try:
                                        for i in range(len(resource_types)):
                                            if resource_types[i] in blob.name:
                                                resource_json = blob.name
                                                blob_dict["resource"] = f'{resource_types[i]}'
                                                blob_dict["url"] = azure_acc_url + container_name + resource_json
                                                try:
                                                    patient_id = re.search(f'{resource_types[i]}_(.*).json', resource_json)[1]
                                                except Exception as e:
                                                    logging.info(e)
                                                    patient_id = re.search('/(.*).json', resource_json)[1].rsplit("/")[-1].rsplit("_")[-1]
                                                blob_dict['id'] = patient_id
                                    except Exception as e:
                                        logging.info(e)
                                        blob_dict["result"] = "failure"
                                        blob_dict["blob"] = blob.name

                                elif any(resource in blob.name for resource in non_fhir_resources):
                                    try:
                                        for i in range(len(non_fhir_resources)):
                                            if non_fhir_resources[i] in blob.name:
                                                resource_json = blob.name
                                                blob_dict["resource"] = f'{non_fhir_resources[i]}'
                                                blob_dict["url"] = azure_acc_url+container_name+resource_json
                                                try:
                                                    patient_id = re.search(f'{non_fhir_resources[i]}_(.*).json', resource_json)[1]
                                                except Exception as e:
                                                    logging.info(e)
                                                    patient_id = re.search('/(.*).json', resource_json)[1].rsplit("/")[-1].rsplit("_")[-1]
                                                blob_dict['id'] = patient_id

                                    except Exception as e:
                                        logging.info(e)
                                        blob_dict["result"] = "failure"
                                        blob_dict["blob"] = blob.name

                                else:
                                    try:
                                        resource_json = blob.name
                                        blob_dict["resource"] = 'patient'
                                        blob_dict["url"] = azure_acc_url+container_name+resource_json
                                        patient_id = re.search('/(.*).json', resource_json)[1].rsplit("/")[-1]
                                        blob_dict['id'] = patient_id
                                    except Exception as e:
                                        logging.info(e)
                                        blob_dict["result"] = "failure"
                                        blob_dict["blob"] = blob.name
                                blob_name_list.append(blob_dict)

            resource_count = len(blob_name_list)
            output = {"org_id": org_id,
                    "epoch_from": epoch_from,
                    "epoch_to": epoch_to,  # Capture the time of the request ad make that epoch_to.
                    "resource_count": resource_count,
                    # "last modified" :datetime.timestamp(blob['last_modified']) ,
                    "blob_name": blob_name_list
                    }
            return json.dumps(output)

        except Exception as ex:
            logging.error("Error: " + str(ex))


    def decrypt_appsettings(self, s):
        s = (s.split("("))[1].split(")")[0]
        s = s.split(";")
        s0 = s[0].split("=")
        s1 = s[1].split("=")
        logging.info(s0[1])
        logging.info(s1[1])
        KVUri = f"https://{s0[1]}.vault.azure.net"
        logging.info(KVUri)
        managed_identity = ManagedIdentityCredential()
        client = SecretClient(vault_url=KVUri, credential=managed_identity)
        retrieved_secret = client.get_secret(s1[1])
        secret_value = retrieved_secret.value
        logging.warning(secret_value)
        return secret_value
