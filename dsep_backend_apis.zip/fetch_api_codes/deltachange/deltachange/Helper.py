import logging
import json
import jwt


class Common:
    def __init__(self):
        logging.warn("this is helper")

    def oid_req(req_json):
        try:
            oid = json.loads(req_json)["oid"]
        except:
            oid=None
        return oid


    def jwt_decoder(self,req):
        try:
            token= req.headers['Authorization'].lstrip('Bearer').strip()
            token_decode = jwt.decode(token, options={"verify_signature": False})
            oid = token_decode["oid"]
        except:
            oid = None
        return oid 

    def run_format(self,data_bundles):
        output={
                "resourceType": "Bundle",
                "type": "transaction-response",
                "entry": data_bundles,

                }
        return output
