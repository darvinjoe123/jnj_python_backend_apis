import logging
from .delta_api_constants import *

velys_query_dict = {
                         
	'query_subresource': QUERY_SUBRESOURCE,
	'query_patient': QUERY_PATIENT,
    'query_master': QUERY_MASTER,
    'query_non_fhir': QUERY_NON_FHIR,
    'query_practitioner': QUERY_PRACTITIONER
}
                    

def query_executor(db_connection, query):
    try:
        db_connection._cursor.execute(query, None)
        logging.info(query)
        fetch = db_connection._cursor.fetchall()
        return fetch
    except Exception as e:
        logging.info(e)
        pass

    

def fetch_delta_change(db_connection, name, epoch_from, future_epoch,app_settings_dict,client_name):
    try:
        query = ""
        formatter_dict_basic = {'epoch_time': str(epoch_from) ,'s_oid': str(name) }
        for table in resources_list:
            query = query + velys_query_dict['query_subresource'].format(t_name=table,**formatter_dict_basic) if len(query) == 0 else query + ' UNION ' + velys_query_dict['query_subresource'].format(t_name=table,**formatter_dict_basic)
        query = query + velys_query_dict['query_patient'].format(**formatter_dict_basic) if len(query) == 0 else query + ' UNION ' + velys_query_dict['query_patient'].format(**formatter_dict_basic)
        query = query + velys_query_dict['query_master'].format(**formatter_dict_basic) if len(query) == 0 else query + ' UNION ' + velys_query_dict['query_master'].format(**formatter_dict_basic)
        query = query + velys_query_dict['query_non_fhir'].format(**formatter_dict_basic) if len(query) == 0 else query + ' UNION ' + velys_query_dict['query_non_fhir'].format(**formatter_dict_basic)
        query = query + velys_query_dict['query_practitioner'].format(**formatter_dict_basic) if len(query) == 0 else query + ' UNION ' + velys_query_dict['query_practitioner'].format(**formatter_dict_basic)
        blob_name = [] 
        logging.info(query)
        result = query_executor(db_connection, query)
        if len(result) > 0:
            for data in result:
                if data['resource_type'].lower() in master_list:
                    data_json = {
                                "resource": data['resource_type'],
                                "id": data['vendor_resource_id'],
                                "transaction_id": data['transaction_id']
                                }
                elif data['resource_type'].lower() in nonfhir_list:
                    data_json = {
                                 "resource": data['resource_type'],
                                 "transaction_id": data['transaction_id']
                                }
                elif data['resource_type'].lower() in practitioner_list:
                    data_json = {
                                 "resource": data['resource_type'],
                                 "dsp_practitioner_id": data['dsp_practitioner_id'],
                                 "npi":  data['npi']
                                 }
                elif data['resource_type'].lower() in patient_list:
                    data_json = {
                                "resource": data['resource_type'],
                                "dsp_patient_id": data['dsp_patient_id'],
                                "mrn": data["mrn"],
                                "organization_oid": data['organization_oid']
                                }
                elif data['resource_type'].lower() in resources_list:
                    data_json = {
                                "resource": data['resource_type'],
                                "id": data['vendor_resource_id'],
                                "dsp_patient_id": data['dsp_patient_id'],
                                f"dsp_{data['resource_type']}_id": data['dsp_resource_id']
                                }
      
                blob_name.append(data_json)
        result_json = {"org_id": name, "epoch_from": epoch_from,"epoch_to":  future_epoch, "resource_count": len(result),"blob_name": blob_name}
        return result_json

    except Exception as e:
        logging.info(e)
        logging.info(type(e))
        return {"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}
    finally:
        db_connection._connection.close()