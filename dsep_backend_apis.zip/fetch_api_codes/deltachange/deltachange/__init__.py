import logging
import os
import azure.functions as func
from datetime import datetime
import json
from . delta_change_mysql import fetch_delta_change
from . Adl_Helper import AdlHelper
from . Db_Helper import DBHelper,AppSettings
from . Helper import Common



# Using the class in a function
db_connection = DBHelper()
app_settings = AppSettings()
adlhelper = AdlHelper()
common = Common()

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    name = common.jwt_decoder(req)
    logging.info(name)
    if name is None:
        try:
            name = req.params.get('org_id')
        except Exception as e:
            logging.info(e)
            name = None
    if name is None:
        return func.HttpResponse(json.dumps({"error":"System oid needed"}), status_code=400, mimetype="application/json")
    app_settings_dict = None
    client_name = None
    app_settings_dict,client_name = app_settings.getappset_with_oid(name)
    epoch_from = (req.params.get('epoch_from'))
    #d4c = ast.literal_eval(app_settings_dict[f'{client_name}_D4C'])
    d4c = True
    if str(req.route_params.get("mode")).lower() == "adls": d4c=False
    future_epoch = round(datetime.timestamp(datetime.now()))
    if name is not None and epoch_from is not None:
        if (epoch_from.isdigit()) and (int(epoch_from) < (future_epoch)):
            if d4c:
                try:
                    logging.info("d4c_exists")
                    outer = fetch_delta_change(db_connection, name, epoch_from, future_epoch,app_settings_dict,client_name)
                    logging.info("outer")
                    return func.HttpResponse(json.dumps(outer), status_code=200, mimetype="application/json") if "error" not in outer.keys() else func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}), status_code=400, mimetype="application/json")
                except Exception as e:
                    logging.info(e)
                    return func.HttpResponse(json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_INPUT_ROUTE']}), status_code=400, mimetype="application/json")
            if name:
                storage_account_name = app_settings_dict[f"{client_name}_STORAGE_ACCOUNT_NAME"]
                azure_acc_url = 'https://' + storage_account_name + '.blob.core.windows.net'
                dsp_velys_blob_client = adlhelper.create_blob_client(app_settings_dict[f'{client_name}_STORAGE_ACCOUNT_NAME'], os.environ['VELYS_CONNECTION_STRING'])
                dsep_container_client = dsp_velys_blob_client.get_container_client(container=app_settings_dict[f'{client_name}_DSEP_CONTAINER'])
                epoch_from = epoch_from
                output = adlhelper.get_lastmodified_files(epoch_from, future_epoch, connection_instance=dsep_container_client, azure_acc_url=azure_acc_url, container_name='/dsep/', blob_path='/v1/{org_name}'.format(org_name=name))
                if name:
                    return func.HttpResponse(output, mimetype="application/json")
                else:
                    return func.HttpResponse(
                        json.dumps({"error": 'ACCESS_DENIED'}),
                        status_code=200, mimetype="application/json"
                    )
            else:
                return func.HttpResponse(
                        json.dumps({"error": 'ACCESS_DENIED'}),
                        status_code=400, mimetype="application/json"
                    )
        else:
            return func.HttpResponse(
                json.dumps({"error": app_settings_dict[f'{client_name}_INVALID_EPOCH']}),
                status_code=400, mimetype="application/json"
            )
    else:
        return func.HttpResponse(
            json.dumps({"error":  app_settings_dict[f'{client_name}_EMPTY_RESOURCE_ERROR']}),
            status_code=400, mimetype="application/json"
        )