import datetime
import logging
import os 
from pytz import timezone

db_details = os.environ['DB_DETAILS'].split(',')

insert_d4cfhir_query ="INSERT INTO d4c_fhir_datastore.patient (system_oid, organization_oid, resource_id, dsp_patient_id, mrn, resource_type, resource_json, transaction_id, vendor_name, created_on, modified_on) VALUES"


update_d4cfhir_query = "UPDATE d4c_fhir_datastore.patient SET system_oid = %s, organization_oid = %s, vendor_resource_id = %s, dsp_patient_id = %s, mrn = %s, resource_type = %s, resource_json = %s, transaction_id = %s,vendor_name = %s , modified_on = %s  WHERE id = %s;"

select_by_patient_id_query ="SELECT id from d4c_fhir_datastore.patient where vendor_resource_id = {} and dsp_patient_id = {} and resource_type = {} order by modified_on desc, id desc limit 1"

insert_common_query = "INSERT INTO common (mrn, vendor_name, resource_json, created_on) VALUES"

update_common_query = "UPDATE common SET mrn = %s, vendor_name = %s , resource_json = %s WHERE id = %s;"

select_by_mrn_id_query = "SELECT id from common where mrn = {} order by modified_on desc, id desc limit 1"

def get_date():
    tz = timezone('US/Eastern')
    time_stamp = str(datetime.datetime.now(tz))[:-13]
    return time_stamp

def _save_to_d4cfhirdatastore(oid, organization_oid, resource_id, dsp_patient_id, mrn, npi, dsp_practitioner_id,
                              resource_type, resource_json, transaction_id, nonfhir_filename,db_connection):
    logging.info("Saving to d4c fhir database")
    dt = datetime.datetime.now()
    formatted_date = dt.strftime('%Y-%m-%d %H:%M:%S')
    formatted_day = dt.strftime('%A : %Y-%m-%d %H:%M:%S')
    columns = {}
    columns["system_oid"] = oid
    columns["organization_oid"] = organization_oid
    columns["resource_id"] = resource_id
    columns["dsp_patient_id"] = dsp_patient_id
    columns["mrn"] = mrn
    columns["resource_type"] = resource_type
    columns["resource_json"] = resource_json
    columns["transaction_id"] = transaction_id
    columns["vendor_name"] = "Legacy"
    columns["created_on"] = get_date() 
    columns["modified_on"] = get_date() 
    logging.info("Values set to column")
    logging.info("Sql connection successful...")
    #id_value = _patient_exists(db_connection, resource_id, dsp_patient_id, resource_type)
    # if id_value:
    #     columns["id"] = id_value
    #     value = (
    #         columns["system_oid"],
    #         columns["organization_oid"],
    #         columns["resource_id"],
    #         columns["dsp_patient_id"],
    #         columns["mrn"],
    #         columns["resource_type"],
    #         columns["resource_json"],
    #         columns["transaction_id"],
    #         columns["vendor_name"],
    #         columns["modified_on"],
    #         columns["id"]
            
    #     )
    #     logging.info("Updating column...")
    #     db_connection._cursor.execute(update_d4cfhir_query, value)
    # else:
    value = (
        columns["system_oid"],
        columns["organization_oid"],
        columns["resource_id"],
        columns["dsp_patient_id"],
        columns["mrn"],
        columns["resource_type"],
        columns["resource_json"],
        columns["transaction_id"],
        columns["vendor_name"],
        columns["created_on"],
        columns["modified_on"]
    )
    logging.info("Inserting new data...")
    db_connection._cursor.execute(insert_d4cfhir_query + str(value))
    logging.info("data inserted successfully !! ")
    return "success"


def _patient_exists(db_connection, resource_id, dsp_patient_id, resource_type):
    db_connection._cursor.execute(select_by_patient_id_query.format(str("'") + resource_id + str("'"), str("'") + dsp_patient_id + str("'"), str("'") + resource_type + str("'")))
    logging.info(db_connection._cursor)
    for row in db_connection._cursor.fetchall():
        logging.info("id exists")
        return row["id"]
    return None

def _save_to_common(mrn, resource_json,db_connection):
    logging.info("Saving to common table..")
    columns = {"mrn": mrn, "vendor_name": "DocSpera", "resource_json": resource_json}
    logging.info("values set to column")
    logging.info("Sql connection successful..")
    # id_value = _mrn_exists(db_connection, mrn)
    # if id_value:
    #     columns["id"] = id_value
    #     value = (
    #         columns["mrn"],
    #         columns["vendor_name"],
    #         columns["resource_json"],
    #         columns["id"]
    #     )
    #     logging.info("Updating column...")
    #     db_connection._cursor.execute(update_common_query, value)
    # else:
    value = (
        columns["mrn"],
        columns["vendor_name"],
        columns["resource_json"],
        get_date()
    )
    logging.info("Inserting data")
    db_connection._cursor.execute(insert_common_query + str(value))
    logging.info("data inserted successfully !! ")
    return "success"


def _mrn_exists(db_connection, mrn):
    db_connection._cursor.execute(select_by_mrn_id_query.format(str("'") + mrn + str("'")))
    try:
        for row in  db_connection._cursor.fetchall():
            logging.info("Id exists in common")
            logging.info(row)
            return row["id"]
    except Exception as e:
        logging.info(e)
    return None



