import json
import os
import uuid
import asyncio
import aiohttp
import requests
import logging
from . import app_settings
from . utils import *
from . import utils
from .mrn_mysql_db import *
from .mysqlutils import _save_to_d4cfhirdatastore, _save_to_common
import ast

docsper_oid = os.environ["DOCSPERA_OID"]

def _save_to_container(data, blob_name,app_settings_dict,client_name):
    container_client = utils_create_blob_client(
        app_settings_dict[f'{client_name}_VELYS_CONNECTION_STRING']).get_container_client(container=app_settings_dict[f'{client_name}_DSEP_CONTAINER'])
    blob_client = container_client.get_blob_client(blob=blob_name)
    blob_client.upload_blob(data, overwrite=True)

def s3_save_to_container(data, blob_name,app_settings_dict,client_name):
    container_client = utils_create_blob_client(
        app_settings_dict[f'{client_name}_DOCSPERA_CONNECTION_STRING']).get_container_client(container=app_settings_dict[f'{client_name}_S3_CONTAINER'])
    blob_client = container_client.get_blob_client(blob=blob_name)
    blob_client.upload_blob(data, overwrite=True)

async def fetch_assigner(mrn,oid,data,d4c,db_connection,app_settings_dict,client_name):
    url = app_settings_dict[f"{client_name}_GENERATE_JWT_URL"]
    payload={}
    headers = {
    # 'client_id': app_settings_dict[f"{client_name}_CLIENT_ID"],
    # 'client_secret': app_settings_dict[f"{client_name}_CLIENT_SECRET"]
        'client_id': 'bHsSkEGHMuxRldoycwqSN9nc0dvyggF7',
        'client_secret':'tsF9QYJui7hgqavC'
    }
    response = requests.request("GET", url, headers=headers, data=payload)
    async with aiohttp.ClientSession() as session:
        tasks = []
        if d4c:
            tasks.append(fetch_mrn(mrn, oid, db_connection))
        else:
            tasks.append( _search_mrn_in_adls(mrn, oid,app_settings_dict,client_name))
        if oid == None:
            tasks.append( _search_mrn(mrn, data, response.headers['jwt-token'],app_settings_dict,client_name))
        else:
            tasks.append( _search_mrn_oid(mrn, oid, data, response.headers['jwt-token'],app_settings_dict,client_name))

    responses = await asyncio.gather(*tasks, return_exceptions=True)
    # responses = fetch_mrn(mrn, oid)
    # print(responses)
    return responses

def _generate_jwt(mrn, oid, data, d4c, db_connection,app_settings_dict,client_name):
    try:
        isLegacy = False
        isADLs = False
        responses = asyncio.run(fetch_assigner(mrn,oid,data,d4c,db_connection,app_settings_dict,client_name))
        patient_data_adls=responses[0]
        patient_data=responses[1]
        if patient_data_adls:
            isADLs = True
        patient_data = json.loads(patient_data.text)
        if(patient_data['entry'][0]['resource']['total'] == 1):
            patient_json = patient_data['entry'][0]['resource']['entry'][0]['resource']
            patient_resource_id=str(patient_json["id"])
            dsep_patient_id = isDSEPExists(patient_json, "DSEP")
            if(dsep_patient_id == ""):
                dsep_patient_id = get_new_patient_id(app_settings_dict,client_name)
                new_dsep_identifier = {
                    "system": "DSEP_Patient_ID",
                    "value": str(dsep_patient_id),
                    "assigner":  {
                        "reference": "DSEP"
                    }
                }
                patient_json['identifier'].append(new_dsep_identifier)
                url_params=f"Patient/{patient_resource_id}"
                patient_response_text=utils._post_patient(patient_json, url_params,app_settings_dict,client_name)
            mrn_value = ""
            oid_value = ""
            print("adls>>> ", isADLs)
            if isADLs == False:
                list_assigners = patient_json['identifier']
                for assign in list_assigners:
                    try:
                        if "Medical Record Number".lower() in str(assign["type"]["coding"][0]["display"]).lower():
                            mrn_value = str(assign["value"])
                            oid_value = str(assign["system"]).split(":")[2]

                    except:
                        logging.error("error")
                        continue
                filename = f"v1/{docsper_oid}/{dsep_patient_id}/patient/patient_{dsep_patient_id}_{mrn_value}_{oid_value}.json"

                #internal_oid- inside the patient multiple urn-oid will be there.
                logging.info("save if adls false")
                if d4c:
                    _save_to_d4cfhirdatastore(docsper_oid, oid_value, patient_resource_id, dsep_patient_id, mrn_value, "", "",
                                            "patient", json.dumps(patient_json,sort_keys=False), str(uuid.uuid4()), filename,db_connection)
                _save_to_container(json.dumps(patient_json), blob_name=filename,app_settings_dict=app_settings_dict,client_name=client_name)

            isLegacy = True
            if isLegacy and isADLs:
                list_assigners = patient_json['identifier']
                for assign in list_assigners:
                    try:
                        if "Medical Record Number".lower() in str(assign["type"]["coding"][0]["display"]).lower():
                            mrn_value = str(assign["value"])
                            oid_value = str(assign["system"]).split(":")[2]

                    except:
                        logging.error("error")
                        continue

                common_filename = f"common/{dsep_patient_id}/patient/patient_{dsep_patient_id}_{mrn_value}_{oid_value}.json"
                if d4c:
                    _save_to_common(mrn, json.dumps(patient_json,sort_keys=False),db_connection)
                _save_to_container(json.dumps(patient_json), blob_name=common_filename,app_settings_dict=app_settings_dict,client_name=client_name)

        if isADLs:
            data=data_output_mrn_oid(patient_data_adls)
            return data
        else:
            return patient_data
    except Exception as e:
        logging.info(e)
        pass
    finally:
        db_connection._connection.close()

async def _search_mrn_in_adls(mrn, oid,app_settings_dict,client_name):
    unbundle_container_client = utils_create_blob_client(
        app_settings_dict[f"{client_name}_VELYS_CONNECTION_STRING"]).get_container_client(container=app_settings_dict["{client_name}_DSEP_CONTAINER"])
    for blob in unbundle_container_client.list_blobs() if oid is None else unbundle_container_client.list_blobs(name_starts_with=f"v1/{docsper_oid}"):

        if oid:
            if "_"+mrn+"_" in str(blob.name) and "_"+oid+"." in str(blob.name):
                isADLs = True
                try:
                    data = (json.loads(utils_get_blob_data(
                        unbundle_container_client, blob.name)))
                    return data
                except:
                    logging.error("incorrect_fetch")
        else:
            #if re.match(mrn, blob.name) :
            if "_"+mrn+"_" in str(blob.name):
                isADLs = True
                try:
                    data = (json.loads(utils_get_blob_data(
                        unbundle_container_client, blob.name)))
                    return data
                except:
                    logging.error("incorrect_fetch")


body= {
        "resourceType": "Bundle",
        "id": "bundle-transaction",
        "type": "transaction",
        "entry": [
            {
            "request": {
                "method": "GET",
                "url": ""
            }
            }
        ]
        }


async def _search_mrn_oid(mrn, oid, data, token,app_settings_dict,client_name):
    headers = {
    'PurposeOfUse': app_settings_dict[f"{client_name}_PURPOSE_OF_USE"],
    'UserID': app_settings_dict[f"{client_name}_USER_ID"],
    'Source': app_settings_dict[f"{client_name}_SOURCE"],
    'Product': app_settings_dict[f"{client_name}_PRODUCT"],
    'Application': app_settings_dict[f"{client_name}_APPLICATION"],
    'Content-Type': app_settings_dict[f"{client_name}_CONTENT_TYPE"],
    'Authorization': ""
    }
    url = app_settings_dict[f"{client_name}_MRN_SEARCH_URL"]
    if data:
        payload = json.dumps(data)
    elif "." in oid:
        body["entry"][0]["request"]["url"] = "Patient?identifier=urn:oid:{}|{}".format(oid,mrn)
        payload = json.dumps(body)
    else:
        body["entry"][0]["request"]["url"] = "Patient?organization=Organizaton/{}&identifier={}".format(oid,mrn)
        payload = json.dumps(body)
    headers["Authorization"] = 'Bearer ' + token
    return requests.request("POST", url, headers=headers, data=payload)

async def _search_mrn(mrn, data, token,app_settings_dict,client_name):
    headers = {
    'PurposeOfUse': app_settings_dict[f"{client_name}_PURPOSE_OF_USE"],
    'UserID': app_settings_dict[f"{client_name}_USER_ID"],
    'Source': app_settings_dict[f"{client_name}_SOURCE"],
    'Product': app_settings_dict[f"{client_name}_PRODUCT"],
    'Application': app_settings_dict[f"{client_name}_APPLICATION"],
    'Content-Type': app_settings_dict[f"{client_name}_CONTENT_TYPE"],
    'Authorization': ""
    }
    url = app_settings.mrn_search_url
    if data:
        payload = json.dumps(data)
    else:
        body["entry"][0]["request"]["url"] = "Patient?identifier=" + mrn
        payload = json.dumps(body)
    headers["Authorization"] = 'Bearer ' + token
    return requests.request("POST", url, headers=headers, data=payload)

def check_unbundling_post(patient_json):
    trxn_id= str(uuid.uuid4()) #"b9d6a54f-6ec5-4996-938a-aab402de6eae"
    data={
        "resourceType": "Bundle",
        "identifier": {
            "type": {
                "text": "DocSpera Bundle ID",
                "coding": [
                    {
                        "code": "DSBID",
                        "display": "DocSpera Bundle ID"
                    }
                ]
            },
            "value": trxn_id
        },
        "type": "collection",
        "timestamp": "2022-01-28T22:12:21Z",
        "entry": [
            {
                "resource" : patient_json
            }
        ],
        "request": {
            "method": "POST",
            "url": "Patient"
        }
    }
    posting_url= os.environ["POST_TO_UNBUNDLE"]
    posting_headers = {
    'x-ms-blob-type': 'BlockBlob',
    'Content-Type': 'application/json'
    }
    response = requests.request("PUT", posting_url, headers=posting_headers, data=json.dumps(data))
    return (response.text)

def data_output_mrn_oid(data):
    formate={
	"resource": {
		"resourceType": "Bundle",
		"id": str(uuid.uuid4()),
		"type": "searchset",
		"entry": [
            data
        ]
	}
}
    return formate
