import time 
import logging 
import json
# from mysql.connector import connect
import uuid
import datetime
import traceback
import os 

mrn_query = "SELECT resource_json FROM d4c_fhir_datastore.patient where resource_type = 'patient' and mrn ='{mrn}' order by modified_on desc, id desc limit 1"
mrn_oid_query = "SELECT resource_json FROM d4c_fhir_datastore.patient where resource_type = 'patient' and  mrn ='{mrn}' and (organization_oid ='{oid}' or system_oid ='{oid}') order by modified_on desc, id desc limit 1;"


def data_output_d4c():
    ts = time.time()
    formate = {
        "resourceType": "Bundle",
        "id": str(uuid.uuid4()),
        "type": "transaction-response",
        "entry": [
            {
                "resource": {
                    "resourceType": "Bundle",
                    "id": str(uuid.uuid4()),
                    "meta": {
                        "lastUpdated": datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d %H:%M:%S')
                    },
                    "type": "searchset",
                    "total": 0,
                },
                "response": {
                    "status": "200 OK"
                }
            }
        ]
    }
    return formate


async def fetch_mrn(mrn, oid, db_connection):
    logging.info(db_connection)
    logging.info("inside ...")
    try:
        query = ""
        if oid:
            query = mrn_oid_query.format(mrn = mrn,oid = oid)
            # df = cx.read_sql(mysql_url, mrn_oid_query.format(str("'") + mrn + str("'"),
            #                                                 str("'") + oid + str("'"),
            #                                                 str("'") + oid + str("'")))
        else:
            query = mrn_query.format(mrn =  mrn)
            # df = cx.read_sql(mysql_url, mrn_query + str("'") + mrn + str("'"))
        logging.info("query >" + query)
        # result = db_connection.fetchall(query, None)
        db_connection._cursor.execute(query, None)
        result = db_connection._cursor.fetchall()
        logging.info(result[0]["resource_json"])
        return json.loads(result[0]["resource_json"])
    except:
        traceback.print_exc()
        logging.info("error >>")
    return None
