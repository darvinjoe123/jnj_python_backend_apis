import os
from .commons import SqlPooled

db_connection = SqlPooled()


def getappset_with_oid(oid):
     # def app_settings_from_db(oid,db_connection):
    select_client_data = f"""
    SELECT system_oid,client_name,key_parameters,value_parameters 
    FROM d4c_fhir_datastore.clients
    INNER JOIN  
    d4c_fhir_datastore.migration_config
    ON 
    d4c_fhir_datastore.clients.id = d4c_fhir_datastore.migration_config.client_id
    where system_oid = "{oid}"
    """
    data = db_connection.fetch_all(select_client_data, None)
    app_settings_dict = {}
    for i in data:
        client_name = i["client_name"]
        app_settings_dict[i['key_parameters']] = i['value_parameters']
    return app_settings_dict,client_name

