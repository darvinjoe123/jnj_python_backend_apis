import json, logging
import azure.functions as func
from . import mrn_search
from . import app_settings
from .commons import SqlPooled
import ast 
import os 

# Using the class in a function
db_connection = SqlPooled()


def main(req: func.HttpRequest) -> func.HttpResponse:
    url_address = str(req.url)
    name = req.params.get('mrn')
    oid = req.params.get('oid')
    app_settings_dict,client_name = app_settings.getappset_with_oid(oid)
    # d4c = req.params.get("d4c")
    # d4c = ast.literal_eval(os.environ['D4C'])
    d4c= True
    # if str(req.route_params.get("mode")).lower() == "adls": d4c=False
    if 'adls' in (url_address.lower()).split('/'): d4c = False
    if name is  None :
        try:
            req.get_json()
        except:
            return func.HttpResponse(json.dumps({"error" : app_settings_dict[f"{client_name}_EMPTY_RESOURCE_ERROR"]}), status_code=400,mimetype="application/json")
    if name :
        return func.HttpResponse(json.dumps((mrn_search._generate_jwt(name, oid, None, d4c, db_connection,app_settings_dict,client_name))),mimetype="application/json")
    else:
        try:
            json_data = req.get_json()
            return func.HttpResponse(mrn_search._generate_jwt(None, oid, json_data, d4c, db_connection,app_settings_dict,client_name),mimetype="application/json")
        except:
            return func.HttpResponse(json.dumps({"error" : app_settings_dict[f"{client_name}_BAD_REQUEST"]}), status_code=400,mimetype="application/json")


