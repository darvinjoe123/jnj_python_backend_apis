import os
import json
import requests
import jwt
import logging

from azure.storage.blob import BlobServiceClient

def _post_patient(data, url_params,app_settings_dict,client_name):
    print("post data >> " + json.dumps(data))
    url = os.environ["FHIR_PATIENT_URL"]
    response = ""
    if(data):
        payload = {
        "resourceType": "Bundle",
        "id": "bundle-transaction",
        "type": "transaction",
        "entry": [{ "resource" : data
            ,"request": {
                "method": "PUT",
                "url": url_params
            }
        }]
        }
        headers = {
        'PurposeOfUse': os.environ["PURPOSE_OF_USE"],
        'UserID': os.environ["USER_ID"],
        'Source': os.environ["SOURCE"],
        'Product': os.environ["PRODUCT"],
        'Application': os.environ["APPLICATION"],
        'Content-Type': os.environ["CONTENT_TYPE"],
        'Authorization': 'Bearer ' + utils_generate_jwt(app_settings_dict,client_name)
        }
        print("payload 1>> " + str(payload))
        print("payload 2>> " + json.dumps(payload))
        try:
            response = requests.request("POST", url, headers=headers, data=json.dumps(payload))
            print(response.text)
            return json.dumps(response.text)
        except:
            print("Post to legacy FHIR Error")
    return json.dumps(response)



def get_new_patient_id(app_settings_dict,client_name):
    try:
        patient_id_gen_url = app_settings_dict[f'{client_name}_DSEP_PATIENT_ID_GENERATOR_URL']
        response = requests.get(patient_id_gen_url, timeout=30)
        response.raise_for_status()
        new_id = response.text
        return new_id
    except requests.exceptions.RequestException as exception:
        raise SystemExit(exception)

def isDSEPExists(patient_json, key_string):
    try:
        list_assigners = patient_json["identifier"]
        list_string = []
        for assign in list_assigners:
            try:
                if key_string in str(assign["assigner"]["reference"]):
                    return str(assign["value"])
            except:
                logging.error("error")
        return ""
    except:
        logging.error("Something went wrong")
        return ""

def utils_create_blob_client(connection_string):
    blob_service_client = BlobServiceClient.from_connection_string(
        connection_string)
    return blob_service_client


def utils_get_blob_data(container_client, blob_name):
    blob_client = container_client.get_blob_client(blob=blob_name)
    raw_data = blob_client.download_blob().readall()
    return raw_data


def utils_generate_jwt(app_settings_dict,client_name):
    url = app_settings_dict[f'{client_name}_GENERATE_JWT_URL']
    payload = {}
    headers = {
        'client_id': app_settings_dict[f'{client_name}_CLIENT_ID'],
        'client_secret': app_settings_dict[f'{client_name}_CLIENT_SECRET']
    }
    response = requests.request("GET", url, headers=headers, data=payload)
    return response.headers['jwt-token']


def utils_generate_payload_headers(url_params):
    payload = json.dumps({
        "resourceType": "Bundle",
        "id": "bundle-transaction",
        "type": "transaction",
        "entry": [
            {
                "request": {
                    "method": "GET",
                    "url": url_params
                }
            }
        ]
    })

    headers = {
        'PurposeOfUse': os.environ["PURPOSE_OF_USE"],
        'UserID': os.environ["USER_ID"],
        'Source': os.environ["SOURCE"],
        'Product': os.environ["PRODUCT"],
        'Application': os.environ["APPLICATION"],
        'Content-Type': os.environ["CONTENT_TYPE"],
        'Authorization': 'Bearer ' + utils_generate_jwt()
    }

    return payload, headers


def utils_filter_token_for_oid(req):
    jwt_token = req.headers.get('Authorization')[7:]
    decoded = jwt.decode(jwt_token, options={"verify_signature": False})
    oid = decoded['oid']
    return oid


def utils_route_param_fetch(req):
    dsep_resource_id = req.route_params.get('dsep_resource_id')
    resource_fetch = req.route_params.get('resource_fetch')
    resource_fetch_id = req.route_params.get('resource_fetch_id')
    return dsep_resource_id, resource_fetch, resource_fetch_id


def utils_format_output(practitioner_data, resource_data):
    output = []
    formatted_output = []
    output.extend(practitioner_data)
    output.extend(resource_data)

    for i in range(len(output)):
        if 'resource' in output[i]:
            formatted_output.append(
                output[i])
        else:
            formatted_output.append(
                {"resource": output[i]})
    return {
        "resourceType": "Bundle",
        "type": "transaction-response",
        "entry": formatted_output
    }
