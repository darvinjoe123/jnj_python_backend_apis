import os
import logging
import requests
import ast
from tenacity import retry,stop
from azure.storage.blob import BlobServiceClient ,ContentSettings


def _create_blob_client(connection_string):
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    return blob_service_client

def _save_to_container(data, container_client, blob_name):
    blob_client = container_client.get_blob_client(blob=blob_name)
    cnt_settings = ContentSettings(content_type="application/json")
    blob_client.upload_blob(data,content_settings=cnt_settings, overwrite=True)

@retry(stop=stop.stop_after_attempt(3))
def update_docspera_ack(data,blob_name,headers,app_settings_dict,client_name):
    try:
        url=app_settings_dict[f'{client_name}_ACK_URL']
        dsp_fhir_blob_client = _create_blob_client(app_settings_dict[f"{client_name}_EXTERNAL_CONNECTION_STRING"])
        dsp_fhir_blob_container_client = dsp_fhir_blob_client.get_container_client(container= app_settings_dict[f'{client_name}_DSP_ACK_CONTAINER'])
        response = requests.request("POST", url, headers=headers, data=data)
        if(response.status_code == 200):
            logging.info("200 success")
        else:
            #push to dlq containers
            _save_to_container(data,app_settings_dict[f"{client_name}_DLQ_CONTAINER"], blob_name) #blob_name = <txn_id from data object>.json
        logging.info("Finished!")
        return True
    except Exception as e :
        logging.info("DOCSPERA_ACK_URL not found %s",e)
        print(f"DOCSPERA_ACK_URL not found{e}")
        raise

def process(data, blob_name,app_settings_dict,client_name):
    logging.info("Start processing new files!")
    #velys DocSpera storage account
    dsp_fhir_blob_client = _create_blob_client(app_settings_dict[f"{client_name}_EXTERNAL_CONNECTION_STRING"])
    #adls - container inside velys DocSpera storage account
    dsp_fhir_blob_container_client = dsp_fhir_blob_client.get_container_client(container=app_settings_dict[f'{client_name}_DSP_ACK_CONTAINER'])
    try:
        logging.info(f'Processing {blob_name} file.')
        # Move blindly from velys container to velys DocSpera container
        _save_to_container(data, dsp_fhir_blob_container_client, blob_name)
        headers=ast.literal_eval(app_settings_dict[f'{client_name}_ACK_HEADERS'])
        logging.info("headers>>>%s",headers)
        if headers:
            return update_docspera_ack(data,blob_name,headers,app_settings_dict,client_name)
        logging.info('Before validation ..')
    except Exception:
        logging.info(f'Error during processing: {blob_name}. Moving file to temp container.')
        return False
    logging.info("Finished!")
    return True