import logging
import json
import jwt
from azure.identity import ManagedIdentityCredential
from azure.keyvault.secrets import SecretClient


class Common:
    def __init__(self):
        logging.info("This is Common")

    def oid_req(self,req_json):
        try:
            oid = json.loads(req_json)["oid"]
        except:
            oid=None
        return oid

    def decrypt_appsettings(self, s):
        s = (s.split("("))[1].split(")")[0]
        s = s.split(";")
        s0 = s[0].split("=")
        s1 = s[1].split("=")
        KVUri = f"https://{s0[1]}.vault.azure.net"
        managed_identity = ManagedIdentityCredential()
        client = SecretClient(vault_url=KVUri, credential=managed_identity)
        retrieved_secret = client.get_secret(s1[1])
        secret_value = retrieved_secret.value
        return secret_value

    def jwt_decoder(self,req):
        try:
            token= req.headers['Authorization'].lstrip('Bearer').strip()
            token_decode = jwt.decode(token, options={"verify_signature": False})
            oid = token_decode["oid"]
        except:
            oid = None
        return oid 

    def run_format(self,data_bundles):
        output={
                "resourceType": "Bundle",
                "type": "transaction-response",
                "entry": data_bundles,
                }
        return output