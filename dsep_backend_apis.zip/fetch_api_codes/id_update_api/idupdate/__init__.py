import logging
import json
import azure.functions as func
from . import ack_to_docspera
from .Db_Helper import AppSettings

appsettings = AppSettings()


def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    req_body = req.get_json()
    blob_name = req.params.get('blob_name')
    logging.info(req_body)
    try:
        req_oid = req_body["acknowledgement"]["OID"].split(":")[-1]
    except:
        req_oid = req_body["acknowledgement"][0]["OID"].split(":")[-1]

    app_settings_dict = None
    app_settings_dict,client_name = appsettings.getappset_with_oid(req_oid)

    if blob_name is None:
        return func.HttpResponse(json.dumps({"error": app_settings_dict[f"{client_name}_INVALID_INPUT"]}),
                                 status_code=400, mimetype="application/json")

    if req_body:
        logging.info("json >> %s", str(req_body))
        logging.info("blob_name >> %s", str(blob_name))
        # try:
        response = {}
        if ack_to_docspera.process(json.dumps(req_body), blob_name,app_settings_dict,client_name):
            response = {"result": "success"}
        else:
            response = {"result": "failure"}
        return func.HttpResponse(json.dumps(response), mimetype="application/json")


