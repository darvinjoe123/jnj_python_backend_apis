import os
import pymysql
import ast
from dbutils.pooled_db import PooledDB
from .Helper import Common


db_details = os.environ['DB_DETAILS'].split(',')
pool_config = os.environ['POOLING_DETAILS'].split(',')
MYSQL_CONFIG = {
    "host": db_details[0],
    "port": int(db_details[1]),
    "db": db_details[2],
    "password": os.environ['DB_PASSWORD'],
    "user": os.environ['DB_USER_NAME'],
    "charset": db_details[3],
    "cursorclass": pymysql.cursors.DictCursor,
    "autocommit": ast.literal_eval(db_details[4]),
}
POOL_CONFIG = {
    # Modules using linked databases
    "creator": pymysql,
    "maxconnections": int(pool_config[0]),
    "mincached": int(pool_config[1]),
    "maxcached": int(pool_config[2]),
    "maxshared": int(pool_config[3]),
    "blocking": ast.literal_eval(pool_config[4]),
    "maxusage": ast.literal_eval(pool_config[5]),
    "setsession": [],
    "ping": int(pool_config[6]),
}

POOL = PooledDB(**MYSQL_CONFIG, **POOL_CONFIG)


class DBHelper:
    def __init__(self):
        self._connection = POOL.connection()
        self._cursor = self._connection.cursor()

    def fetch_one(self, sql, args):
        self._cursor.execute(sql, args)
        result = self._cursor.fetchone()
        return result

    def fetch_all(self, sql, args):
        self._cursor.execute(sql, args)
        result = self._cursor.fetchall()
        return result

    def __del__(self):
        self._connection.close()

dbhelper = DBHelper()
common = Common()

class AppSettings:
    def getappset_with_oid(self, oid):
        select_client_data = f"""
        SELECT system_oid,lmi_name,key_parameters,value_parameters 
        FROM d4c_fhir_datastore.lmi
        INNER JOIN  
        d4c_fhir_datastore.migration_config
        ON 
        d4c_fhir_datastore.lmi.id = d4c_fhir_datastore.migration_config.client_id
        where system_oid = "{oid}"
        """
        data = dbhelper.fetch_all(select_client_data, None)
        app_settings_dict = {}
        client_name = None
        for i in data:
            client_name = i["lmi_name"]
            if str(i['value_parameters']).startswith("@Microsoft"):
                value = common.decrypt_appsettings(i['value_parameters'])
                app_settings_dict[i['key_parameters']] = value
            else:
                app_settings_dict[i['key_parameters']] = i['value_parameters']

        return app_settings_dict, client_name