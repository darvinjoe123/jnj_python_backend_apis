import datetime
import logging
import azure.functions as func
# from .Process import BundleProcessor
from .Process.BundleProcessor import process


def main(mytimer: func.TimerRequest) -> None:
    utc_timestamp = datetime.datetime.utcnow().replace(
        tzinfo=datetime.timezone.utc).isoformat()
    logging.info('Python timer trigger function ran at %s', utc_timestamp)
    if mytimer.past_due:
        logging.info('The timer is past due!')
    process()
    logging.info('Python timer trigger function ran att %s', utc_timestamp)
