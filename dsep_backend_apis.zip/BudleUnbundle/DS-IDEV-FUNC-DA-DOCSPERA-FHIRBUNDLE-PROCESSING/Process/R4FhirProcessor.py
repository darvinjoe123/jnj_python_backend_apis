import logging
import json
import os
from typing import final 
from  benedict import benedict
from threading import Thread
from collections import deque
from collections import defaultdict
from queue import Queue
from ..Helper.ADLHelper import adl_helper
from ..Helper.DSPHelper import helper_util
from ..Constants.DSPConstants import DSP_CONSTANT
from ..Helper.DBHelper import db_helper
import ast 
search_string_present_but_null = DSP_CONSTANT.search_string_present_but_null 
expected_value_missing = DSP_CONSTANT.expected_value_missing
ack_filestring = DSP_CONSTANT.ack_filestring
err_filestring = DSP_CONSTANT.err_filestring
prac_id_url_dict = None

class DownloadWorker(Thread):

    def __init__(self, queue):
        Thread.__init__(self)
        self.queue = queue

    def run(self):
        while True:
            # Get the work from the queue and expand the tuple
            blob, json_data,thread_count,vendor,gc, d4c, adls= self.queue.get()
            try:
                self.worker_thread(blob, json_data,thread_count,vendor,gc, d4c, adls)
            finally:
                self.queue.task_done()

    def worker_thread(self,blob,json_data, thread_count,vendor,gc, d4c, adls):
        try:
            logging.info("hi")
            uuid = ""
            client_resource_id = reject_process = False
            audit_fhir = defaultdict(lambda: False)
            name_list = blob.name.split('/')
            audit_fhir["is_uuid"] = audit_fhir["is_json"] =  audit_fhir["is_fhir_valid"] = True
            audit_fhir["vendor_oid"] = gc[f"{vendor}_OID"]
            audit_fhir["transaction_id"] = name_list[1][:-5] if len(name_list) >1 else name_list[0][:-5]
            db_helper.insert_data(DSP_CONSTANT.insert_statement.format(fields=(",".join(list(audit_fhir.keys()))),values=tuple(audit_fhir.values())),None,d4c)
            audit_fhir["lmi_name"] = vendor 
            audit_fhir["resource_pickup_time"] = helper_util.get_eastern_time_date()
            audit_fhir["blobpath"] = blob.name
            audit_fhir["resource_landed_time"] = helper_util.convert_datetime_timezone((blob.creation_time).strftime('%Y-%m-%d %H:%M:%S'), "UTC", 'US/Eastern')
            audit_fhir["resource_modified_time"] = helper_util.convert_datetime_timezone((blob.last_modified).strftime('%Y-%m-%d %H:%M:%S'), "UTC", 'US/Eastern')
            vendor = audit_fhir["lmi_name"] 
            ext  = os.path.splitext(blob.name)[-1]
            audit_fhir["worker_pickup_time"] = helper_util.get_eastern_time_date()
            values = [audit_fhir["vendor_oid"],audit_fhir["lmi_name"],audit_fhir['transaction_id'],json.dumps(json_data,sort_keys=False),f'{audit_fhir["transaction_id"]}{ext}',audit_fhir["resource_landed_time"]]       
            db_helper.insert_data(DSP_CONSTANT.insert_dsp_archive_query,values,d4c)
            # docspera-archive
            adl_helper.upload_data(gc["VELYS_CONNECTION_STRING"], gc[f"{vendor}_ARCHIVED_CONTAINER"], f'{audit_fhir["transaction_id"]}{ext}',json_data,adls)
            audit_fhir["is_moved_to_archive"] = True
            audit_fhir["moved_to_archive_time"] =  helper_util.get_eastern_time_date()
            #docspera-adls
            adl_helper.upload_data(gc["VELYS_CONNECTION_STRING"], gc[f"{vendor}_DSP_FHIR_CONTAINER"], f'{audit_fhir["transaction_id"]}{ext}',json_data,adls)
            # docspera-processing 
            adl_helper.upload_data(gc["VELYS_CONNECTION_STRING"], gc[f"{vendor}_DSP_CONTAINER"], f'{audit_fhir["transaction_id"]}{ext}',json_data,adls)
            resources_ids, audit_fhir["resource_type"] = helper_util.fetch_id_types(json_data)
            audit_fhir["resource_type"] = (",".join(audit_fhir["resource_type"])).lower()
            resources_list  = audit_fhir["resource_type"].split(",")
            audit_fhir["mrn"] = helper_util.get_mrn(json_data)
            resource_type_search = ''
            if len(resources_list) == 1: 
                audit_fhir["is_single_resource"] = True
            if "practitioner" in resources_list: audit_fhir["is_single_practitioner"] = True
            if "medications" in resources_list:  audit_fhir["is_medication_resource"] = True
            resource_type_search = 'practitioner' if audit_fhir["is_single_practitioner"] else 'patient'
            # UPDATE PATH******************************************************************************************************************
                
                # ADD PATH-----------------------------------------------------------------------------
            if helper_util.return_from_resource_type(json_data, resource_type_search, True):
                # PATIENT & PRACTITIONER ADD PATH -----------------------------------------------------------------------------
                    # vendor_custom_id = helper_util.fhir_mr_extractor(json_data, gc[f'{vendor}_PAT_ID_PATTERN'], gc[f'{vendor}_PAT_ID_VALUE'])
                    vendor_custom_id = helper_util.fhir_mr_extract(json_data)
                    vendor_custom_pat_id, vendor_custom_pract_id = helper_util.full_url_extractor(json_data)
                    logging.warning("vendor_custom_pract_id  "+str(vendor_custom_pract_id))
                    logging.warning("vendor_custom_id  "+str(vendor_custom_id))
                    logging.warning("vendor_custom_pat_id  "+str(vendor_custom_pat_id))
                    # if  vendor_custom_id and  vendor_custom_id != expected_value_missing and  vendor_custom_id != search_string_present_but_null:
                    if  vendor_custom_id or vendor_custom_pract_id or vendor_custom_pat_id:

                        if audit_fhir["is_single_practitioner"]:
                            prac_id_url_dict = {}
                            dsep_pract_id =[] 
                            for i in vendor_custom_pract_id:
                                id_exist = db_helper.fetch_one(DSP_CONSTANT.select_dsp_practitioner_fhir,(i,audit_fhir["vendor_oid"]))
                                # if id_exist: audit_fhir["dsp_practitioner_id"] = id_exist['dsp_practitioner_id']
                                if id_exist:
                                    dsep_pract = id_exist['dsp_practitioner_id']
                                    dsep_pract_id.append(dsep_pract)
                                else:
                                    audit_fhir["is_add"] = audit_fhir["is_new_practitioner"] = True
                                    dsep_pract = helper_util.generate_dsp_id(gc[f'{vendor}_ID_GEN_URL'])
                                    # audit_fhir["dsp_practitioner_id"] = helper_util.generate_dsp_id(gc[f'{vendor}_ID_GEN_URL'])
                                    dsep_pract_id.append(dsep_pract)
                                    audit_fhir["new_dsp_practitioner_id_time"] = helper_util.get_eastern_time_date()
                                prac_id_url_dict[i] = dsep_pract
                                dsep_practi = ','.join(dsep_pract_id)
                            # logging.info(prac_id_url_dict)
                            
                            audit_fhir["dsp_practitioner_id"] = dsep_practi
                            
                        if "patient" in resources_list:
                            audit_fhir['patient_vendor_id'] = vendor_custom_id
                            id_exist = db_helper.fetch_one(DSP_CONSTANT.select_dsp_patient,(vendor_custom_pat_id,audit_fhir["vendor_oid"]))
                            if id_exist: audit_fhir["dsp_patient_id"] = id_exist['dsp_patient_id']
                            else:
                                audit_fhir["is_add"] =  audit_fhir["is_new_patient"] = True
                                audit_fhir["dsp_patient_id"] = helper_util.generate_dsp_id(gc[f'{vendor}_ID_GEN_URL'])
                                audit_fhir["new_dsp_patient_id_time"] = helper_util.get_eastern_time_date()
                    else:
                        audit_fhir["vendor_id_not_found"] = reject_process = True   
                        audit_fhir['vendor_id_not_found_block'] = error_message= f'{vendor} ID not found while processing blob'
                        helper_util.handle_error(error_message, vendor, audit_fhir, str(json_data), gc, adls, "error", d4c)
            # NON-PATIENT ADD PATH-----------------------------------------------------------------------------
            else:
                vendor_custom_id = helper_util.get_fhir_url_client_id(json_data)
                if vendor_custom_id:
                    if audit_fhir["is_single_practitioner"]:
                        audit_fhir['practitioner_vendor_id'] = vendor_custom_id
                        id_exist = db_helper.fetch_one(DSP_CONSTANT.select_dsp_practitioner_fhir,(audit_fhir['practitioner_vendor_id'],audit_fhir["vendor_oid"]))
                        if (not id_exist) or (audit_fhir['dsp_practitioner_id'] != id_exist['dsp_practitioner_id']): reject_process = True
                    else:
                        audit_fhir['patient_vendor_id'] = vendor_custom_id
                        id_exist = db_helper.fetch_one(DSP_CONSTANT.select_dsp_patient,(audit_fhir['patient_vendor_id'],audit_fhir["vendor_oid"]))
                        if (not id_exist) or (audit_fhir['dsp_patient_id'] != id_exist['dsp_patient_id']): reject_process = True
                else:
                    audit_fhir["vendor_id_not_found"] = reject_process = True   
                    audit_fhir['vendor_id_not_found_block'] = error_message= f'Non-Patient or Non-Practitioner Resource: {vendor} ID not found while processing blob'
                    helper_util.handle_error(error_message, vendor, audit_fhir, str(json_data), gc, adls, "error", d4c)

            try:
                resource_oid = json_data["oid"]
                oid_flag = True
            except: oid_flag = False
            if not audit_fhir["is_resource_id_error"]:

                if not reject_process:
                    logging.warn(
                        '-------------------------- if not reject_process: --------------------------')
                    #uuid = audit_fhir["dsp_practitioner_id"]  if audit_fhir["is_single_practitioner"] else audit_fhir["dsp_patient_id"] 
                    uuid = audit_fhir["dsp_patient_id"]
                    vendor_unique_id = audit_fhir["patient_vendor_id"]
                    org_oid = audit_fhir["vendor_oid"] if oid_flag != True else resource_oid
                    response = helper_util.post_to_urls(audit_fhir["transaction_id"],  audit_fhir["dsp_patient_id"], org_oid, vendor_unique_id, json.dumps(prac_id_url_dict),  audit_fhir["npi"],
                                            audit_fhir["is_new_practitioner"], audit_fhir["is_single_practitioner"], audit_fhir["is_medication_resource"], audit_fhir["is_new_patient"],gc,vendor,adls)
                    
                    audit_fhir["post_to_unbundle_time"] = helper_util.get_eastern_time_date()
                    audit_fhir["status_code"] = response
                    # delete from processing
                    # try: adl_helper.delete_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_DSP_CONTAINER'], blob.name,adls)
                    # except: pass
                else:
                    audit_fhir["vendor_id_not_found"] = reject_process = True   
                    audit_fhir['vendor_id_not_found_block'] = error_message= f'DSEP PID or {vendor} ID did not match'
                    helper_util.handle_error(error_message, vendor, audit_fhir, str(json_data), gc, adls, "error", d4c)
                    
                    # delete from processing
                    # try: adl_helper.delete_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_DSP_CONTAINER'], blob.name,adls)
                    # except: pass
            else:
                audit_fhir["vendor_id_not_found"] = reject_process = True   
                audit_fhir['vendor_id_not_found_block'] = error_message= 'No resource id found'
                helper_util.handle_error(error_message, vendor, audit_fhir, str(json_data), gc, adls, "error", d4c)
                
            #     # delete from processing
            #     try: adl_helper.delete_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_DSP_CONTAINER'], blob.name,adls)
            #     except: pass
            # helper_util.delete_helper(blob,vendor,gc,adls)
            audit_fhir["delete_source_time"] = helper_util.get_eastern_time_date()
            try:
                if audit_fhir["status_code"] == 200:
                    audit_fhir["is_requests_error"] = False
                    acknowledgement_filename = helper_util.join_strings(filename_list=[audit_fhir["transaction_id"], ack_filestring])
                    valid_patient_acknowledgement = helper_util.get_acknowledgement_response(audit_fhir["transaction_id"],gc,vendor,adls,audit_fhir["status_code"],
                                                                                audit_fhir["is_single_practitioner"],
                                                                                gc[f'{vendor}_DSP_PAT_ID_STRING'], "OID", 
                                                                                f"{vendor}_ID",
                                                                                gc[f'{vendor}_DSP_DOC_ID_STRING'],
                                                                                gc[f'{vendor}_NPI_PATTERN_STRING'],
                                                                                uuid=audit_fhir["dsp_patient_id"], oid=org_oid,
                                                                                docspera_id=vendor_unique_id,
                                                                                practitioner_id=audit_fhir["dsp_practitioner_id"],
                                                                                national_provider_id=audit_fhir["npi"])

                    values = [audit_fhir["transaction_id"],uuid,json.dumps(valid_patient_acknowledgement),acknowledgement_filename,helper_util.get_eastern_time_date()]
                    db_helper.insert_data(DSP_CONSTANT.insert_dsp_ack_query,values,d4c)
                    db_helper.insert_data(DSP_CONSTANT.insert_dsp_ack_archive_query,values,d4c)
                    adl_helper.upload_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_ACKNOWLEDGEMENT_CONTAINER'],acknowledgement_filename,valid_patient_acknowledgement,adls)
                    adl_helper.upload_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_ACKNOWLEDGEMENT_ARCHIVE_CONTAINER'],acknowledgement_filename,valid_patient_acknowledgement,adls)
                    audit_fhir["post_ack_time"] = helper_util.get_eastern_time_date()
                else:
                    audit_fhir["is_requests_error"] = True
                    helper_util.err_ack_helper(audit_fhir["transaction_id"],gc, uuid,vendor, d4c, adls)
                    audit_fhir["post_ack_time"] = helper_util.get_eastern_time_date()
            except Exception as e: audit_fhir["is_requests_error_desc"] = e
        except Exception as e:
            logging.info(e)
            internall_error = 500
            error_message = f"Error during Processing : {e}"
            response_filename = f'{os.path.splitext(blob.name)[0]}.error' 
            values = [audit_fhir["transaction_id"],error_message,str(json_data),"error",helper_util.get_eastern_time_date()]
            db_helper.insert_data(DSP_CONSTANT.insert_dsp_error_query,values,d4c)
            adl_helper.upload_data(gc["VELYS_CONNECTION_STRING"], gc["WORKFLOW_ERROR_CONTAINER"], response_filename,error_message,adls)
            adl_helper.upload_data(gc["VELYS_CONNECTION_STRING"], gc["WORKFLOW_ERROR_CONTAINER"], response_filename, json_data,adls)
            # helper_util.delete_helper(blob,vendor,gc,adls)
            audit_fhir["delete_source_time"] = helper_util.get_eastern_time_date()
            
        finally: helper_util.delete_helper(blob, vendor, gc, adls)
        
        try:
            audit_fhir["bundle_audit_json"] = json.dumps(audit_fhir,sort_keys=False)
            audit_fhir = {k: False if not v else v for k, v in audit_fhir.items() }
            val = (audit_fhir["bundle_audit_json"],audit_fhir["transaction_id"])
            db_helper.update_data(DSP_CONSTANT.update_statement,val,d4c)
            #db_helper.insert_data(DSP_CONSTANT.insert_statement.format(fields=(",".join(list(audit_fhir.keys()))),values=tuple(audit_fhir.values())),None,d4c)

        except Exception as e:
            logging.info(e)
        logging.error("Blob {}  - Thread completed {} ".format(audit_fhir["transaction_id"], thread_count))


class R4FhirProcessor:
    _instance = None
    def __new__(cls):
        if cls._instance is None:
            logging.info('Creating the R4FhirProcessor singleton object')
            cls._instance = super(R4FhirProcessor, cls).__new__(cls)
        return cls._instance
 
    def process(self,vendor,gc, d4c, adls):
        que = deque([])
        data_que = deque([])
        error_blobs = []
        fhir_processing_blob_list = adl_helper.list_data(gc[f'{vendor}_STORAGE_ACCOUNT_CONNECTION_STRING'],gc[f'{vendor}_DSP_FHIR_CONTAINER'],adls, list_prefix=gc[f"{vendor}_FHIR_PATH"])
        for blob in fhir_processing_blob_list:
            try:
                logging.warn("R$_1")
                name_blob = blob.name.split('/')
                transaction = name_blob[1][:-5] if len(name_blob) >1 else name_blob[0][:-5]
                raw_data = adl_helper.get_data(gc[f'{vendor}_STORAGE_ACCOUNT_CONNECTION_STRING'], gc[f'{vendor}_DSP_FHIR_CONTAINER'],blob.name,adls)
                is_uuid = helper_util.uuid_validation(transaction)
                # if gc[f'{vendor}_UUID_VAL'] == False: is_uuid = True
                is_json ,json_data = helper_util.json_validation(raw_data)
                logging.warn(f"R$_2 : {is_json}")

                try:
                    json_data = json_data["body"]
                except:
                    json_data = json_data

                fhir_allow = True
                fhir_valid, fhir_error_desc = helper_util.fhir_resource_validator("Bundle",json_data, transaction)
                if not fhir_valid and ast.literal_eval(gc[f'REDOX_FHIR_REJECT']): fhir_allow = False
                logging.warn("R$_3")

                if is_uuid and is_json and fhir_allow:
                    logging.warn("R$_4")

                    search_data = benedict(json_data)
                    is_patttern, _ = helper_util.search_helper(search_data,gc[f"{vendor}_RESOURCE_TYPE_PATTERN"],"Patient","")
                    que.appendleft(blob) if is_patttern else que.append(blob)
                    data_que.appendleft(json_data) if is_patttern else data_que.append(json_data)                    
                else:
                    logging.warn("R$_5")
                    error_blobs.append(blob)
                    status_code = 400
                    audit_error = defaultdict(lambda: False)
                    audit_error["is_uuid"] = is_uuid
                    audit_error["is_json"] = is_json
                    audit_error["status_code"] = status_code
                    name_error = blob.name.split('/')
                    audit_error["vendor_oid"] = gc[f"{vendor}_OID"]
                    audit_error["transaction_id"] = name_error[1][:-5] if len(name_error) >1 else name_error[0][:-5]
                    audit_error["lmi_name"] = vendor 
                    audit_error["resource_pickup_time"] = helper_util.get_eastern_time_date()
                    audit_error["blobpath"] = blob.name
                    audit_error["resource_landed_time"] = helper_util.convert_datetime_timezone((blob.creation_time).strftime('%Y-%m-%d %H:%M:%S'), "UTC", 'US/Eastern')
                    audit_error["resource_modified_time"] = helper_util.convert_datetime_timezone((blob.last_modified).strftime('%Y-%m-%d %H:%M:%S'), "UTC", 'US/Eastern')
                    decode_data = str(raw_data.decode('utf8').replace("'", '"'))
                    logging.warn("R$_6")

                    if not is_uuid:
                        logging.warn("R$_7")
                        helper_util.handle_error(f"Error during processing: {blob.name}. Invalid UUID.", "UUID", audit_error, decode_data, gc, adls, "dlq", d4c)
                        helper_util.err_ack_helper(audit_error["transaction_id"],gc, None,vendor, d4c, adls)
                    if not is_json:
                        logging.warn("R$_8")
                        helper_util.handle_error(f"Error during processing: {blob.name}. Invalid JSON.", "SYNTAX", audit_error, decode_data, gc, adls, "dlq", d4c)
                        helper_util.err_ack_helper(audit_error["transaction_id"],gc, None,vendor, d4c, adls)
                    if not fhir_allow:
                        logging.warn("R$_9")
                        error_message=  f'FHIR Error : {str(fhir_error_desc)}'
                        values = transaction, error_message, json.dumps(json_data), "dlq", helper_util.get_eastern_time_date()
                        db_helper.insert_data(DSP_CONSTANT.insert_dsp_dlq_query,values,d4c)

                    helper_util.err_ack_helper(transaction,gc, "",vendor, d4c, adls)
                    logging.warn("R$_10")
                    helper_util.delete_helper(blob,vendor,gc,adls)
                    logging.warn("R$_11")

                    try: 
                        audit_error["bundle_audit_json"] = json.dumps(audit_error,sort_keys=False)
                        audit_error = {k: False if not v else v for k, v in audit_error.items() }
                        val = (audit_error["bundle_audit_json"],audit_error["transaction_id"])
                        db_helper.update_data(DSP_CONSTANT.update_statement,val,d4c)
                        #db_helper.insert_data(DSP_CONSTANT.insert_statement.format(fields=(",".join(list(audit_error.keys()))),values=tuple(audit_error.values())),None,d4c)
                    except Exception as e: pass
            except Exception as err:
                logging.error("err"+str(err))

        if len(que) > 0:
            thread_count = 0
            queue = Queue()
            for x in range(int(gc[f"{vendor}_THREAD_COUNT"])):
                worker = DownloadWorker(queue)
                worker.daemon = True # Setting daemon to True will let the main thread exit even though the workers are blocking
                worker.start()
                logging.info("worker started")
            thread_count = 0
            for blob in range(len(que)):
                queue.put((que[blob],data_que[blob],thread_count,vendor,gc, d4c, adls))  # Put the tasks into the queue as a tuple
                thread_count = +1
            queue.join() # Causes the main thread to wait for the queue to finish processing all the tasks
        
FhirProcessor = R4FhirProcessor()
