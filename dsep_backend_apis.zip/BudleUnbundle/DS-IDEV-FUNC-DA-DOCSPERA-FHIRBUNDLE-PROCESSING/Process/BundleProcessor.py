import logging
import json
from benedict import benedict
from ..Helper.DBHelper import db_helper
from .NonFhirProcessor import nonFhirProcessor
from .R4FhirProcessor import FhirProcessor
from .CustomProcessor import customProcessor
from ..Helper.DSPHelper import helper_util
from ..Constants.DSPConstants import DSP_CONSTANT

def process():
    try:
        lock_status = (db_helper.fetch_all(DSP_CONSTANT.select_lock_query))[0]['status']
        if lock_status==0:
            db_helper.update_data(DSP_CONSTANT.lock_status,(1,"bundle"))
            client_data =  db_helper.fetch_all(DSP_CONSTANT.select_client_data)
            vendor_names = set(str(dic['lmi_name']) for dic in client_data)
            gc =  helper_util.get_config(client_data)

            for vendor in vendor_names:
                d4c = gc[f'{vendor}_IS_FHIR_D4C']
                adls = gc[f'{vendor}_IS_ADLS']
                nonFhirProcessor.process(vendor,gc, d4c, adls)
                if gc[f'{vendor}_VALIDATION_KIND'] == "FHIR":
                    logging.warning(1)
                    FhirProcessor.process(vendor,gc, d4c, adls)
                elif gc[f'{vendor}_VALIDATION_KIND'] == "CUSTOM":
                    logging.warning(2)
                    customProcessor.process(vendor,gc, d4c, adls)
                    
    except Exception as e: 
        logging.info(e)
    finally: db_helper.update_data(DSP_CONSTANT.lock_status,(0,"bundle"))
        