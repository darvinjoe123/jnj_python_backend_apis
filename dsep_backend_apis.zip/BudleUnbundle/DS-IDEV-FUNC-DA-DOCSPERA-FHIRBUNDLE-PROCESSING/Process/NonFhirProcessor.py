import logging
import json, traceback
import os
from collections import defaultdict
from ..Helper.ADLHelper import adl_helper
from ..Helper.DBHelper import db_helper
from ..Helper.DSPHelper import helper_util
from ..Constants.DSPConstants import DSP_CONSTANT

class NonFhirProcessor:

    _instance = None
    def __new__(cls):
        if cls._instance is None:
            logging.info('Creating the object')
            cls._instance = super(NonFhirProcessor, cls).__new__(cls)
        return cls._instance
    
    # process non-fhir data
    def process(self, vendor,gc, d4c, adls):
        logging.warning("1: "+str(vendor))

        non_fhir_processing_blob_list = adl_helper.list_data(gc[f'{vendor}_STORAGE_ACCOUNT_CONNECTION_STRING'],gc[f'{vendor}_DSEP_CONTAINER'],adls, list_prefix=gc[f"{vendor}_NON_FHIR_FOLDER_PATH"])
        for blob in non_fhir_processing_blob_list:
            try:
                audit_nonfhir = defaultdict(lambda: False)
                audit_nonfhir["vendor_name"] = vendor
                audit_nonfhir["resource_pickup_time"] = helper_util.get_eastern_time_date()
                audit_nonfhir["blobpath"] = blob.name
                audit_nonfhir["resource_landed_time"] = helper_util.convert_datetime_timezone((blob.creation_time).strftime('%Y-%m-%d %H:%M:%S'), "UTC", 'US/Eastern')
                audit_nonfhir["resource_modified_time"] = helper_util.convert_datetime_timezone((blob.last_modified).strftime('%Y-%m-%d %H:%M:%S'), "UTC", 'US/Eastern')
                raw_data = adl_helper.get_data(gc[f'{vendor}_STORAGE_ACCOUNT_CONNECTION_STRING'], gc[f'{vendor}_DSEP_CONTAINER'],blob.name,adls)
                try: file = json.loads(raw_data) 
                except: file = raw_data
                audit_nonfhir["delete_source_time"] = helper_util.get_eastern_time_date()
                _,audit_nonfhir["vendor_oid"],_,audit_nonfhir["resource_type"],audit_nonfhir["transaction_id"],_ = [str(e) for e in audit_nonfhir["blobpath"].split("/")]
                # "TODO" check two values are same - correct or wrong - non_fhir_pickup_time instead of nonfhir_created_time
                values = [audit_nonfhir["vendor_oid"],audit_nonfhir["resource_type"],str(file),audit_nonfhir["transaction_id"],vendor, audit_nonfhir["resource_landed_time"], audit_nonfhir["resource_modified_time"]]
                db_helper.insert_data(DSP_CONSTANT.insert_d4cnonfhir_query,values,d4c)
                adl_helper.upload_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_DSEP_CONTAINER'],blob.name,raw_data,adls)
                audit_nonfhir["moved_to_destiny_time"] = helper_util.get_eastern_time_date()
                adl_helper.delete_data(gc[f'{vendor}_STORAGE_ACCOUNT_CONNECTION_STRING'], gc[f'{vendor}_DSEP_CONTAINER'],blob.name,adls)
                audit_nonfhir["delete_source_time"] = helper_util.get_eastern_time_date()
                audit_nonfhir = {k: False if not v else v for k, v in audit_nonfhir.items() }
                db_helper.insert_data(DSP_CONSTANT.insert_statement.format(fields=(",".join(list(audit_nonfhir.keys()))),values=tuple(audit_nonfhir.values())),None,d4c)
            except Exception as e:
                logging.info(e)
                audit_nonfhir["non_fhir_error"] = True
                response_filename = f'{os.path.splitext(blob.name)[0]}.error'
                try: file = json.loads(raw_data) 
                except: file = raw_data
                values = [audit_nonfhir["transaction_id"],"Error during NON-FHIR processing",str(file),"non_fhir",helper_util.get_eastern_time_date()]
                db_helper.insert_data(DSP_CONSTANT.insert_dsp_error_query,values,d4c)
                db_helper.insert_data(DSP_CONSTANT.insert_statement.format(fields=(",".join(list(audit_nonfhir.keys()))),values=tuple(audit_nonfhir.values())),None,d4c)
                adl_helper.upload_data(gc["VELYS_CONNECTION_STRING"], gc["WORKFLOW_ERROR_CONTAINER"], response_filename,traceback.format_exc(),adls)
                adl_helper.upload_data(gc["VELYS_CONNECTION_STRING"], gc["WORKFLOW_ERROR_CONTAINER"], response_filename, raw_data,adls)
                try: adl_helper.delete_data(gc[f'{vendor}_STORAGE_ACCOUNT_CONNECTION_STRING'], gc[f'{vendor}_DSEP_CONTAINER'], blob.name,adls)
                except: pass
                audit_nonfhir["delete_source_time"] = helper_util.get_eastern_time_date()
                audit_nonfhir = {k: False if not v else v for k, v in audit_nonfhir.items() }
                db_helper.insert_data(DSP_CONSTANT.insert_statement.format(fields=(",".join(list(audit_nonfhir.keys()))),values=tuple(audit_nonfhir.values())),None,d4c)

        return True

nonFhirProcessor = NonFhirProcessor()
