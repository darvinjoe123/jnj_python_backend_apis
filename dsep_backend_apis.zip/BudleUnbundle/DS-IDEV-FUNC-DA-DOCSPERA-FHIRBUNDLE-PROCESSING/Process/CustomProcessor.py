import logging
import json
import os 
from  benedict import benedict
from threading import Thread
from collections import deque
from collections import defaultdict
from queue import Queue
from ..Helper.ADLHelper import adl_helper
from ..Helper.DSPHelper import helper_util
from ..Constants.DSPConstants import DSP_CONSTANT
from ..Helper.DBHelper import db_helper

search_string_present_but_null = DSP_CONSTANT.search_string_present_but_null 
expected_value_missing = DSP_CONSTANT.expected_value_missing
ack_filestring = DSP_CONSTANT.ack_filestring
err_filestring = DSP_CONSTANT.err_filestring

class DownloadWorker(Thread):

    def __init__(self, queue):
        Thread.__init__(self)
        self.queue = queue

    def run(self):
        while True:
            # Get the work from the queue and expand the tuple
            blob, thread_count,vendor,gc, d4c, adls= self.queue.get()
            try:
                self.worker_thread(blob, thread_count,vendor,gc, d4c, adls)
            finally:
                self.queue.task_done()

    def worker_thread(self,blob, thread_count,vendor,gc, d4c, adls):
        try:
            audit_fhir = defaultdict(lambda: False)
            name_list = blob.name.split('/')
            audit_fhir["is_uuid"] = audit_fhir["is_json"] = True
            audit_fhir["vendor_oid"] = gc[f"{vendor}_OID"]
            audit_fhir["transaction_id"] = name_list[1][:-5] if len(name_list) >1 else name_list[0][:-5]
            db_helper.insert_data(DSP_CONSTANT.insert_statement.format(fields=(",".join(list(audit_fhir.keys()))),values=tuple(audit_fhir.values())),None,d4c)
            audit_fhir["lmi_name"] = vendor 
            audit_fhir["resource_pickup_time"] = helper_util.get_eastern_time_date()
            audit_fhir["blobpath"] = blob.name
            audit_fhir["resource_landed_time"] = helper_util.convert_datetime_timezone((blob.creation_time).strftime('%Y-%m-%d %H:%M:%S'), "UTC", 'US/Eastern')
            audit_fhir["resource_modified_time"] = helper_util.convert_datetime_timezone((blob.last_modified).strftime('%Y-%m-%d %H:%M:%S'), "UTC", 'US/Eastern')
            vendor = audit_fhir["lmi_name"] 
            ext  = os.path.splitext(blob.name)[-1]
            uuid =   ""
            client_resource_id = reject_process = False
            raw_data = adl_helper.get_data(gc[f'{audit_fhir["lmi_name"]}_STORAGE_ACCOUNT_CONNECTION_STRING'], gc[f'{audit_fhir["lmi_name"]}_DSP_FHIR_CONTAINER'],blob.name,adls)
            json_data = json.loads(raw_data)
            dump_data = json.dumps(json_data,sort_keys=False)
            audit_fhir["worker_pickup_time"] = helper_util.get_eastern_time_date()
            values = [audit_fhir["vendor_oid"],audit_fhir["lmi_name"],audit_fhir['transaction_id'],dump_data,f'{audit_fhir["transaction_id"]}{ext}',audit_fhir["resource_landed_time"]]       
            db_helper.insert_data(DSP_CONSTANT.insert_dsp_archive_query,values,d4c)
            # docspera-archive
            adl_helper.upload_data(gc["VELYS_CONNECTION_STRING"], gc[f"{vendor}_ARCHIVED_CONTAINER"], f'{audit_fhir["transaction_id"]}{ext}',raw_data,adls)
            audit_fhir["is_moved_to_archive"] = True
            audit_fhir["moved_to_archive_time"] =  helper_util.get_eastern_time_date()
            #docspera-adls
            adl_helper.upload_data(gc["VELYS_CONNECTION_STRING"], gc[f"{vendor}_DSP_FHIR_CONTAINER"], f'{audit_fhir["transaction_id"]}{ext}',raw_data,adls)
            # docspera-processing 
            adl_helper.upload_data(gc["VELYS_CONNECTION_STRING"], gc[f"{vendor}_DSP_CONTAINER"], f'{audit_fhir["transaction_id"]}{ext}',raw_data,adls)
            resources_ids, audit_fhir["resource_type"] = helper_util.fetch_id_types(json_data)
            audit_fhir["resource_type"] = (",".join(audit_fhir["resource_type"])).lower()
            audit_fhir["mrn"] = helper_util.get_mrn(json_data)
            resource_type_search = ''
            if(len(resources_ids) == 1): audit_fhir["is_single_resource"] = True
            is_individual_resource = helper_util.check_is_individual_resource(json_data)
            logging.warning("OOOOO"+str(helper_util.check_for_resource_id_errors(json_data, is_individual_resource)))
            if gc[f'{vendor}_VALIDATION_KIND'] != "FHIR":
                audit_fhir["is_resource_id_error"] = helper_util.check_for_resource_id_errors(json_data, is_individual_resource)
            audit_fhir["is_single_practitioner"] = helper_util.check_resource_type(json_data, 'practitioner')
            audit_fhir["is_medication_resource"] = helper_util.check_resource_type(json_data, 'medication')
            if not audit_fhir["is_medication_resource"]:
                if not audit_fhir["is_single_practitioner"]:
                    resource_type_search = 'patient'
                    audit_fhir["dsp_patient_id"] = helper_util.search_json(json_data, audit_fhir["transaction_id"],gc,d4c,adls,
                                            search_string=gc[f'{vendor}_DSP_PAT_ID_STRING'],
                                            search_in_key="identifier", where="type")
                else:
                    resource_type_search = 'practitioner'
                    audit_fhir["dsp_practitioner_id"] = helper_util.search_json(json_data, audit_fhir["transaction_id"],gc,d4c,adls,
                                            search_string=gc[f'{vendor}_DSP_DOC_ID_STRING'],
                                            search_in_key="identifier", where="type")
            # UPDATE PATH******************************************************************************************************************
                if  audit_fhir["dsp_practitioner_id"] or (audit_fhir["dsp_patient_id"] and audit_fhir["dsp_patient_id"] != expected_value_missing and audit_fhir["dsp_patient_id"] != search_string_present_but_null):
                    audit_fhir["is_add"] = False
                    if helper_util.return_from_resource_type(json_data, resource_type_search, True):
                        vendor_custom_id = helper_util.get_custom_id_from_patient_or_practitioner(json_data, is_individual_resource)
                        if audit_fhir["is_single_practitioner"]: audit_fhir["practitioner_vendor_id"] = vendor_custom_id
                        else: 
                            audit_fhir["patient_vendor_id"] = vendor_custom_id
                            audit_fhir["is_patient"] = True 
                        if vendor_custom_id and vendor_custom_id != expected_value_missing and vendor_custom_id != search_string_present_but_null:
                            if audit_fhir["patient_vendor_id"]:
                                id_exist = db_helper.fetch_one(DSP_CONSTANT.select_dsp_patient,(audit_fhir['patient_vendor_id'],audit_fhir["vendor_oid"]))
                                if (not id_exist) or (audit_fhir["dsp_patient_id"] != id_exist['dsp_patient_id']): reject_process = True
                            else:
                                id_exist = db_helper.fetch_one(DSP_CONSTANT.select_dsp_practitioner,(audit_fhir['practitioner_vendor_id'],audit_fhir["vendor_oid"]))
                                if (not id_exist) or (audit_fhir["dsp_practitioner_id"] != id_exist['dsp_practitioner_id']): reject_process = True
                                
                        else:
                            audit_fhir["vendor_id_not_found"] = error_message= f"Patient or Practitioner Resource: {vendor} ID not found while processing blob"
                            helper_util.handle_error(error_message, vendor, audit_fhir, str(json_data), gc, adls, "error", d4c)
                    # Update NON-PATIENT PATH-----------------------------------------------------------------------------
                    else:
                        vendor_custom_id = helper_util.get_vendor_specific_id(json_data)
                        if vendor_custom_id:
                            if audit_fhir["is_single_practitioner"]: 
                                audit_fhir['practitioner_vendor_id'] = vendor_custom_id
                                id_exist = db_helper.fetch_one(DSP_CONSTANT.select_dsp_practitioner,(audit_fhir['practitioner_vendor_id'],audit_fhir["vendor_oid"]))
                                if (not id_exist) or (audit_fhir['dsp_practitioner_id'] != id_exist['dsp_practitioner_id']): reject_process = True
                            else: 
                                audit_fhir['patient_vendor_id'] = vendor_custom_id
                                id_exist = db_helper.fetch_one(DSP_CONSTANT.select_dsp_patient,(audit_fhir['patient_vendor_id'],audit_fhir["vendor_oid"]))
                                if (not id_exist) or (audit_fhir['dsp_patient_id'] != id_exist['dsp_patient_id']): reject_process = True
                        else:
                            audit_fhir["vendor_id_not_found"] = reject_process = True   
                            audit_fhir['vendor_id_not_found_block'] = error_message= f'Non-Patient or Non-Practitioner Resource: {vendor} ID not found while processing blob'
                            helper_util.handle_error(error_message, vendor, audit_fhir, str(json_data), gc, adls, "error", d4c)

                else:
                    audit_fhir["is_add"] = True
                    # ADD PATH-----------------------------------------------------------------------------
                    if helper_util.return_from_resource_type(json_data, resource_type_search, True):
                        vendor_custom_id = helper_util.get_custom_id_from_patient_or_practitioner(json_data, is_individual_resource)
                    
                        if  vendor_custom_id and  vendor_custom_id != expected_value_missing and  vendor_custom_id != search_string_present_but_null:
                            if audit_fhir["is_single_practitioner"]:
                                audit_fhir["practitioner_vendor_id"] = vendor_custom_id
                                id_exist = db_helper.fetch_one(DSP_CONSTANT.select_dsp_practitioner,(audit_fhir['practitioner_vendor_id'],audit_fhir["vendor_oid"]))
                                if id_exist: audit_fhir["dsp_practitioner_id"] = id_exist['dsp_practitioner_id']
                                else:
                                    audit_fhir["is_new_practitioner"] = True
                                    audit_fhir["dsp_practitioner_id"] = helper_util.generate_dsp_id(gc[f'{vendor}_ID_GEN_URL'])
                                    audit_fhir["new_dsp_practitioner_id_time"] = helper_util.get_eastern_time_date()
                            else:
                                audit_fhir['patient_vendor_id'] = vendor_custom_id
                                id_exist = db_helper.fetch_one(DSP_CONSTANT.select_dsp_patient,(audit_fhir['patient_vendor_id'],audit_fhir["vendor_oid"]))
                                if id_exist: audit_fhir["dsp_patient_id"] = id_exist['dsp_patient_id']
                                else:
                                    audit_fhir["is_new_patient"] = True
                                    audit_fhir["dsp_patient_id"] = helper_util.generate_dsp_id(gc[f'{vendor}_ID_GEN_URL'])
                                audit_fhir["new_dsp_patient_id_time"] = helper_util.get_eastern_time_date()
                        else:
                            audit_fhir["vendor_id_not_found"] = reject_process = True   
                            audit_fhir['vendor_id_not_found_block'] = error_message= f'{vendor} ID not found while processing blob'
                            helper_util.handle_error(error_message, vendor, audit_fhir, str(json_data), gc, adls, "error", d4c)
                # NON-PATIENT ADD PATH-----------------------------------------------------------------------------
                    else:
                        vendor_custom_id = helper_util.get_vendor_specific_id(json_data)
                        if vendor_custom_id and vendor_custom_id!= expected_value_missing and vendor_custom_id != search_string_present_but_null:
                            if audit_fhir["is_single_practitioner"]: 
                                audit_fhir['practitioner_vendor_id'] = vendor_custom_id
                                id_exist = db_helper.fetch_one(DSP_CONSTANT.select_dsp_practitioner,(audit_fhir['practitioner_vendor_id'],audit_fhir["vendor_oid"]))
                                if (not id_exist): reject_process = True
                                else: audit_fhir['dsp_practitioner_id'] != id_exist['dsp_practitioner_id']
                            else: 
                                audit_fhir['patient_vendor_id'] = vendor_custom_id
                                id_exist = db_helper.fetch_one(DSP_CONSTANT.select_dsp_patient,(audit_fhir['patient_vendor_id'],audit_fhir["vendor_oid"]))
                                if (not id_exist): reject_process = True
                                else: audit_fhir['dsp_patient_id'] = id_exist['dsp_patient_id']
                        else:
                            audit_fhir["vendor_id_not_found"] = reject_process = True   
                            audit_fhir['vendor_id_not_found_block'] = error_message= f'Non-Patient or Non-Practitioner Resource: {vendor} ID not found while processing blob'
                            helper_util.handle_error(error_message, vendor, audit_fhir, str(json_data), gc, adls, "error", d4c)
            else:audit_fhir["dsep_patient_id"] = audit_fhir["docspera_id"] = audit_fhir["practitioner_id"] = None
            
            from_practitioner_resource_type = helper_util.return_from_resource_type(json_data, "practitioner", False)
            audit_fhir["npi"] = helper_util.search_json(from_practitioner_resource_type, audit_fhir["transaction_id"],gc,d4c,adls,search_string="https://npiregistry.cms.hhs.gov/",search_in_key="identifier")
            try:
                resource_oid = json_data["oid"]
                oid_flag = True
            except: oid_flag = False
            if not audit_fhir["is_resource_id_error"]:
                if not reject_process:
                    logging.warn(
                        '-------------------------- if not reject_process: --------------------------')
                    uuid = audit_fhir["dsp_practitioner_id"]  if audit_fhir["is_single_practitioner"] else audit_fhir["dsp_patient_id"] 
                    vendor_unique_id = audit_fhir["practitioner_vendor_id"]  if audit_fhir["is_single_practitioner"] else audit_fhir["patient_vendor_id"]
                    org_oid = audit_fhir["vendor_oid"] if oid_flag != True else resource_oid
                    response = helper_util.post_to_urls(audit_fhir["transaction_id"],  audit_fhir["dsp_patient_id"], org_oid, vendor_unique_id, audit_fhir["dsp_practitioner_id"],  audit_fhir["npi"],
                                            audit_fhir["is_new_practitioner"], audit_fhir["is_single_practitioner"], audit_fhir["is_medication_resource"], audit_fhir["is_new_patient"],gc,vendor,adls)
                    audit_fhir["post_to_unbundle_time"] = helper_util.get_eastern_time_date()
                    audit_fhir["status_code"] = response
                    # delete from processing
                    # try: adl_helper.delete_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_DSP_CONTAINER'], blob.name,adls)
                    # except: pass
                else:
                    audit_fhir["vendor_id_not_found"] = reject_process = True   
                    audit_fhir['vendor_id_not_found_block'] = error_message= f'DSEP PID or {vendor} ID did not match'
                    helper_util.handle_error(error_message, vendor, audit_fhir, str(json_data), gc, adls, "error", d4c)
                    # # delete from processing
                    # try: adl_helper.delete_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_DSP_CONTAINER'], blob.name,adls)
                    # except: pass
                    #audit_fhir["delete_source_time"] = helper_util.get_eastern_time_date() 
            else:
                audit_fhir["vendor_id_not_found"] = reject_process = True   
                audit_fhir['vendor_id_not_found_block'] = error_message= 'No resource id found'
                helper_util.handle_error(error_message, vendor, audit_fhir, str(json_data), gc, adls, "error", d4c)
                # # delete from processing
                # try: adl_helper.delete_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_DSP_CONTAINER'], blob.name,adls)
                # except: pass
            # delete from and to adls
            # try: adl_helper.delete_data(gc[f'{vendor}_STORAGE_ACCOUNT_CONNECTION_STRING'], gc[f'{vendor}_DSP_FHIR_CONTAINER'], blob.name,adls)
            # except: pass
            # try:adl_helper.delete_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_DSP_FHIR_CONTAINER'], blob.name,adls)
            # except: pass
             # delete from processing
            # try: adl_helper.delete_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_DSP_CONTAINER'], blob.name,adls)
            # except: pass
            audit_fhir["delete_source_time"] = helper_util.get_eastern_time_date()
            try:
                if audit_fhir["status_code"] == 200:
                    audit_fhir["is_requests_error"] = False
                    acknowledgement_filename = helper_util.join_strings(filename_list=[audit_fhir["transaction_id"], ack_filestring])
                    valid_patient_acknowledgement = helper_util.get_acknowledgement_response(audit_fhir["transaction_id"],gc,vendor,adls,audit_fhir["status_code"],
                                                                                audit_fhir["is_single_practitioner"],
                                                                                gc[f'{vendor}_DSP_PAT_ID_STRING'], "OID", 
                                                                                f"{vendor}_ID",
                                                                                gc[f'{vendor}_DSP_DOC_ID_STRING'],
                                                                                gc[f'{vendor}_NPI_PATTERN_STRING'],
                                                                                uuid=audit_fhir["dsp_patient_id"], oid=org_oid,
                                                                                docspera_id=vendor_unique_id,
                                                                                practitioner_id=audit_fhir["dsp_practitioner_id"],
                                                                                national_provider_id=audit_fhir["npi"])

                    values = [audit_fhir["transaction_id"],uuid,json.dumps(valid_patient_acknowledgement),acknowledgement_filename,helper_util.get_eastern_time_date()]
                    logging.warning("3: "+str(vendor))

                    db_helper.insert_data(DSP_CONSTANT.insert_dsp_ack_query,values,d4c)
                    db_helper.insert_data(DSP_CONSTANT.insert_dsp_ack_archive_query,values,d4c)
                    adl_helper.upload_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_ACKNOWLEDGEMENT_CONTAINER'],acknowledgement_filename,valid_patient_acknowledgement,adls)
                    adl_helper.upload_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_ACKNOWLEDGEMENT_ARCHIVE_CONTAINER'],acknowledgement_filename,valid_patient_acknowledgement,adls)
                    #adl_helper.upload_data(gc[f'{vendor}_STORAGE_ACCOUNT_CONNECTION_STRING'], gc[f'{vendor}_ACKNOWLEDGEMENT_CONTAINER'],acknowledgement_filename,valid_patient_acknowledgement,adls)
                    audit_fhir["post_ack_time"] = helper_util.get_eastern_time_date()
                else:
                    audit_fhir["is_requests_error"] = True
                    acknowledgement_filename =  helper_util.join_strings(filename_list=[audit_fhir["transaction_id"], ack_filestring])
                    err_patient_acknowledgement = helper_util.get_acknowledgement_response(audit_fhir["transaction_id"],gc,vendor,adls)
                    audit_fhir["post_ack_time"] = helper_util.get_eastern_time_date()
                    values = [audit_fhir["transaction_id"],uuid,json.dumps(err_patient_acknowledgement),acknowledgement_filename,helper_util.get_eastern_time_date()]
                    db_helper.insert_data(DSP_CONSTANT.insert_dsp_ack_query,values,d4c)
                    db_helper.insert_data(DSP_CONSTANT.insert_dsp_ack_archive_query,values,d4c)
                    adl_helper.upload_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_ACKNOWLEDGEMENT_CONTAINER'],acknowledgement_filename,err_patient_acknowledgement,adls)
                    adl_helper.upload_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_ACKNOWLEDGEMENT_ARCHIVE_CONTAINER'],acknowledgement_filename,err_patient_acknowledgement,adls)
                    adl_helper.upload_data(gc[f'{vendor}_STORAGE_ACCOUNT_CONNECTION_STRING'], gc[f'{vendor}_ACKNOWLEDGEMENT_CONTAINER'],acknowledgement_filename,err_patient_acknowledgement,adls)
                    audit_fhir["post_ack_time"] = helper_util.get_eastern_time_date()
            except Exception as e:
                audit_fhir["is_requests_error_desc"] = e
        except Exception as e:
            logging.info(e)
            internall_error = 500
            error_message = f"Error during Processing : {e}"
            response_filename = f'{os.path.splitext(blob.name)[0]}.error' 
            values = [audit_fhir["transaction_id"],error_message,str(json_data),"error",helper_util.get_eastern_time_date()]
            db_helper.insert_data(DSP_CONSTANT.insert_dsp_error_query,values,d4c)
            adl_helper.upload_data(gc["VELYS_CONNECTION_STRING"], gc["WORKFLOW_ERROR_CONTAINER"], response_filename,error_message,adls)
            adl_helper.upload_data(gc["VELYS_CONNECTION_STRING"], gc["WORKFLOW_ERROR_CONTAINER"], response_filename, raw_data,adls)
            # delete from and to adls
            # try: adl_helper.delete_data(gc[f'{vendor}_STORAGE_ACCOUNT_CONNECTION_STRING'], gc[f'{vendor}_DSP_FHIR_CONTAINER'], blob.name,adls)
            # except: pass
            # try:adl_helper.delete_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_DSP_FHIR_CONTAINER'], blob.name,adls)
            # except: pass
            # # delete from processing
            # try: adl_helper.delete_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_DSP_CONTAINER'], blob.name,adls)
            # except: pass
            audit_fhir["delete_source_time"] = helper_util.get_eastern_time_date()
        finally: 
            helper_util.delete_helper(blob, vendor, gc, adls)
        try:
            audit_fhir["bundle_audit_json"] = json.dumps(audit_fhir,sort_keys=False)
            audit_fhir = {k: False if not v else v for k, v in audit_fhir.items() }
            val = (audit_fhir["bundle_audit_json"],audit_fhir["transaction_id"])
            db_helper.update_data(DSP_CONSTANT.update_statement,val,d4c)

        except Exception as e:
            logging.info(e)
        logging.error("Blob {}  - Thread completed {} ".format(audit_fhir["transaction_id"], thread_count))

class CustomProcessor:

    _instance = None
    def __new__(cls):
        if cls._instance is None:
            logging.info('Creating the CustomProcessor singleton object')
            cls._instance = super(CustomProcessor, cls).__new__(cls)
        return cls._instance

    def process(self,vendor,gc, d4c, adls):
        logging.warning("1: "+str(vendor))

        que = deque([])
        error_blobs = []
        fhir_processing_blob_list = adl_helper.list_data(gc[f'{vendor}_STORAGE_ACCOUNT_CONNECTION_STRING'],gc[f'{vendor}_DSP_FHIR_CONTAINER'],adls, list_prefix=gc[f"{vendor}_FHIR_PATH"])
        
        for blob in fhir_processing_blob_list:
            try:
                name_blob = blob.name.split('/')
                transact = name_blob[1][:-5] if len(name_blob) >1 else name_blob[0][:-5]
                raw_data = adl_helper.get_data(gc[f'{vendor}_STORAGE_ACCOUNT_CONNECTION_STRING'], gc[f'{vendor}_DSP_FHIR_CONTAINER'],blob.name,adls)
                is_uuid = helper_util.uuid_validation(transact)
                is_json ,json_data = helper_util.json_validation(raw_data)

                if is_uuid and is_json:
                    search_data = benedict(json_data)
                    is_patttern, _ = helper_util.search_helper(search_data,gc[f"{vendor}_RESOURCE_TYPE_PATTERN"],"Patient","")
                    que.appendleft(blob) if is_patttern else que.append(blob)
                else:
                    error_blobs.append(blob)

            except Exception as err:
                logging.error(err)

        if len(que) > 0:
            thread_count = 0
            queue = Queue()
            for x in range(int(gc[f"{vendor}_THREAD_COUNT"])):
                worker = DownloadWorker(queue)
                worker.daemon = True # Setting daemon to True will let the main thread exit even though the workers are blocking
                worker.start()
                logging.info("worker started")
            thread_count = 0
            for blob in que:
                queue.put((blob, thread_count,vendor,gc, d4c, adls))  # Put the tasks into the queue as a tuple
                thread_count = + 1
            queue.join() # Causes the main thread to wait for the queue to finish processing all the tasks
        if error_blobs:
                status_code = 400
                for blob in error_blobs:
                    audit_error = defaultdict(lambda: False)
                    audit_error["is_uuid"] = is_uuid
                    audit_error["is_json"] = is_json
                    audit_error["status_code"] = status_code
                    name_error = blob.name.split('/')
                    audit_error["vendor_oid"] = gc[f"{vendor}_OID"]
                    audit_error["transaction_id"] = name_error[1][:-5] if len(name_error) >1 else name_error[0][:-5]
                    audit_error["lmi_name"] = vendor 
                    audit_error["resource_pickup_time"] = helper_util.get_eastern_time_date()
                    audit_error["blobpath"] = blob.name
                    audit_error["resource_landed_time"] = helper_util.convert_datetime_timezone((blob.creation_time).strftime('%Y-%m-%d %H:%M:%S'), "UTC", 'US/Eastern')
                    audit_error["resource_modified_time"] = helper_util.convert_datetime_timezone((blob.last_modified).strftime('%Y-%m-%d %H:%M:%S'), "UTC", 'US/Eastern')
                    decode_data = str(raw_data.decode('utf8').replace("'", '"'))
                    if not is_uuid:
                        helper_util.handle_uuid_isjson_error(f"Error during processing: {blob.name}. Invalid UUID.", "UUID" , audit_error, decode_data, gc, adls, d4c, vendor)
                    if not is_json:
                        helper_util.handle_uuid_isjson_error(f"Error during processing: {blob.name}. Invalid JSON.", "SYNTAX", audit_error, decode_data, gc, adls, d4c, vendor)
                    acknowledgement_filename =  helper_util.join_strings(filename_list=[audit_error["transaction_id"], ack_filestring])
                    err_patient_acknowledgement = helper_util.get_acknowledgement_response(audit_error["transaction_id"],gc,vendor,adls)
                    audit_error["post_ack_time"] = helper_util.get_eastern_time_date()
                    values = [audit_error["transaction_id"],"",json.dumps(err_patient_acknowledgement),acknowledgement_filename,helper_util.get_eastern_time_date()]
                    db_helper.insert_data(DSP_CONSTANT.insert_dsp_ack_query,values,d4c)
                    db_helper.insert_data(DSP_CONSTANT.insert_dsp_ack_archive_query,values,d4c)
                    adl_helper.upload_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_ACKNOWLEDGEMENT_CONTAINER'],acknowledgement_filename,err_patient_acknowledgement,adls)
                    adl_helper.upload_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_ACKNOWLEDGEMENT_ARCHIVE_CONTAINER'],acknowledgement_filename,err_patient_acknowledgement,adls)
                    adl_helper.upload_data(gc[f'{vendor}_STORAGE_ACCOUNT_CONNECTION_STRING'], gc[f'{vendor}_ACKNOWLEDGEMENT_CONTAINER'],acknowledgement_filename,err_patient_acknowledgement,adls)
                    # delete from and to adls
                    try: adl_helper.delete_data(gc[f'{vendor}_STORAGE_ACCOUNT_CONNECTION_STRING'], gc[f'{vendor}_DSP_FHIR_CONTAINER'], blob.name,adls)
                    except: pass
                    try:adl_helper.delete_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_DSP_FHIR_CONTAINER'], blob.name,adls)
                    except: pass
                    # delete from processing
                    try: adl_helper.delete_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_DSP_CONTAINER'], blob.name,adls)
                    except: pass
                    audit_error["delete_source_time"] = helper_util.get_eastern_time_date()
                    try:
                        audit_error["bundle_audit_json"] = json.dumps(audit_error,sort_keys=False)
                        audit_error = {k: False if not v else v for k, v in audit_error.items() }
                        val = (audit_error["bundle_audit_json"],audit_error["transaction_id"])
                        db_helper.update_data(DSP_CONSTANT.update_statement,val,d4c)
                    except Exception as e: pass

customProcessor = CustomProcessor()
