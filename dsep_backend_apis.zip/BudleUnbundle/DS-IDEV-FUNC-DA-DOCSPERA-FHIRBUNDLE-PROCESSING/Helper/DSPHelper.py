import logging
import importlib
import json
import requests
import uuid 
import os 
from datetime import datetime
from pytz import timezone
from benedict import benedict
from ..Constants.DSPConstants import DSP_CONSTANT
from .DBHelper import db_helper
from .ADLHelper import adl_helper

search_string_present_but_null = DSP_CONSTANT.search_string_present_but_null 
expected_value_missing = DSP_CONSTANT.expected_value_missing
ack_filestring = DSP_CONSTANT.ack_filestring
err_filestring = DSP_CONSTANT.err_filestring


class DSPHelper:

    _instance = None
    def __new__(cls):
        if cls._instance is None:
            logging.info('Creating the object')
            cls._instance = super(DSPHelper, cls).__new__(cls)
        return cls._instance

    def search_helper(self, data, pattern, search_string,value_pattern):
        b = benedict(data, keypath_separator='/')
        identifiers = value = None
        try:
            pattern_matching = b.match(pattern)
            identifiers = search_string in pattern_matching
            value = b.match(value_pattern)[pattern_matching.index(search_string)]
        except (IndexError, ValueError):return None, None
        return identifiers, value      
 
     # return vedor specific parameter
    def get_config(self,config_data):
        searcher = {}
        
        for i in config_data: 
            searcher[i['key_parameters']] = i['value_parameters']
        #except Exception as e: logging.info(e)
        return searcher

    def gen_dict_extract(self, extract_from_dict, key):
        try:
            if hasattr(extract_from_dict, 'items'):
                for k, v in extract_from_dict.items():
                    if k.lower() == key:
                        yield v
                    if isinstance(v, dict):
                        for result in self.gen_dict_extract(v, key):
                            yield result
                    elif isinstance(v, list):
                        for d in v:
                            for result in self.gen_dict_extract(d, key):
                                yield result
        except Exception as e:
            logging.error(e)
    
    def search_json(self, json_to_search, transaction_id, gc,d4c,adls,search_string="",
                search_in_key="", where=""):
        if search_string:
            normalized_search_string = ''.join(
                filter(str.isalnum, search_string.lower().replace(" ", "")))
            return_string = ""
            for i in self.gen_dict_extract(json_to_search, search_in_key):
                try:
                    if isinstance(i, list) and isinstance(i[0], dict):
                        for index, j in enumerate(i):
                            if not where:
                                normalized_strings_in_list = list(
                                    map(lambda x: ''.join(filter(str.isalnum, x.lower().replace(" ", ""))),
                                        filter(lambda y: isinstance(y, str), i[index].values())))
                            else:
                                normalized_strings_in_list = list(
                                    map(lambda x: ''.join(filter(str.isalnum, x.lower().replace(" ", ""))),
                                        filter(lambda y: isinstance(y, str), i[index][where].values())))

                            if normalized_search_string in normalized_strings_in_list:
                                logging.info('%s', j)
                                if not i[index]['value']:
                                    return search_string_present_but_null
                                return i[index]['value']

                    elif isinstance(i, dict):
                        if not where:
                            normalized_strings_in_dict = list(
                                map(lambda x: ''.join(filter(str.isalnum, x.lower().replace(" ", ""))),
                                    filter(lambda y: isinstance(y, str), i.values())))
                        else:
                            normalized_strings_in_dict = list(
                                map(lambda x: ''.join(filter(str.isalnum, x.lower().replace(" ", ""))),
                                    filter(lambda y: isinstance(y, str), i[where].values())))

                        if normalized_search_string in normalized_strings_in_dict:
                            if not i['value']:
                                return search_string_present_but_null
                            return i['value']
                except AttributeError:
                    pass
                except IndexError:
                    pass
                except KeyError:
                    error_message = f"Key-value 'value': '{search_string}' missing when searching under {search_in_key} for transaction id: {transaction_id}."
                    logging.error(error_message)
                    textfilename = helper_util.join_strings(filename_list=[transaction_id, "SYNTAX", err_filestring], file_extension=".txt")
                    jsonfilename = helper_util.join_strings(filename_list=[transaction_id])
                    string_data = json.dumps(json_to_search)
                    values = [transaction_id,error_message,"error",string_data, self.get_eastern_time_date()]
                    db_helper.insert_data(DSP_CONSTANT.insert_dsp_error_query,values,d4c)
                    adl_helper.upload_data(gc["VELYS_CONNECTION_STRING"], gc["WORKFLOW_ERROR_CONTAINER"], textfilename,error_message,adls)
                    adl_helper.upload_data(gc["VELYS_CONNECTION_STRING"], gc["WORKFLOW_ERROR_CONTAINER"], jsonfilename,string_data,adls)
    

                    # Adl_Helper_obj.error_to_containers(transaction_id, "error", error_message, json.dumps(json_to_search), syntax_err_client,
                    #                     search_string.replace(" ", ""), db_connection)
                    return_string = expected_value_missing
            return return_string
    def return_from_resource_type(self, json_to_search, resource_type_check, patient_check):
        try:
            resources = json_to_search["entry"]
            for resource in resources:
                resource = json.loads(json.dumps(resource))
                try:
                    resource_type = resource["resource"]["resourceType"].lower()
                    if patient_check:
                        if resource_type == resource_type_check:
                            return True
                    elif resource_type == resource_type_check:
                        return resource
                except KeyError:
                    logging.exception(
                        "No json_data[entry][resource][resourceType]. Bundle not properly formatted.")
                    raise
        except KeyError:
            try:
                logging.exception(
                    "No json_data[entry]. Checking single resource-type")
                resource_type = json_to_search["resourceType"].lower()
                if patient_check:
                    if resource_type == resource_type_check:
                        return True
                elif resource_type == resource_type_check:
                    return json_to_search
                return False
            except:
                logging.exception("Uknown bundle type")
                raise
        return False

    def get_custom_id_from_patient_or_practitioner(self, data, is_individual_resource):
        logging.warn(
            f'------------------------------get_docspera_id_from_patient_or_practitioner: is_individual_resource: {is_individual_resource}')
        d = benedict(data)
        b = benedict(d, keypath_separator='/')
        docspera_id_list = []
        try:
            if is_individual_resource:
                docspera_id_list = b.match('identifier[*]/value')
            else:
                docspera_id_list = b.match('entry[*]/resource/identifier[*]/value')
            logging.warn(
                f'------------------------------get_docspera_id_from_patient_or_practitioner: RETURNIN DOCSPERA_ID from Patient or Practitioner: {docspera_id_list}')
            return docspera_id_list[0]
        except KeyError:
            raise
    
    def fhir_mr_extractor(self, data, system_, value_):
        d = benedict(data)
        b = benedict(d, keypath_separator='/')
        pattern_matcher = b.match(system_)
        for i in pattern_matcher:
            if 'MR' in i.split(":"):
                value_out = b.match(value_)[pattern_matcher.index(i)]
                return value_out
            
    def fhir_mr_extract(self, json_data):
        for entry in json_data["entry"]:
            for identifier in entry["resource"]["identifier"]:
                if "system" in identifier and identifier["system"].endswith(":MR"):
                    identifier_value = identifier["value"]
                    return identifier_value
                else: return None
    
    def generate_dsp_id(self, url):
        try:
            logging.info('Getting new patient id')
            response = requests.get(url, timeout=30)
            response.raise_for_status()
            new_id = response.text
            return new_id
        except requests.exceptions.RequestException as e:
            logging.error(
                "There was an error when generating a new UUID using API endpoint: %s", url)
            raise SystemExit(e)
    def get_fhir_client_id(self, json_data):
        d = benedict(json_data)
        patient_id = ""
        r =  d.search("reference", in_keys=True, in_values=False, exact=True, case_sensitive=True)
        try:
            for i in range(len(r)):
                if  r[i][0]['reference'].split('/')[0] == "Patient":
                    patient_id = r[i][0]['reference'].split('/')[1]
        except:
            pass
        check_client_id_exists = DSP_CONSTANT.check_client_id_exists
        row =  db_helper.fetch_one(check_client_id_exists.format(str("'") + patient_id + str("'")))
        if row: return row[0]["lmi_id"]
        return None
    
    def get_fhir_url_client_id(self,json_data):
        client_url =None
        resource = json_data['entry'][0]['resource']
        print(resource)
        d = benedict(resource)
        client_id = d.search("urn:uuid", in_keys=False, in_values=True,
                    exact=False, case_sensitive=False)
        if client_id: client_url = client_id[0][0]['reference'][9:] 
        else: pass
        if client_url: return client_url
        # check_client_id_exists = DSP_CONSTANT.check_client_url_map_exists
        # row =  db_helper.fetch_one(check_client_id_exists.format(str("'") + client_url + str("'")))
        # if row:  return row[0]["client_id"]
        return None
    
    def extract_vendor_id_from_single_resource(self,data, resource_type, is_bundle):
        # Extract docspera_id based on different type of resource groups
        try:
            logging.warn(
                f'-------------------------- extract_docspera_id_from_single_resource --------------------------')
            new_dict = {
                '(?i)entry[*]/resource/identifier[*]/value': ['patient', 'practitioner'],
                '(?i)entry[*]/resource/participant[*]/identifier[*]/value': ['appointment'],
                '(?i)entry[*]/resource/subject/identifier[*]/value': ['procedure', 'observation', 'diagnosticreport', 'medicationadministration', 'medicationstatement', 'medicationrequest', 'condition'],
                '(?i)entry[*]/resource/beneficiary/identifier[*]/value': ['coverage'],
                '(?i)entry[*]/resource/patient/identifier[*]/value': ['allergyintolerance']
            }

            individual_resource_dict = {
                '(?i)identifier[*]/value': ['patient', 'practitioner'],
                '(?i)participant[*]/actor/identifier[*]/value': ['appointment'],
                '(?i)subject/identifier/value': ['observation', 'procedure', 'condition'],
                '(?i)beneficiary/identifier/value': ['coverage']
            }
            d = benedict(data)
            b = benedict(d, keypath_separator='/')
            if is_bundle:
                for k, v in new_dict.items():
                    if resource_type in v:
                        logging.warn(
                            f'-------------------------- resource type found in value returning key_path: {k} --------------------------')
                        docspera_id_list = b.match(k)
                        logging.warn(
                            f'-------------------------- resource type found in value returning: {docspera_id_list} --------------------------')
                        return docspera_id_list[0]
            else:
                for k, v in individual_resource_dict.items():
                    logging.warn(
                        '---------------------------------------- Is Single Resource -----------------------------------------------')
                    if resource_type in v:
                        logging.warn(
                            f'-------------------------- resource type found in value returning key_path: {k} --------------------------')
                        docspera_id_list = b.match(k)
                        logging.warn(
                            f'-------------------------- resource type found in value returning: {docspera_id_list} --------------------------')
                        return docspera_id_list[0]
        except KeyError:
            logging.exception(
                "Unable to extract DocSpera Id from Non-Patient resource.")
            raise
    def get_vendor_specific_id(self, data):
        try:
            logging.warn(
                f'-------------------------- get_docspera_id --------------------------')
            logging.warn(
                f'-------------------------- {data} --------------------------')
            resource_type = data["entry"][0]['resource']['resourceType'].lower()
            logging.warn(
                f'-------------------------- {resource_type} --------------------------')
            return self.extract_vendor_id_from_single_resource(data, resource_type, True)
        except KeyError:
            try:
                logging.exception("No entry key. Checking single resource-type")
                logging.warn(
                    f'-------------------------- trying as single resource --------------------------')
                logging.warn(
                    f'-------------------------- {data} --------------------------')
                resource_type = data["resourceType"].lower()
                logging.warn(
                    f'-------------------------- {resource_type} --------------------------')
                return self.extract_vendor_id_from_single_resource(data, resource_type, False)
            except:
                logging.exception("Uknown bundle type")
                raise    
    def check_for_resource_id_errors(self, data, is_individual_resource):
        d = benedict(data)
        b = benedict(d, keypath_separator='/')
        try:
            if not is_individual_resource:
                resource_id_list = b.match('(?i)entry[*]/resource/id$')
                if len(resource_id_list) < 1 or not resource_id_list[0]:
                    return True
            else:
                resource_id_list = b.match('(?i)id$')
                if len(resource_id_list) < 1 or not resource_id_list[0]:
                    return True
            return False
        except IndexError:
            logging.exception("Resource ID field not present in Bundle")
            raise
    # return - YYYY/MM/DD - eg. 2022/08/21
    def _current_date(self):
        current_time = datetime.now()
        # TODO f format method to concat the strings
        return (str(current_time.year) + '/' + str(current_time.strftime("%m")) + '/' + str(current_time.strftime("%d")))

    # return time in eastern zone
    def get_eastern_time_date(self):
        return str(datetime.now(timezone('US/Eastern')))[:-13]

    # return time form current timezone to required
    def convert_datetime_timezone(self, date_value, tz1, tz2):
        dt = datetime.strptime(date_value,"%Y-%m-%d %H:%M:%S")
        dt = timezone(tz1).localize(dt).astimezone(timezone(tz2))
        return dt.strftime("%Y-%m-%d %H:%M:%S")

    #check for uuid compliance
    def uuid_validation(self,param_uuid):
        try:
            uuid.UUID(param_uuid)
            return True
        except ValueError: return False
    
    # check for json compliance
    def json_validation(self,raw_data):
        try:return True, json.loads(raw_data)
        except json.decoder.JSONDecodeError as err: return False,None
    
    def join_strings(self, filename_list=[], file_extension=".json", seperator="-"):
        if filename_list:
            if len(filename_list) == 1:
                return filename_list[0] + file_extension
            return seperator.join((filename_list)) + file_extension
    
    def fhir_resource_validator(self,fhir_type,resource_payload, txn_id):
        fhir_module=importlib.import_module(f'fhir.resources.{str(fhir_type).lower()}')
        fhir_function = getattr(fhir_module, fhir_type)
        try:
            fhir_function(**resource_payload)
            return True, None
        except Exception as e:
            logging.info(e)
            return False, e
    
    
    def fetch_id_types(self, data):
        d = benedict(data)
        b = benedict(d, keypath_separator='/')
        try:
            # "TODO" ternary operator
            resource_id_list = b.match('(?i)entry[*]/resource/id$')
            resource_types = b.match('(?i)entry[*]/resource/resourceType$') 
            return resource_id_list, resource_types
        except IndexError as err:
            logging.error(err)
            return None, None
    def get_mrn(self,data):
        try:
            #data_ = json.loads(data)
            d = benedict(data)
            oid = d.search("urn:oid", in_keys=False, in_values=True,
                        exact=False, case_sensitive=False)
            if oid:
                mrn = oid[0][0]['value']
                return mrn
            return ''
        except:return ""
    def check_is_individual_resource(self, json_data):
        try:
            data = json_data['entry']
            if data:return False
        except KeyError:
            data = json_data['resourceType']
            if data:return True
     
    def check_resource_type(self, json_data, resource_type_to_search):
        try:
            resource_type = json_data["entry"][0]['resource']['resourceType'].lower(
            )
            if resource_type == resource_type_to_search:
                return True
        except KeyError:
            resource_type = json_data['resourceType']
            if resource_type == resource_type_to_search:
                return True
        return False

    def get_acknowledgement_response(self, transaction_id,gc,vendor,adls, status_code=400, is_single_resource=False,
                                    *consistent_acknowledgement_fields,
                                    **consistent_acknoledgement_values):
        logging.warn(
            f'*************************************** Sendin Ack: is_single_practitioner: {is_single_resource}')
        try:
            if len(consistent_acknoledgement_values) != len(consistent_acknowledgement_fields):
                raise TypeError("""
                    Unexpected lengths for *args and **kwargs. Expected len(*args) == len(**kwargs.values).
                    These are the keys and values under the acknowledgement dictionary such that under obj.acknolwedgement -> 'args[i]' : kwargs.values[i])
                """)

            obj = {
                'transaction_id': transaction_id,
                'status': status_code,
                'acknowledgement': {
                }
            }

            if status_code == 400:
                return obj
            if status_code == 200:
                for field, val in zip(consistent_acknowledgement_fields, consistent_acknoledgement_values.values()):
                    if is_single_resource and field == gc[f'{vendor}_DSP_PAT_ID_STRING'] and not val:
                        continue
                    if is_single_resource and field == f"{vendor}_ID" and not val:
                        continue
                    obj['acknowledgement'][field] = val 
                    # if field == gc[f'{vendor}_NPI_PATTERN_STRING'] and not val:
                    #     del obj['acknowledgement'][gc[f'{vendor}_DSP_DOC_ID_STRING']]
                    #     del obj['acknowledgement'][gc[f'{vendor}_NPI_PATTERN_STRING']]
                return obj
        except TypeError as err:
            textfilename = self.join_strings(filename_list=[transaction_id, err_filestring], file_extension=".txt")
            adl_helper.upload_data(gc["VELYS_CONNECTION_STRING"], gc["WORKFLOW_ERROR_CONTAINER"], textfilename,str(err),adls)
    

    def post_to_urls(self,transaction_id, dsep_patient_id, oid, docspera_id, practitioner_id, national_provider_id,
                 practitioner_bool, is_single_resource, is_medication_resource,new_patient_bool,gc,vendor,adls):
        if dsep_patient_id or is_single_resource or is_medication_resource:
            logging.warning("inside post_to_urls")
            filename = self.join_strings(filename_list=[transaction_id, ack_filestring])
            status_code = 200
            acknowledgement_response = self.get_acknowledgement_response(transaction_id,gc,vendor,adls, status_code, is_single_resource,
                                                                    gc[f'{vendor}_DSP_PAT_ID_STRING'], "OID", f"{vendor}_ID",
                                                                     gc[f'{vendor}_DSP_DOC_ID_STRING'], gc[f'{vendor}_NPI_PATTERN_STRING'],
                                                                    dsep_patient_id=dsep_patient_id, oid=oid,
                                                                    docspera_id=docspera_id,
                                                                    practitioner_id=practitioner_id,
                                                                    national_provider_id=national_provider_id)
            '''
            unbundle_json = json.dumps(
                {"transaction_id": transaction_id, "dsep_patient_id": dsep_patient_id, "practitioner_id": practitioner_id,
                "national_provider_id": national_provider_id, "practitioner_bool": practitioner_bool, "is_medication_resource": is_medication_resource, "oid": oid,"patient_bool": new_patient_bool})
            '''
            unbundle_json = json.dumps(
                {"transaction_id": transaction_id, "dsep_patient_id": dsep_patient_id, "practitioner_id": practitioner_id,
                "national_provider_id": national_provider_id, "practitioner_bool": practitioner_bool,
                "is_medication_resource": is_medication_resource, "oid": oid,
                "patient_bool": new_patient_bool, "docspera_id": docspera_id, "vendor_name" : vendor})
            try:
                unbundle_response =  requests.post(gc[f'{vendor}_UNBUNDLE_URL'], unbundle_json)
                logging.warning(gc[f'{vendor}_UNBUNDLE_URL'])
                # unbundle_response =  requests.post(
                #     "http://localhost:5004/api/DS-IDEV-FUNC-DA-DOCSPERA-FHIRUNBUNDLE-PROCESSING",
                #     unbundle_json
                # )
                logging.info(unbundle_response.status_code)
            except Exception as e:
                logging.info(e)
            if not oid == gc['REDOX_OID']:
                requests.post(gc[f"{vendor}_ID_UPDATE_URL"] + filename, json.dumps(acknowledgement_response))
            return status_code
        
    def full_url_extractor(self, json_data):
        full_url_patient = None
        full_url_practitioner = []
        for i in json_data['entry']:
            try: 
                if i['request']['url'].lower() == "patient":full_url_patient = i['fullUrl'].split(':')[-1]
            except Exception as e: 
                logging.info(e)
                full_url_patient = None
            try:
                if i['request']['url'].lower() == "practitioner": full_url_practitioner.append(i['fullUrl'].split(':')[-1])
            except Exception as e: 
                logging.info(e)
                full_url_practitioner = None
        return full_url_patient, full_url_practitioner
        
    def handle_error(self, error_message, err_type, audit_fhir, file_data, gc, adls, kind, d4c):
        textfilename = self.join_strings(filename_list=[audit_fhir["transaction_id"], err_type, err_filestring], file_extension=".txt")
        jsonfilename = self.join_strings(filename_list=[audit_fhir["transaction_id"]])
        values = [audit_fhir["transaction_id"],error_message,file_data,kind,helper_util.get_eastern_time_date()]
        db_helper.insert_data(DSP_CONSTANT.insert_dsp_dlq_query,values,d4c)
        if kind == "dlq": error_container = gc["SYNTAX_ERROR_CONTAINER"] 
        else: error_container = gc["WORKFLOW_ERROR_CONTAINER"]
        adl_helper.upload_data(gc["VELYS_CONNECTION_STRING"], error_container, textfilename,error_message,adls)
        adl_helper.upload_data(gc["VELYS_CONNECTION_STRING"], error_container, jsonfilename, file_data,adls)
    
    def delete_helper(self,blob,vendor,gc,adls):
        # delete from and to adls con - A
        try: adl_helper.delete_data(gc[f'{vendor}_STORAGE_ACCOUNT_CONNECTION_STRING'], gc[f'{vendor}_DSP_FHIR_CONTAINER'], blob.name,adls)
        except: pass
        # delete from and to adls con - B
        try:adl_helper.delete_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_DSP_FHIR_CONTAINER'], blob.name,adls)
        except: pass
        # delete from processing
        try: adl_helper.delete_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_DSP_CONTAINER'], blob.name,adls)
        except: pass

    def handle_uuid_isjson_error(self, error_message, err_type, audit_fhir, decode_data, gc, adls, d4c, vendor=None):
        textfilename = self.join_strings(filename_list=[audit_fhir["transaction_id"], err_type, err_filestring], file_extension=".txt")
        jsonfilename = self.join_strings(filename_list=[audit_fhir["transaction_id"]])
        values = [audit_fhir["transaction_id"],error_message,decode_data,"dlq",helper_util.get_eastern_time_date()]
        db_helper.insert_data(DSP_CONSTANT.insert_dsp_dlq_query,values,d4c)
        adl_helper.upload_data(gc["VELYS_CONNECTION_STRING"], gc["SYNTAX_ERROR_CONTAINER"], textfilename,error_message,adls)
        adl_helper.upload_data(gc["VELYS_CONNECTION_STRING"], gc["SYNTAX_ERROR_CONTAINER"], jsonfilename, decode_data,adls)
        self.err_ack_helper(audit_fhir["transaction_id"],gc, None,vendor, d4c, adls)
    
    def err_ack_helper(self, transaction_id,gc,dsp_id,vendor, d4c, adls):
        acknowledgement_filename =  self.join_strings(filename_list=[transaction_id, ack_filestring])
        patient_acknowledgement = self.get_acknowledgement_response(transaction_id,gc,vendor,adls)
        values = [transaction_id,dsp_id,patient_acknowledgement,acknowledgement_filename,helper_util.get_eastern_time_date()]
        db_helper.insert_data(DSP_CONSTANT.insert_dsp_ack_query,values,d4c)
        db_helper.insert_data(DSP_CONSTANT.insert_dsp_ack_archive_query,values,d4c)
        adl_helper.upload_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_ACKNOWLEDGEMENT_CONTAINER'],acknowledgement_filename,patient_acknowledgement,adls)
        adl_helper.upload_data(gc['VELYS_CONNECTION_STRING'], gc[f'{vendor}_ACKNOWLEDGEMENT_ARCHIVE_CONTAINER'],acknowledgement_filename,patient_acknowledgement,adls)
        adl_helper.upload_data(gc[f'{vendor}_STORAGE_ACCOUNT_CONNECTION_STRING'], gc[f'{vendor}_ACKNOWLEDGEMENT_CONTAINER'],acknowledgement_filename,patient_acknowledgement,adls)

helper_util = DSPHelper()
