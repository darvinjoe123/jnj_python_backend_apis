import os, logging, pymysql, ast
from dbutils.pooled_db import PooledDB
from pytz import timezone
from datetime import datetime

db_details = os.environ['DB_DETAILS'].split(',')
pool_config = os.environ['POOLING_DETAILS'].split(',')
MYSQL_CONFIG ={
    "host": db_details[0],
    "port": int(db_details[1]),
    "db": db_details[2],
    "password": os.environ['DB_PASSWORD'],
    "user": os.environ['DB_USER_NAME'],
    "charset": db_details[3],
    "cursorclass": pymysql.cursors.DictCursor,
    "autocommit": ast.literal_eval(db_details[4]),
}
POOL_CONFIG = {
    # Modules using linked databases
    "creator": pymysql,
    "maxconnections": int(pool_config[0]),
    "mincached": int(pool_config[1]),
    "maxcached": int(pool_config[2]),
    "maxshared": int(pool_config[3]),
    "blocking": ast.literal_eval(pool_config[4]),
    "maxusage": ast.literal_eval(pool_config[5]),
    "setsession": [],
    "ping": int(pool_config[6]),
}

POOL = PooledDB(**MYSQL_CONFIG, **POOL_CONFIG)

class DBHelper:
    def __init__(self):
        self._connection = POOL.connection()
        self._cursor = self._connection.cursor()
        
    # fetch single record from matched query and args
    def fetch_one(self, sql, args=None,d4c=True):
        if d4c:
            self._cursor.execute(sql, args)
            result = self._cursor.fetchone()
            return result
        
    # fetch all records from matched query and args
    def fetch_all(self, sql,args=None,d4c=True):
        if d4c:
            self._cursor.execute(sql, args)
            result = self._cursor.fetchall()
            return result
        
    # insert and update records into database 
    def insert_data(self,sql,args=None,d4c=True):
        if d4c:
            try:
                if args: sql=sql.format(','.join(['%s']*len(args)))
                self._cursor.execute(sql,args)
                return "success"
            except Exception as e:
                logging.info(e)
                return "no success"
            
        
    def update_data(self,sql,args=None,d4c=True):
        if d4c:
            try:self._cursor.execute(sql,args)
            except Exception as e:logging.info(e)
            return "success"
   
    def __del__(self):
        self._connection.close()


db_helper = DBHelper()