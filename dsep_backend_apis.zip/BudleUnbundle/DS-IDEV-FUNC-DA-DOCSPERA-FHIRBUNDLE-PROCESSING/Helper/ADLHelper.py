import logging 
import json
from azure.storage.blob import BlobServiceClient, ContentSettings

class ADLHelper:    
    _instance = None
    def __new__(cls):
        if cls._instance is None:
            logging.info('Creating the object')
            cls._instance = super(ADLHelper, cls).__new__(cls)
        return cls._instance
    
    def adl_connection(self,source_container_connection_string,source_container_name):
        try:
            blob_source_service_client = BlobServiceClient.from_connection_string(source_container_connection_string)
            source_container_client = blob_source_service_client.get_container_client(source_container_name)
            return source_container_client  
        except Exception as ex:
            logging.info(ex)

    # Method used to retrieve the list of blob from container name passed as params
    def list_data(self, source_container_connection_string_, source_container_name,adls,list_prefix=None):
        if adls:
            container_instance = self.adl_connection(source_container_connection_string_, source_container_name)
            return container_instance.list_blobs(name_starts_with=list_prefix)

    def get_data(self, source_container_connection_string_, source_container_name,blob_name,adls):
        if adls:
            try:
                container_instance = self.adl_connection(source_container_connection_string_, source_container_name)
                return (container_instance.get_blob_client(blob=blob_name)).download_blob().readall()
            except Exception as e:
                logging.warn(e)

    def delete_data(self, source_container_connection_string_, source_container_name,blob_name,adls):
        if adls:
            container_instance = self.adl_connection(source_container_connection_string_, source_container_name)
            container_instance.delete_blob(blob_name)
    
    def upload_data(self, source_container_connection_string_, source_container_name, blob_name,blob_data,adls):
        if adls:
            container_instance = self.adl_connection(source_container_connection_string_, source_container_name)
            try: blob_data = json.dumps(blob_data).encode('utf-8')
            except: blob_data = blob_data
            (container_instance.get_blob_client(blob=blob_name)).upload_blob(blob_data, content_settings=ContentSettings(content_type="application/json"), overwrite=True)

adl_helper = ADLHelper()