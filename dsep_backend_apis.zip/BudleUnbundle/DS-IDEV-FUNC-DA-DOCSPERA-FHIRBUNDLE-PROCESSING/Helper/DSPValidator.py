import logging, json, uuid
from benedict import benedict
import importlib
from .DSPHelper import helper_util
from .ADLHelper import adl_helper
from .DBHelper  import db_helper
from ..Constants.DSPConstants import DSP_CONSTANT

ack_filestring = "ACK"


class DSPValidator:

    _instance = None
    def __new__(cls):   
        if cls._instance is None:
            logging.info('Creating the object')
            cls._instance = super(DSPValidator, cls).__new__(cls)
        return cls._instance

    def __init__(self):
       logging.info("this is audit helper")
    
    #return vendor specific validation
    def is_uuid(self, param_uuid):
        try:
            uuid.UUID(param_uuid)
            return True
        except ValueError as err:
            logging.error(err)
            return False

    def is_json(self, raw_data):
        try:
            json.loads(raw_data)
            return True  # json is valid
        except json.decoder.JSONDecodeError as err:
            logging.error(err)
            return False

    def fetch_id_types(self, data):
        d = benedict(data)
        b = benedict(d, keypath_separator='/')
        try:
            # "TODO" ternary operator
            resource_id_list = b.match('(?i)entry[*]/resource/id$')
            resource_types = b.match('(?i)entry[*]/resource/resourceType$') 
            return resource_id_list, resource_types
        except IndexError as err:
            logging.error(err)
            return None, None

    # fhir resources validator
    def fhir_resource_validator(self, fhir_type, resource_payload):
        fhir_module=importlib.import_module(f'fhir.resources.{str(fhir_type).lower()}')
        fhir_function = getattr(fhir_module, fhir_type)
        try:
            fhir_function(**resource_payload)
            return True
        except Exception as err:
            logging.error(err)
            return False
        
    def custom_validate (self, audit, gc, vendor, data):
        json_data = json.loads(data)
        search_data = benedict(json_data)
        resources_ids, resources_types = self.fetch_id_types(json_data)
        #blob failed due to reason
        if(len(resources_ids) > 1 and audit["is_json"] and audit["is_uuid"]):
            npi_id = mrn = dsp_patient_id= dsp_practitioner_id=  None
            is_patient_bool = is_medication = is_single_resource = new_practitioner_bool = is_single_practitioner = False
            if(len(resources_ids) == 1): 
                is_single_resource = True
                if(resources_types in ["patient"]):
                    # call npi - generic method using benedict
                    mrn = helper_util.benedict_helper(search_data,gc[f'{vendor}_MRN_ID_PATTERN'],gc[f'{vendor}_MRN_PATTERN_STRING'],gc[f'{vendor}_MRN_ID_VALUE'])
                    dsp_patient_id = helper_util.benedict_helper(search_data,gc[f'{vendor}_DSP_PAT_ID_PATTERN'],gc[f'{vendor}_DSP_PAT_ID_STRING'],gc[f'{vendor}_DSP_PAT_ID_VALUE'])
                    is_patient_bool = True
                if(resources_types in ["practitioner"]):
                    new_practitioner_bool = is_single_practitioner = True
                    # call npi - generic method using benedict
                    npi_id = helper_util.benedict_helper(search_data,gc[f'{vendor}_NPI_ID_PATTERN'],gc[f'{vendor}_NPI_PATTERN_STRING'],gc[f'{vendor}_NPI_ID_VALUE'])
                    dsp_practitioner_id = helper_util.benedict_helper(search_data,gc[f'{vendor}_DSP_DOC_ID_PATTERN'],gc[f'{vendor}_DSP_DOC_ID_STRING'],gc[f'{vendor}_DSP_DOC_ID_VALUE'])
            patient_vendor_id = helper_util.benedict_helper(search_data,gc[f'{vendor}_PAT_ID_PATTERN'],gc[f'{vendor}_PAT_PATTERN_STRING'],gc[f'{vendor}_PAT_ID_VALUE'])
            practitioner_vendor_id = helper_util.benedict_helper(search_data,gc[f'{vendor}_DOC_ID_PATTERN'],gc[f'{vendor}_DOC_PATTERN_STRING'],gc[f'{vendor}_DOC_ID_VALUE'])
            # skip for all master resource types       
            if(resources_types in ["medication"]):
                is_medication = True
            audit["resources"] = resources_types
            audit["is_single_resource"] = is_single_resource
            audit["is_single_practitioner"] = is_single_practitioner
            audit["is_medication"] = is_medication
            audit["new_practitioner_bool"] = new_practitioner_bool
            audit["is_patient_bool"] = is_patient_bool
            audit["npi_id"] = npi_id
            audit["mrn"] = mrn
            audit['dsp_patient_id'] = dsp_patient_id
            audit['dsp_practitioner_id'] = dsp_practitioner_id
            audit['patient_vendor_id'] = patient_vendor_id
            audit['practitoner_vendor_id'] = practitioner_vendor_id
            return True, audit
        else:
            pass

    #For loop each blob
    def _validate(self, audit, param_uuid,gc,vendor, data,blob,d4c, adls):
        # "TODO" save to archive
        audit["is_uuid"] = self.is_uuid(param_uuid)
        audit["is_json"] = self.is_json((json.dumps(data)))
        json_data = json.loads(data)
        search_data = benedict(json_data)
        resources_ids, resources_types = self.fetch_id_types(json_data)
        #blob failed due to reason
        if(len(resources_ids) > 1 and audit["is_json"] and audit["is_uuid"]):
            npi_id = mrn = ""
            is_patient_bool = is_medication = is_single_resource = new_practitioner_bool = is_single_practitioner = False
            if(len(resources_ids) == 1): 
                is_single_resource = True
                if(resources_types in ["patient"]):
                    # call npi - generic method using benedict
                    mrn = helper_util.benedict_helper(search_data,gc[f'{vendor}_ID_PATTERN'],gc[f'{vendor}_MRN_PATTERN_STRING'],gc[f'{vendor}_ID_VALUE'])
                    is_patient_bool = True
                if(resources_types in ["practitioner"]):
                    new_practitioner_bool = is_single_practitioner = True
                    # call npi - generic method using benedict
                    npi_id = helper_util.benedict_helper(search_data,gc[f'{vendor}_ID_PATTERN'],gc[f'{vendor}_NPI_PATTERN_STRING'],gc[f'{vendor}_ID_VALUE'])
            # skip for all master resource types       
            if(resources_types in ["medication"]):
                is_medication = True
            audit["is_single_resource"] = is_single_resource
            audit["is_single_practitioner"] = is_single_practitioner
            audit["is_medication"] = is_medication
            audit["new_practitioner_bool"] = new_practitioner_bool
            audit["is_patient_bool"] = is_patient_bool
            audit["npi_id"] = npi_id
            audit["mrn"] = mrn
            return audit
        else: #blob failed due to reason
            # "TODO" remove the blob item from the array
            # "TODO" save to error or dlq
            status_code = 400
            transaction_id = blob.name.split('/')[1][:-5]
            acknowledgement_filename = helper_util.join_strings(filename_list=[transaction_id, ack_filestring])
            err_patient_acknowledgement = helper_util.get_acknowledgement_response(transaction_id,gc,adls)
            try: adl_helper.delete_data(gc[f'{vendor}_STORAGE_ACCOUNT_CONNECTION_STRING'], gc[f'{vendor}_DSEP_CONTAINER'], blob.name,adls)
            except: pass
            audit["delete_source_time"] = helper_util.get_eastern_time_date()
            audit['fhir_error'] = "json is invalid" if not audit["is_json"] else "invalid file name"
            db_helper.insert_data(DSP_CONSTANT.insert_statement.format(fields=(",".join(list(audit.keys()))),values=tuple(audit.values())),None,d4c)
         
            return False
        
dspValidator = DSPValidator()
