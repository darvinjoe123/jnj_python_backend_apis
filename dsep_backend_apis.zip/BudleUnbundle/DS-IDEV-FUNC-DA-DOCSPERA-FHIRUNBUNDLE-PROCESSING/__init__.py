import datetime
import json
import logging
import os
import traceback
from xmlrpc.client import boolean
import azure.functions as func
from .unbundle import unbundle_json, _create_blob_client
from .fhir_schema_validator import fhir_schema_validation
from ._save_db import _save_error_db,error_value_exists, get_date
from .Db_Helper import db_helper_obj
from .dsp_constants import *
import aiohttp
import asyncio


# Hard Coded App Settings

WORKFLOW_ERROR_CONTAINER = 'docspera-error'
DLQ_CONTAINER = 'docspera-dlq'



def get_date_string():
    current_time = datetime.datetime.now()
    year = current_time.year
    month = current_time.strftime("%m")
    day = current_time.strftime("%d")
    return str(year) + '/' + str(month) + '/' + str(day)

async def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    current_time = datetime.datetime
    logging.warn(f"starting time {get_date()}")
    transaction_id = dsep = practitioner_id = vendor_name = national_provider_id = practitioner_bool = is_medication_resource = oid = docspera_id = patient_bool =  None
    req_body = req.get_json()
    
    if not transaction_id:
        transaction_id = req_body.get('transaction_id')
        logging.warn(f"this is txn_id {transaction_id}")
    if not dsep:
        dsep = req_body.get('dsep_patient_id') 
    
    if not practitioner_id:
        practitioner_id = req_body.get('practitioner_id') 
    
    if not national_provider_id:
        national_provider_id = req_body.get('national_provider_id')
    
    if not oid:
        oid = req_body.get('oid') 
        logging.warn(f"this is oid {oid} ")
    
    if not patient_bool:
        patient_bool = req_body.get('patient_bool')
        logging.warn(patient_bool)

    if not docspera_id:
        docspera_id = req_body.get('docspera_id')
        logging.warn(docspera_id)

    if not practitioner_bool:
        practitioner_bool = req_body.get('practitioner_bool')

    if not vendor_name:
        vendor_name = req_body.get('vendor_name')
        logging.info(vendor_name)
            
    #velys storage account
    dsp_velys_blob_client = _create_blob_client(os.environ['VELYS_STORAGE_ACCOUNT_NAME'], os.environ['VELYS_CONNECTION_STRING'])
    #temp - container inside velys storage account - Error json or message
    error_container_client = dsp_velys_blob_client.get_container_client(container=WORKFLOW_ERROR_CONTAINER)    

    try:
        if transaction_id: 
            logging.warn("trying to get")
            raw_data = None
            pickup_archive_fhir_timestamp=pickup_archive_fhir=schema_validation_start_timestamp=fhir_schema_validation_type=schema_validation_end_timestamp=None
            unbundle_json_dict = {}
            data = db_helper_obj.fetch_one(get_raw_data_query.format(str("'") + transaction_id + str("'")))
            for i in data:
                raw_data = data['bundle_json']
            json_to_unbundle = transaction_id + ".json"
            docspera_error = transaction_id + ".error"
            if raw_data:
                client_data = db_helper_obj.get_client_parameters()
                pickup_archive_fhir_timestamp = get_date()
                pickup_archive_fhir = True
                raw_data_dict = json.loads(raw_data)
                schema_validation_start_timestamp= get_date()
                if os.environ['validation_method'] != "no_validation":
                    logging.error("not equal no validation")
                    error_list = fhir_schema_validation(raw_data_dict, json_to_unbundle)

                    if len(error_list) > 0:
                        for error_lists in error_list:
                            filename = error_lists.get('file_name')
                            filename_split = filename.split(".")[0:-1]
                            filename_join = ".".join(filename_split)
                            resourcename = error_lists.get('resource_name')
                            path = error_lists.get('path')
                            error = error_lists.get('error')
                            error_line_no = error_lists.get('error_line_no')
                            resourceid = error_lists.get('resource_id')
                            error_value_exists(filename_join, resourcename, path, error, str(error_line_no), resourceid, db_helper_obj)

                    if os.environ['validation_method'] == "validation_only":
                        logging.error("only schema validation")
                        fhir_schema_validation_type = "validation_only"
                        schema_validation_end_timestamp = get_date()
                        unbundle_json_dict['pickup_archive_fhir'] = pickup_archive_fhir
                        unbundle_json_dict['pickup_archive_fhir_timestamp'] = pickup_archive_fhir_timestamp
                        unbundle_json_dict['fhir_schema_validation_type'] = fhir_schema_validation_type
                        unbundle_json_dict['schema_validation_start_timestamp'] = schema_validation_start_timestamp
                        unbundle_json_dict['schema_validation_end_timestamp'] = pickup_archive_fhir
                        unbundle_json_dict['transaction_id'] = pickup_archive_fhir
                        async with aiohttp.ClientSession() as session:
                            tasks = []
                        tasks.append(unbundle_json(raw_data, transaction_id, oid,
                                dsep, practitioner_id, national_provider_id, practitioner_bool, patient_bool, db_helper_obj,
                                docspera_id, vendor_name, client_data, unbundle_json_dict))
                        await asyncio.gather(*tasks, return_exceptions=True)
                    if os.environ['validation_method'] == "block_by_validation":
                        logging.error("block by validation in")
                        fhir_schema_validation_type = "block_by_validation"
                        if len(error_list) != 0:
                            dlq_container = dsp_velys_blob_client.get_container_client(
                                container=DLQ_CONTAINER)
                            error_text = "Error during processing: " + json_to_unbundle + " US core profile validation error."
                            error_list_dump = json.dumps(error_list)
                            error_text_dlq = str(error_text) + "\n\n" + str(error_list_dump).replace(",", ",\n")


                            blob_txt_name = transaction_id + "_VALIDATION_ERR.txt"

                            blob_client = dlq_container.get_blob_client(blob=json_to_unbundle)
                            blob_client.upload_blob(raw_data, overwrite=True)

                            blob_text_client = dlq_container.get_blob_client(blob=blob_txt_name)
                            blob_text_client.upload_blob(error_text_dlq, overwrite=True)

                            blob_client = error_container_client.get_blob_client(blob=json_to_unbundle)
                            blob_client.upload_blob(raw_data, overwrite=True)

                            error_container_error = "FHIR Schema Validation Error"
                            error_text_error_container = str(error_container_error) + "\n\n" + str(error_list_dump).replace(",", ",\n")

                            blob_client = error_container_client.get_blob_client(blob=docspera_error)
                            blob_client.upload_blob(error_text_error_container, overwrite=True)

                            # dlq
                            _save_error_db(raw_data, transaction_id, error_text,db_helper_obj)
                            schema_validation_end_timestamp = get_date()
                            return func.HttpResponse("Validation Failed", status_code=400)

                        else:
                            schema_validation_end_timestamp = get_date()
                            logging.error("block by validation")
                            fhir_schema_validation_type = "block_by_validation"
                            unbundle_json_dict['pickup_archive_fhir'] = pickup_archive_fhir
                            unbundle_json_dict['pickup_archive_fhir_timestamp'] = pickup_archive_fhir_timestamp
                            unbundle_json_dict['fhir_schema_validation_type'] = fhir_schema_validation_type
                            unbundle_json_dict['schema_validation_start_timestamp'] = schema_validation_start_timestamp
                            unbundle_json_dict['schema_validation_end_timestamp'] = pickup_archive_fhir
                            unbundle_json_dict['transaction_id'] = pickup_archive_fhir
                            async with aiohttp.ClientSession() as session:
                                tasks = []
                            tasks.append(unbundle_json(raw_data, transaction_id, oid,
                                dsep, practitioner_id, national_provider_id, practitioner_bool,
                                patient_bool, db_helper_obj, docspera_id, vendor_name, client_data, unbundle_json_dict))
                            await asyncio.gather(*tasks, return_exceptions=True)
                else:
                    logging.error("validation not")
                    try:
                        async with aiohttp.ClientSession() as session:
                            tasks = []
                            fhir_schema_validation_type = "no_validation"
                            unbundle_json_dict['pickup_archive_fhir'] = pickup_archive_fhir
                            unbundle_json_dict['pickup_archive_fhir_timestamp'] = pickup_archive_fhir_timestamp
                            unbundle_json_dict['fhir_schema_validation_type'] = fhir_schema_validation_type
                            unbundle_json_dict['schema_validation_start_timestamp'] = schema_validation_start_timestamp
                            unbundle_json_dict['schema_validation_end_timestamp'] = pickup_archive_fhir
                            unbundle_json_dict['transaction_id'] = pickup_archive_fhir
                            tasks.append(unbundle_json(raw_data, transaction_id, oid,
                                        dsep, practitioner_id, national_provider_id,
                                        practitioner_bool, patient_bool, db_helper_obj, docspera_id, vendor_name, client_data, unbundle_json_dict))
                        await asyncio.gather(*tasks, return_exceptions=True)
                    except Exception as e:
                        logging.info(e)
                    # unbundle_json(unbundle_container_client, error_container_client, raw_data, transaction_id, oid,
                    #               dsep, practitioner_id, national_provider_id, practitioner_bool, patient_bool, db_helper_obj, docspera_id)
            return func.HttpResponse("Successfull", status_code=200)
                # else:

                #     error_message = f"Error during processing: {transaction_id}. Invalid UUID."
                #     error_to_containers(transaction_id[:-5], "dlq", error_message, raw_data, syntax_err_client, "UUID", db_helper_obj)
                #     return func.HttpResponse("Failed",status_code=400)

    except Exception as e:
        logging.info(f'Error during unbundle for blob: {transaction_id}.json. \n{traceback.format_exc()}')