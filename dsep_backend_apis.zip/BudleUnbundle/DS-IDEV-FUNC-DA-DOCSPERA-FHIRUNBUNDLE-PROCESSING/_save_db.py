import logging
from sre_constants import SUCCESS
from mysql.connector import connect
from datetime import datetime
import os
from pytz import timezone
from .dsp_constants import *
from .Db_Helper import db_helper_obj
error_list_insert_query ="""INSERT INTO error_analytics (transaction_id,resource_name,path,error,error_line_no,resource_id,created_on) VALUES """
insert_dsp_dlq_query =  """INSERT INTO dlq (transaction_id, error, file, type,created_on) VALUES """

# ====================

def get_date():
    tz = timezone('US/Eastern')
    time_stamp = str(datetime.now(tz))[:-13]
    return time_stamp

def _save_error_db(raw_data, txn_id, error_message,db_connection):
    my_json = raw_data.decode('utf8').replace("'", '"')
    query = insert_dsp_dlq_query
    value = (txn_id,error_message,my_json,'dlq',get_date())
    db_connection._cursor.execute(query + str(value))
    logging.info("error data inserted into docspera-error")


def error_value_exists(filename,resourcename,path,error,error_line_no,resourceid, db_connection):
    logging.error('db entry')
    value = (filename, resourcename, path, error, error_line_no, resourceid, get_date())
    db_connection._cursor.execute(error_list_insert_query + str(value))
    logging.error("error analytics db error ")
    print("data inserted ")
    logging.info("data inserted successfully in error analytics db !! ")
    return "success"





