import json
import logging
import re
import jsoncfg
import numpy as np
from .unbundle import *
from .unbundle import _get_fhir_schema_blob_data


def fhir_schema_validation(json_file, file_name):

    error_list = []

    class NpEncoder(json.JSONEncoder):
        def default(self, obj):
            if isinstance(obj, np.integer):
                return int(obj)
            if isinstance(obj, np.floating):
                return float(obj)
            if isinstance(obj, np.ndarray):
                return obj.tolist()
            return super(NpEncoder, self).default(obj)

    def get_router(schema_path_get_item, rule):
        get_array_split = schema_path_get_item.split("/")
        get_array_ref_path = rule.get(get_array_split[1]).get(get_array_split[2])
        return get_array_ref_path

    def array_choice_validation(input_json, curr_rule):

        value = False
        if type(input_json).__name__ == "list":
            for i in input_json:
                if i in curr_rule:
                    value = True
                else:
                    value = False
        else:
            value = False
        return value

    def datatype_validation(definitions, input_js, rule, bundle_name, resource_name, resource_id, line_no_input):
        if definitions.get("properties"):
            definitions_json = definitions.get("properties")
            # first level required validation
            definitions_requireds = definitions.get("required")
            for definitions_required in definitions_requireds:
                if input_js.get(definitions_required) is None:
                    # 1st level required error
                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                  "path": "root" + "/" + definitions_required,
                                  "error": "Required field is not available.",
                                  "error_line_no": "N/A",
                                  "resource_id": resource_id
                                  }
                    error_list.append(error_json)
            definitions_keys = list(definitions_json.keys())
            for definitions_key in definitions_keys:
                if input_js.get(definitions_key) is not None:
                    schema_path_get = definitions_json.get(definitions_key)
                    # 1st level const
                    if schema_path_get.get("const"):
                        if input_js.get(definitions_key) != schema_path_get.get("const"):
                            # 1st level const error
                            line_no = jsoncfg.node_location(line_no_input[definitions_key]).line
                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                          "path": "root" + "/" + definitions_key,
                                          "error": "Const value not match",
                                          "error_line_no": line_no,
                                          "resource_id": resource_id
                                          }
                            error_list.append(error_json)
                    if schema_path_get.get("enum"):
                        if input_js.get(definitions_key) not in schema_path_get.get("enum"):
                            line_no = jsoncfg.node_location(line_no_input[definitions_key]).line
                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                          "path": "root" + "/" + definitions_key,
                                          "error": "Incorrect value",
                                          "error_line_no": line_no,
                                          "resource_id": resource_id
                                          }
                            error_list.append(error_json)
                    # 1st level (type) datatype validation
                    if schema_path_get.get("type"):
                        if (type(input_js.get(definitions_key)).__name__.lower().replace(
                                'str',
                                'string').replace(
                            'list', 'array').replace('bool', 'boolean').replace("int", "number").replace(
                            "dict", "object").replace(
                            "float", "number")) == schema_path_get.get("type"):
                            if schema_path_get.get("items"):
                                if schema_path_get.get("items").get('enum'):
                                    if not array_choice_validation(input_js.get(definitions_key),
                                                                   schema_path_get.get("items").get('enum')):
                                        line_no = jsoncfg.node_location(line_no_input[definitions_key]).line
                                        error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                      "path": "root" + "/" + definitions_key,
                                                      "error": "Incorrect value",
                                                      "error_line_no": line_no,
                                                      "resource_id": resource_id
                                                      }
                                        error_list.append(error_json)
                                if schema_path_get.get("items").get('type'):
                                    if type(input_js.get(definitions_key)).__name__.lower().replace(
                                            'str', 'string').replace('list', 'array').replace('bool',
                                                                                              'boolean').replace(
                                        "int",
                                        "number").replace(
                                        "dict", "object").replace(
                                        "float", "number") == schema_path_get.get("items").get('type'):
                                        if schema_path_get.get("items").get('pattern'):
                                            if not re.match(str(schema_path_get.get("items").get('pattern')),
                                                            str(input_js.get(definitions_key))):
                                                line_no = jsoncfg.node_location(line_no_input[definitions_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key,
                                                              "error": "Pattern is not match.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                    else:
                                        line_no = jsoncfg.node_location(line_no_input[definitions_key]).line
                                        error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                      "path": "root" + "/" + definitions_key,
                                                      "error": "Datatype is not valid.",
                                                      "error_line_no": line_no,
                                                      "resource_id": resource_id
                                                      }
                                        error_list.append(error_json)
                                elif schema_path_get.get("items").get('$ref'):
                                    array_validation(schema_path_get.get("items").get('$ref'), input_js, rule,
                                                     definitions_key, bundle_name, resource_name, resource_id,
                                                     line_no_input)
                            # 1st level (pattern) datatype validation
                            if schema_path_get.get("pattern"):
                                if not re.match(str(schema_path_get.get("pattern")),
                                                str(input_js.get(definitions_key))):
                                    # pattern error
                                    line_no = jsoncfg.node_location(line_no_input[definitions_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key,
                                                  "error": "Pattern is not match.",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                        else:
                            # 1st level type error
                            line_no = jsoncfg.node_location(line_no_input[definitions_key]).line
                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                          "path": "root" + "/" + definitions_key,
                                          "error": "Datatype is not valid.",
                                          "error_line_no": line_no,
                                          "resource_id": resource_id
                                          }
                            error_list.append(error_json)
                    # ref->path->type validation
                    if schema_path_get.get("$ref"):
                        ref_path = get_router(schema_path_get.get("$ref"), rule)
                        if ref_path.get("type"):
                            if (type(input_js.get(definitions_key)).__name__.lower().replace(
                                    'str',
                                    'string').replace(
                                'list', 'array').replace('bool', 'boolean').replace("int", "number").replace(
                                "dict", "object").replace(
                                "float", "number")) == ref_path.get("type"):
                                # ref->path->pattern validation
                                if ref_path.get("pattern"):
                                    if not re.match(str(ref_path.get("pattern")), str(input_js.get(definitions_key))):
                                        # pattern error
                                        line_no = jsoncfg.node_location(line_no_input[definitions_key]).line
                                        error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                      "path": "root" + "/" + definitions_key,
                                                      "error": "Pattern is not match.",
                                                      "error_line_no": line_no,
                                                      "resource_id": resource_id
                                                      }
                                        error_list.append(error_json)
                            else:
                                # 1st level datatype error
                                line_no = jsoncfg.node_location(line_no_input[definitions_key]).line
                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                              "path": "root" + "/" + definitions_key,
                                              "error": "Datatype is not valid.",
                                              "error_line_no": line_no,
                                              "resource_id": resource_id
                                              }
                                error_list.append(error_json)
                        # object validation
                        elif schema_path_get.get("$ref"):
                            obj_validation(schema_path_get, rule, definitions_key, input_js, bundle_name,
                                           resource_name, resource_id, line_no_input)

    # array_start
    def array_validation(schema_path_get, input_js, rule, definitions_key, bundle_name, resource_name, resource_id,
                         line_no_input):
        get_array_data = get_router(schema_path_get, rule)
        if get_array_data.get('properties'):
            array_keys = list(get_array_data.get('properties').keys())
            input_listtype = input_js.get(definitions_key)
            for input_len in range(len(input_listtype)):
                if get_array_data.get("required"):
                    for definitions_required in get_array_data.get("required"):
                        if input_listtype[input_len].get(definitions_required) is None:
                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                              input_len) + "]/" + definitions_required,
                                          "error": "Array required field is not available.",
                                          "error_line_no": "N/A",
                                          "resource_id": resource_id
                                          }
                            error_list.append(error_json)
                for array_key in array_keys:
                    if isinstance(input_listtype[input_len], dict):
                        input_array_valid = input_listtype[input_len].get(array_key)
                        if input_array_valid is not None:
                            get_array_key = get_array_data.get('properties').get(array_key)
                            if get_array_key.get("const"):
                                if input_array_valid != get_array_key.get("const"):
                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][input_len][array_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                      input_len) + "]/" + array_key,
                                                  "error": "Array const value not match",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                            if get_array_key.get('enum'):
                                if input_array_valid not in get_array_key.get('enum'):
                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][input_len][array_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                      input_len) + "]/" + array_key,
                                                  "error": "Array incorrect value",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                            if get_array_key.get('type'):
                                if type(input_array_valid).__name__.lower().replace(
                                        'str', 'string').replace('list', 'array').replace('bool',
                                                                                          'boolean').replace(
                                    "int",
                                    "number").replace(
                                    "dict", "object").replace("float", "number") == get_array_key.get('type'):
                                    if get_array_key.get("items"):
                                        if get_array_key.get("items").get('type'):
                                            if type(input_array_valid).__name__.lower().replace(
                                                    'str', 'string').replace('list', 'array').replace('bool',
                                                                                                      'boolean').replace(
                                                "int",
                                                "number").replace(
                                                "dict", "object").replace("float", "number") == get_array_key.get(
                                                "items").get(
                                                'type'):
                                                if get_array_key.get("items").get('enum'):
                                                    if not array_choice_validation(input_array_valid,
                                                                                   get_array_key.get("items").get(
                                                                                       'enum')):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][input_len][array_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                                          input_len) + "]/" + array_key,
                                                                      "error": "Array incorrect value",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                                if get_array_key.get("items").get('pattern'):
                                                    if not re.match(str(get_array_key.get("items").get('pattern')),
                                                                    str(input_array_valid)):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][input_len][array_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                                          input_len) + "]/" + array_key,
                                                                      "error": "Array pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key]).line
                                                error_json = {"file_name": bundle_name,
                                                              "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key,
                                                              "error": "Array datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        elif get_array_key.get("items").get('$ref'):
                                            array_array_validation(get_array_key, rule, input_array_valid,
                                                                   definitions_key,
                                                                   input_len,
                                                                   array_key, bundle_name, resource_name, resource_id,
                                                                   line_no_input)
                                    if get_array_key.get('pattern'):
                                        if not re.match(str(get_array_key.get('pattern')),
                                                        str(input_listtype[input_len].get(array_key))):
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][input_len][array_key]).line
                                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                                              input_len) + "]/" + array_key,
                                                          "error": "Array pattern is not match",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)
                                else:
                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][input_len][array_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                      input_len) + "]/" + array_key,
                                                  "error": "Array datatype is not valid.",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                            if get_array_key.get('$ref'):
                                array_ref = get_router(get_array_key.get('$ref'), rule)
                                if array_ref.get("type"):
                                    if type(input_listtype[input_len].get(array_key)).__name__.lower().replace(
                                            'str', 'string').replace('list', 'array').replace('bool',
                                                                                              'boolean').replace(
                                        "int",
                                        "number").replace(
                                        "dict", "object").replace("float", "number") == array_ref.get("type"):
                                        if array_ref.get("pattern"):
                                            if not re.match(str(array_ref.get("pattern")),
                                                            str(input_listtype[input_len].get(array_key))):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key,
                                                              "error": "Array pattern is not match",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                    else:
                                        line_no = jsoncfg.node_location(
                                            line_no_input[definitions_key][input_len][array_key]).line
                                        error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                          input_len) + "]/" + array_key,
                                                      "error": "Array datatype is not valid.",
                                                      "error_line_no": line_no,
                                                      "resource_id": resource_id
                                                      }
                                        error_list.append(error_json)
                                elif get_array_key.get('$ref'):
                                    input_json = input_listtype[input_len].get(array_key)
                                    array_obj_validation(get_array_key, rule, definitions_key, input_len, array_key,
                                                         input_json,
                                                         bundle_name, resource_name, resource_id, line_no_input)

    def array_obj_validation(schema_path_get, rule, definitions_key, input_len, array_key, input_js, bundle_name,
                             resource_name, resource_id, line_no_input):
        if schema_path_get.get("$ref"):
            obj_property = get_router(schema_path_get.get("$ref"), rule)
            obj_schema_prop = obj_property.get("properties")
            obj_property_keys = list(obj_schema_prop.keys())
            if isinstance(input_js, dict):
                if obj_property.get("required"):
                    for definitions_required in obj_property.get("required"):
                        if input_js.get(definitions_required) is None:
                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                          "path": "root" + "/" + definitions_required,
                                          "error": "Array required datatype is not valid.",
                                          "error_line_no": "N/A",
                                          "resource_id": resource_id
                                          }
                            error_list.append(error_json)
                if isinstance(input_js, dict):
                    for array_obj_key in obj_property_keys:
                        if input_js.get(array_obj_key) is not None:
                            schema_type = obj_schema_prop.get(array_obj_key)
                            if schema_type.get("enum"):
                                if input_js.get(array_obj_key) not in schema_type.get("enum"):
                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][input_len][array_key][array_obj_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                      input_len) + "]/" + array_key + "/" + array_obj_key,
                                                  "error": "Array incorrect value.",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                            if schema_type.get("type"):
                                if type(input_js.get(array_obj_key)).__name__.lower().replace(
                                        'str', 'string').replace('list', 'array').replace('bool',
                                                                                          'boolean').replace(
                                    "int",
                                    "number").replace(
                                    "dict", "object").replace("float", "number") == schema_type.get("type"):
                                    if schema_path_get.get("items"):
                                        if schema_path_get.get("items").get('enum'):

                                            if not array_choice_validation(input_js.get(array_obj_key),
                                                                           schema_path_get.get("items").get('enum')):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][
                                                        array_obj_key]).line
                                                error_json = {"file_name": bundle_name,
                                                              "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/" + array_obj_key,
                                                              "error": "Array incorrect value.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        if schema_path_get.get("items").get('type'):
                                            if type(input_js.get(array_obj_key)).__name__.lower().replace(
                                                    'str', 'string').replace('list', 'array').replace('bool',
                                                                                                      'boolean').replace(
                                                "int",
                                                "number").replace(
                                                "dict", "object").replace("float", "number") == schema_path_get.get(
                                                "items").get('type'):
                                                if schema_path_get.get("items").get('pattern'):
                                                    if not re.match(str(schema_path_get.get("items").get('pattern')),
                                                                    str(input_js.get(definitions_key))):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][input_len][array_key][
                                                                array_obj_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                                          input_len) + "]/" + array_key + "/" + array_obj_key,
                                                                      "error": "Array pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][
                                                        array_obj_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/" + array_obj_key,
                                                              "error": "array datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        elif schema_path_get.get("items").get('$ref'):
                                            array_obj_array_validation(schema_type.get("items"), rule, definitions_key,
                                                                       input_js.get(array_obj_key), input_len,
                                                                       array_key,
                                                                       array_obj_key,
                                                                       bundle_name, resource_name, resource_id,
                                                                       line_no_input)

                                    if schema_type.get("pattern"):
                                        if not re.match(str(schema_type.get("pattern")),
                                                        str(input_js.get(array_obj_key))):
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][input_len][array_key][
                                                    array_obj_key]).line
                                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                                              input_len) + "]/" + array_key + "/" + array_obj_key,
                                                          "error": "array pattern is not match.",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)
                                else:
                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][input_len][array_key][array_obj_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                      input_len) + "]/" + array_key + "/" + array_obj_key,
                                                  "error": "array datatype is not valid.",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                            if schema_type.get("$ref"):
                                split_path = get_router(schema_type.get("$ref"), rule)
                                if split_path.get("type"):
                                    if type(input_js.get(array_obj_key)).__name__.lower().replace(
                                            'str', 'string').replace('list', 'array').replace('bool',
                                                                                              'boolean').replace(
                                        "int",
                                        "number").replace(
                                        "dict", "object").replace("float", "number") == split_path.get("type"):
                                        if split_path.get("pattern"):
                                            if not re.match(str(split_path.get("pattern")),
                                                            str(input_js.get(array_obj_key))):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][
                                                        array_obj_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/" + array_obj_key,
                                                              "error": "Array pattern is not match.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                    else:
                                        line_no = jsoncfg.node_location(
                                            line_no_input[definitions_key][input_len][array_key][array_obj_key]).line
                                        error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                          input_len) + "]/" + array_key + "/" + array_obj_key,
                                                      "error": "Array datatype is not valid.",
                                                      "error_line_no": line_no,
                                                      "resource_id": resource_id
                                                      }
                                        error_list.append(error_json)
                                else:
                                    if schema_type.get("$ref"):
                                        array_obj_obj_validation(schema_type.get("$ref"), rule, definitions_key,
                                                                 input_js.get(
                                                                     array_obj_key), input_len, array_key,
                                                                 array_obj_key,
                                                                 bundle_name,
                                                                 resource_name, resource_id, line_no_input)

            else:
                line_no = jsoncfg.node_location(
                    line_no_input[definitions_key][input_len][array_key]).line
                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                              "path": "root" + "/" + definitions_key + "/[" + str(
                                  input_len) + "]/" + array_key,
                              "error": "Array datatype is not valid.",
                              "error_line_no": line_no,
                              "resource_id": resource_id
                              }
                error_list.append(error_json)

    def array_obj_obj_validation(schema_type, rule, definitions_key, input_js, input_len, array_key, array_obj_key,
                                 bundle_name,
                                 resource_name, resource_id, line_no_input):
        if schema_type:
            get_array_object_object_data = get_router(schema_type, rule)
            arr_obj_obj_property = get_array_object_object_data.get("properties")
            arr_obj_obj_property_keys = list(arr_obj_obj_property.keys())
            if isinstance(input_js, dict):
                if get_array_object_object_data.get("required"):
                    for definitions_required in get_array_object_object_data.get("required"):
                        if input_js.get(definitions_required) is None:
                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                              input_len) + "]/" + array_key + "/" + array_obj_key + "/" + definitions_required,
                                          "error": "Array required field is not available.",
                                          "error_line_no": "N/A",
                                          "resource_id": resource_id
                                          }
                            error_list.append(error_json)
                if isinstance(input_js, dict):
                    for arr_obj_obj_property_key in arr_obj_obj_property_keys:
                        if input_js.get(arr_obj_obj_property_key) is not None:
                            arr_object_object_datatype = arr_obj_obj_property.get(arr_obj_obj_property_key)
                            if arr_object_object_datatype.get('enum'):
                                if str(input_js.get(
                                        arr_obj_obj_property_key)) is not arr_object_object_datatype.get('enum'):
                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                            arr_obj_obj_property_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                      input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key,
                                                  "error": "Array incorrect value",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)

                            if arr_object_object_datatype.get('type'):
                                if arr_object_object_datatype.get('type') == (
                                        type(input_js.get(arr_obj_obj_property_key)).__name__.lower().replace(
                                            'str',
                                            'string').replace(
                                            'list', 'array').replace('bool', 'boolean').replace("int",
                                                                                                "number").replace(
                                            "dict", "object").replace("float", "number")):


                                    if arr_object_object_datatype.get("items"):
                                        if arr_object_object_datatype.get("items").get('enum'):
                                            if not array_choice_validation(input_js.get(definitions_key),
                                                                           arr_object_object_datatype.get("items").get(
                                                                               'enum')):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                        arr_obj_obj_property_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key,
                                                              "error": "Array incorrect value",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)

                                        if arr_object_object_datatype.get("items").get('type'):
                                            if type(input_js.get(definitions_key)).__name__.lower().replace(
                                                    'str', 'string').replace('list', 'array').replace('bool',
                                                                                                      'boolean').replace(
                                                "int",
                                                "number").replace(
                                                "dict", "object").replace("float",
                                                                          "number") == arr_object_object_datatype.get(
                                                "items").get('type'):

                                                if arr_object_object_datatype.get("items").get('pattern'):
                                                    if not re.match(
                                                            str(arr_object_object_datatype.get("items").get('pattern')),
                                                            str(input_js.get(definitions_key))):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][input_len][array_key][
                                                                array_obj_key][
                                                                arr_obj_obj_property_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                                          input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key,
                                                                      "error": "Array pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                        arr_obj_obj_property_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key,
                                                              "error": "Array datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        elif arr_object_object_datatype.get("items").get('$ref'):
                                            array_obj_obj_array_validation(arr_object_object_datatype.get('items'),
                                                                           rule,
                                                                           input_js.get(arr_obj_obj_property_key),
                                                                           definitions_key, input_len,
                                                                           array_key, array_obj_key,
                                                                           arr_obj_obj_property_key,
                                                                           bundle_name, resource_name, resource_id,
                                                                           line_no_input)

                                    if arr_object_object_datatype.get('pattern'):
                                        if not re.match(str(arr_object_object_datatype.get('pattern')),
                                                        str(input_js.get(arr_obj_obj_property_key))):
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                    arr_obj_obj_property_key]).line
                                            error_json = {"file_name": bundle_name,
                                                          "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                                              input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key,
                                                          "error": "Array pattern is not match.",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)
                                else:
                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                            arr_obj_obj_property_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                      input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key,
                                                  "error": "Array datatype is not valid.",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)

                            if arr_object_object_datatype.get('$ref'):
                                if arr_obj_obj_property.get(arr_obj_obj_property_key):
                                    getobj_path = arr_object_object_datatype.get('$ref')
                                    if getobj_path:

                                        obj_path_split = getobj_path.split("/")
                                        path_get = rule.get(obj_path_split[1]).get(obj_path_split[2])
                                        # ref->path->type
                                        if path_get.get("type"):
                                            if path_get.get("type") == (
                                                    type(input_js.get(
                                                        arr_obj_obj_property_key)).__name__.lower().replace(
                                                        'str',
                                                        'string').replace(
                                                        'list', 'array').replace('bool', 'boolean').replace("int",
                                                                                                            "number").replace(
                                                        "dict", "object").replace("float", "number")):
                                                if path_get.get("pattern"):
                                                    if not re.compile(str(path_get.get("pattern"))).match(
                                                            str(input_js.get(arr_obj_obj_property_key))):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][input_len][array_key][
                                                                array_obj_key][
                                                                arr_obj_obj_property_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                                          input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key,
                                                                      "error": "Array pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                        arr_obj_obj_property_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key,
                                                              "error": "Array datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)

                                        elif arr_object_object_datatype.get('$ref'):
                                            # array obj_obj validation
                                            input_json = input_js.get(arr_obj_obj_property_key)
                                            array_obj_obj_obj_validation(getobj_path,
                                                                         rule, input_json,
                                                                         definitions_key, input_len,
                                                                         array_key, array_obj_key,
                                                                         arr_obj_obj_property_key,
                                                                         bundle_name,
                                                                         resource_name, resource_id, line_no_input)

            else:
                line_no = jsoncfg.node_location(
                    line_no_input[definitions_key][input_len][array_key][array_obj_key]).line
                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                              "path": "root" + "/" + definitions_key + "/[" + str(
                                  input_len) + "]/" + array_key + "/" + array_obj_key,
                              "error": "array datatype is not valid.",
                              "error_line_no": line_no,
                              "resource_id": resource_id
                              }
                error_list.append(error_json)

    def array_obj_obj_obj_validation(getobj_path, rule, input_json, definitions_key, input_len, array_key,
                                     array_obj_key,
                                     arr_obj_obj_property_key, bundle_name, resource_name, resource_id, line_no_input):
        if getobj_path:
            get_array_obj_obj_obj_data = get_router(getobj_path, rule)
            arr_obj_obj_obj_property = get_array_obj_obj_obj_data.get("properties")
            arr_obj_obj_obj_property_keys = list(arr_obj_obj_obj_property.keys())
            if isinstance(input_json, dict):
                if get_array_obj_obj_obj_data.get("required"):
                    for definitions_required in get_array_obj_obj_obj_data.get("required"):
                        if input_json.get(definitions_required) is None:
                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                              input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/" + definitions_required,
                                          "error": "Array required field is not available.",
                                          "error_line_no": "N/A",
                                          "resource_id": resource_id
                                          }
                            error_list.append(error_json)
                if isinstance(input_json, dict):
                    for arr_obj_obj_obj_property_key in arr_obj_obj_obj_property_keys:
                        if isinstance(input_json, dict):
                            if input_json.get(arr_obj_obj_obj_property_key) is not None:
                                arr_object_object_object_datatype = arr_obj_obj_obj_property.get(
                                    arr_obj_obj_obj_property_key)

                                if arr_object_object_object_datatype.get('enum'):
                                    if str(input_json.get(
                                            arr_obj_obj_obj_property_key)) is not arr_object_object_object_datatype.get(
                                        'enum'):
                                        line_no = jsoncfg.node_location(
                                            line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                arr_obj_obj_property_key][arr_obj_obj_obj_property_key]).line
                                        error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                          input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/" + arr_obj_obj_obj_property_key,
                                                      "error": "Array incorrect value",
                                                      "error_line_no": line_no,
                                                      "resource_id": resource_id
                                                      }
                                        error_list.append(error_json)

                                if arr_object_object_object_datatype.get('type'):
                                    if arr_object_object_object_datatype.get('type') == (type(input_json.get(
                                            arr_obj_obj_obj_property_key)).__name__.lower().replace(
                                        'str',
                                        'string').replace(
                                        'list', 'array').replace('bool', 'boolean').replace("int",
                                                                                            "number").replace(
                                        "dict", "object").replace("float", "number")):
                                        # array array object array object
                                        input_array_ref = input_json.get(arr_obj_obj_obj_property_key)
                                        if arr_object_object_object_datatype.get("items"):
                                            if arr_object_object_object_datatype.get("items").get('enum'):
                                                if not array_choice_validation(input_array_ref,
                                                                               arr_object_object_object_datatype.get(
                                                                                   "items").get(
                                                                                   'enum')):
                                                    line_no = jsoncfg.node_location(
                                                        line_no_input[definitions_key][input_len][array_key][
                                                            array_obj_key][
                                                            arr_obj_obj_property_key][
                                                            arr_obj_obj_obj_property_key]).line
                                                    error_json = {"file_name": bundle_name,
                                                                  "resource_name": resource_name,
                                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                                      input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/" + arr_obj_obj_obj_property_key,
                                                                  "error": "Array incorrect value",
                                                                  "error_line_no": line_no,
                                                                  "resource_id": resource_id
                                                                  }
                                                    error_list.append(error_json)
                                            if arr_object_object_object_datatype.get("items").get('type'):
                                                if type(input_array_ref).__name__.lower().replace(
                                                        'str', 'string').replace('list', 'array').replace('bool',
                                                                                                          'boolean').replace(
                                                    "int",
                                                    "number").replace(
                                                    "dict", "object").replace("float",
                                                                              "number") == arr_object_object_object_datatype.get(
                                                    "items").get('type'):

                                                    if arr_object_object_object_datatype.get("items").get('pattern'):
                                                        if not re.match(
                                                                str(arr_object_object_object_datatype.get("items").get(
                                                                    'pattern')),
                                                                str(input_array_ref)):
                                                            line_no = jsoncfg.node_location(
                                                                line_no_input[definitions_key][input_len][array_key][
                                                                    array_obj_key][
                                                                    arr_obj_obj_property_key][
                                                                    arr_obj_obj_obj_property_key]).line
                                                            error_json = {"file_name": bundle_name,
                                                                          "resource_name": resource_name,
                                                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                                                              input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/" + arr_obj_obj_obj_property_key,
                                                                          "error": "Array pattern is not match.",
                                                                          "error_line_no": line_no,
                                                                          "resource_id": resource_id
                                                                          }
                                                            error_list.append(error_json)
                                                else:
                                                    line_no = jsoncfg.node_location(
                                                        line_no_input[definitions_key][input_len][array_key][
                                                            array_obj_key][
                                                            arr_obj_obj_property_key][
                                                            arr_obj_obj_obj_property_key]).line
                                                    error_json = {"file_name": bundle_name,
                                                                  "resource_name": resource_name,
                                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                                      input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/" + arr_obj_obj_obj_property_key,
                                                                  "error": "Array datatype is not valid.",
                                                                  "error_line_no": line_no,
                                                                  "resource_id": resource_id
                                                                  }
                                                    error_list.append(error_json)
                                            elif arr_object_object_object_datatype.get("items").get('$ref'):
                                                pass

                                        if arr_object_object_object_datatype.get('pattern'):
                                            if not re.match(str(arr_object_object_object_datatype.get('pattern')),
                                                            str(input_json.get(
                                                                arr_obj_obj_obj_property_key))):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                        arr_obj_obj_property_key][arr_obj_obj_obj_property_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/" + arr_obj_obj_obj_property_key,
                                                              "error": "Array pattern is not match.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                    else:
                                        line_no = jsoncfg.node_location(
                                            line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                arr_obj_obj_property_key][arr_obj_obj_obj_property_key]).line
                                        error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                          input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/" + arr_obj_obj_obj_property_key,
                                                      "error": "Array datatype is not valid.",
                                                      "error_line_no": line_no,
                                                      "resource_id": resource_id
                                                      }
                                        error_list.append(error_json)
                                if arr_object_object_object_datatype.get('$ref'):
                                    if arr_obj_obj_obj_property.get(arr_obj_obj_obj_property_key):
                                        getobj_path = arr_object_object_object_datatype.get('$ref')
                                        if getobj_path:

                                            obj_path_split = getobj_path.split("/")
                                            path_get = rule.get(obj_path_split[1]).get(obj_path_split[2])
                                            # ref->path->type
                                            if path_get.get("type"):
                                                if path_get.get("type") == (type(input_json.get(
                                                        arr_obj_obj_obj_property_key)).__name__.lower().replace(
                                                    'str',
                                                    'string').replace(
                                                    'list', 'array').replace('bool', 'boolean').replace("int",
                                                                                                        "number").replace(
                                                    "dict", "object").replace("float", "number")):
                                                    if path_get.get("pattern"):
                                                        if not re.compile(str(path_get.get("pattern"))).match(
                                                                str(input_json.get(
                                                                    arr_obj_obj_obj_property_key))):
                                                            line_no = jsoncfg.node_location(
                                                                line_no_input[definitions_key][input_len][array_key][
                                                                    array_obj_key][
                                                                    arr_obj_obj_property_key][
                                                                    arr_obj_obj_obj_property_key]).line
                                                            error_json = {"file_name": bundle_name,
                                                                          "resource_name": resource_name,
                                                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                                                              input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/" + arr_obj_obj_obj_property_key,
                                                                          "error": "Array pattern is not match.",
                                                                          "error_line_no": line_no,
                                                                          "resource_id": resource_id
                                                                          }
                                                            error_list.append(error_json)
                                                else:
                                                    line_no = jsoncfg.node_location(
                                                        line_no_input[definitions_key][input_len][array_key][
                                                            array_obj_key][
                                                            arr_obj_obj_property_key][
                                                            arr_obj_obj_obj_property_key]).line
                                                    error_json = {"file_name": bundle_name,
                                                                  "resource_name": resource_name,
                                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                                      input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/" + arr_obj_obj_obj_property_key,
                                                                  "error": "Array datatype is not valid.",
                                                                  "error_line_no": line_no,
                                                                  "resource_id": resource_id
                                                                  }
                                                    error_list.append(error_json)
                                            elif arr_object_object_object_datatype.get('$ref'):

                                                # array array obj_obj_objvalidation
                                                input_json = input_json.get(arr_obj_obj_obj_property_key)
                                                array_obj_obj_obj_obj_validation(
                                                    arr_object_object_object_datatype.get('$ref'),
                                                    rule, input_json, definitions_key, input_len,
                                                    array_key,
                                                    array_obj_key, arr_obj_obj_property_key,
                                                    arr_obj_obj_obj_property_key,
                                                    bundle_name, resource_name, resource_id,
                                                    line_no_input)

            else:
                line_no = jsoncfg.node_location(
                    line_no_input[definitions_key][input_len][array_key][array_obj_key][
                        arr_obj_obj_property_key]).line
                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                              "path": "root" + "/" + definitions_key + "/[" + str(
                                  input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key,
                              "error": "Array datatype is not valid.",
                              "error_line_no": line_no,
                              "resource_id": resource_id
                              }
                error_list.append(error_json)

    def array_obj_obj_obj_obj_validation(get_object_key, rule, input_json, definitions_key, input_len, array_key,
                                         array_obj_key, arr_obj_obj_property_key, arr_obj_obj_obj_property_key,
                                         bundle_name, resource_name, resource_id, line_no_input):
        if get_object_key:
            get_array_obj_obj_obj_obj_data = get_router(get_object_key, rule)
            arr_obj_obj_obj_obj_property = get_array_obj_obj_obj_obj_data.get("properties")
            arr_obj_obj_obj_obj_property_keys = list(arr_obj_obj_obj_obj_property.keys())
            if isinstance(input_json, dict):
                if get_array_obj_obj_obj_obj_data.get("required"):
                    for definitions_required in get_array_obj_obj_obj_obj_data.get("required"):
                        if input_json.get(definitions_required) is None:
                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                              input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/" + arr_obj_obj_obj_property_key + "/" + definitions_required,
                                          "error": "Array required field is not available.",
                                          "error_line_no": "N/A",
                                          "resource_id": resource_id
                                          }
                            error_list.append(error_json)
                if isinstance(input_json, dict):
                    for arr_obj_obj_obj_obj_property_key in arr_obj_obj_obj_obj_property_keys:
                        if input_json.get(arr_obj_obj_obj_obj_property_key) is not None:
                            arr_obj_obj_obj_obj_datatype = arr_obj_obj_obj_obj_property.get(
                                arr_obj_obj_obj_obj_property_key)
                            input_value = input_json.get(arr_obj_obj_obj_obj_property_key)
                            if arr_obj_obj_obj_obj_datatype.get('enum'):
                                if str(input_json.get(
                                        arr_obj_obj_obj_obj_property_key)) is not arr_obj_obj_obj_obj_datatype.get(
                                    'enum'):
                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                            arr_obj_obj_property_key][arr_obj_obj_obj_property_key][
                                            arr_obj_obj_obj_obj_property_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                      input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key
                                                          + "/" + arr_obj_obj_obj_property_key + "/" + arr_obj_obj_obj_obj_property_key,
                                                  "error": "Array incorrect value",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                            if arr_obj_obj_obj_obj_datatype.get('type'):
                                if arr_obj_obj_obj_obj_datatype.get('type') == (type(input_json.get(
                                        arr_obj_obj_obj_obj_property_key)).__name__.lower().replace(
                                    'str',
                                    'string').replace(
                                    'list', 'array').replace('bool', 'boolean').replace("int",
                                                                                        "number").replace(
                                    "dict", "object").replace("float", "number")):

                                    if arr_obj_obj_obj_obj_datatype.get("items"):
                                        if arr_obj_obj_obj_obj_datatype.get("items").get('enum'):
                                            if not array_choice_validation(input_value,
                                                                           arr_obj_obj_obj_obj_datatype.get(
                                                                               "items").get(
                                                                               'enum')):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                        arr_obj_obj_property_key][arr_obj_obj_obj_property_key][
                                                        arr_obj_obj_obj_obj_property_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key
                                                                      + "/" + arr_obj_obj_obj_property_key + "/" + arr_obj_obj_obj_obj_property_key,
                                                              "error": "Array incorrect value",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        if arr_obj_obj_obj_obj_datatype.get("items").get('type'):
                                            if type(input_value).__name__.lower().replace(
                                                    'str', 'string').replace('list', 'array').replace('bool',
                                                                                                      'boolean').replace(
                                                "int",
                                                "number").replace(
                                                "dict", "object").replace("float",
                                                                          "number") == arr_obj_obj_obj_obj_datatype.get(
                                                "items").get('type'):

                                                if arr_obj_obj_obj_obj_datatype.get("items").get('pattern'):
                                                    if not re.match(
                                                            str(arr_obj_obj_obj_obj_datatype.get("items").get(
                                                                'pattern')),
                                                            str(input_value)):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][input_len][array_key][
                                                                array_obj_key][
                                                                arr_obj_obj_property_key][arr_obj_obj_obj_property_key][
                                                                arr_obj_obj_obj_obj_property_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                                          input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key
                                                                              + "/" + arr_obj_obj_obj_property_key + "/" + arr_obj_obj_obj_obj_property_key,
                                                                      "error": "Array pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                        arr_obj_obj_property_key][arr_obj_obj_obj_property_key][
                                                        arr_obj_obj_obj_obj_property_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key
                                                                      + "/" + arr_obj_obj_obj_property_key + "/" + arr_obj_obj_obj_obj_property_key,
                                                              "error": "Array datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        elif arr_obj_obj_obj_obj_datatype.get("items").get('$ref'):
                                            pass

                                    if arr_obj_obj_obj_obj_datatype.get('pattern'):
                                        if not re.match(str(arr_obj_obj_obj_obj_datatype.get('pattern')),
                                                        str(input_json.get(
                                                            arr_obj_obj_obj_obj_property_key))):
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                    arr_obj_obj_property_key][arr_obj_obj_obj_property_key][
                                                    arr_obj_obj_obj_obj_property_key]).line
                                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                                              input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key
                                                                  + "/" + arr_obj_obj_obj_property_key + "/" + arr_obj_obj_obj_obj_property_key,
                                                          "error": "Array Pattern is not match.",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)
                                else:
                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                            arr_obj_obj_property_key][arr_obj_obj_obj_property_key][
                                            arr_obj_obj_obj_obj_property_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                      input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key
                                                          + "/" + arr_obj_obj_obj_property_key + "/" + arr_obj_obj_obj_obj_property_key,
                                                  "error": "Array datatype is not valid.",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                            if arr_obj_obj_obj_obj_datatype.get('$ref'):
                                if arr_obj_obj_obj_obj_property.get(arr_obj_obj_obj_obj_property_key):
                                    getobj_path = arr_obj_obj_obj_obj_datatype.get('$ref')
                                    if getobj_path:

                                        obj_path_split = getobj_path.split("/")
                                        path_get = rule.get(obj_path_split[1]).get(obj_path_split[2])
                                        # ref->path->type
                                        if path_get.get("type"):
                                            if path_get.get("type") == (type(input_json.get(
                                                    arr_obj_obj_obj_obj_property_key)).__name__.lower().replace(
                                                'str',
                                                'string').replace(
                                                'list', 'array').replace('bool', 'boolean').replace("int",
                                                                                                    "number").replace(
                                                "dict", "object").replace("float", "number")):
                                                if path_get.get("pattern"):
                                                    if not re.compile(str(path_get.get("pattern"))).match(
                                                            str(input_json.get(
                                                                arr_obj_obj_obj_obj_property_key))):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][input_len][array_key][
                                                                array_obj_key][
                                                                arr_obj_obj_property_key][arr_obj_obj_obj_property_key][
                                                                arr_obj_obj_obj_obj_property_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                                          input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key
                                                                              + "/" + arr_obj_obj_obj_property_key + "/" + arr_obj_obj_obj_obj_property_key,
                                                                      "error": "Array pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                        arr_obj_obj_property_key][arr_obj_obj_obj_property_key][
                                                        arr_obj_obj_obj_obj_property_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key
                                                                      + "/" + arr_obj_obj_obj_property_key + "/" + arr_obj_obj_obj_obj_property_key,
                                                              "error": "Array datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        elif arr_obj_obj_obj_obj_datatype.get('$ref'):
                                            input_json = input_json.get(arr_obj_obj_obj_obj_property_key)

            else:
                line_no = jsoncfg.node_location(
                    line_no_input[definitions_key][input_len][array_key][array_obj_key][
                        arr_obj_obj_property_key][arr_obj_obj_obj_property_key]).line
                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                              "path": "root" + "/" + definitions_key + "/[" + str(
                                  input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/" + arr_obj_obj_obj_property_key,
                              "error": "Array datatype is not valid.",
                              "error_line_no": line_no,
                              "resource_id": resource_id
                              }
                error_list.append(error_json)

    def array_obj_obj_array_validation(get_array_key, rule, input_js, definitions_key, input_len,
                                       array_key, array_obj_key, arr_obj_obj_property_key, bundle_name, resource_name,
                                       resource_id, line_no_input):
        if get_array_key:
            get_array_object_object_array_data = get_router(get_array_key.get('$ref'), rule)
            if get_array_object_object_array_data.get('properties'):
                array_object_object_array_keys = list(get_array_object_object_array_data.get('properties').keys())
                array_array_object_array_schema = get_array_object_object_array_data.get('properties')
                for array_obj_obj_array_len in range(len(input_js)):
                    if isinstance(input_js[array_obj_obj_array_len],dict):
                        if get_array_object_object_array_data.get("required"):
                            for definitions_required in get_array_object_object_array_data.get("required"):
                                if input_js[array_obj_obj_array_len].get(definitions_required) is None:
                                    error_json = {"file_name": bundle_name,
                                                  "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                      input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/[" + str(
                                                      array_obj_obj_array_len) + "]/" + definitions_required,
                                                  "error": "Array required field is not available.",
                                                  "error_line_no": "N/A",
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)

                        for array_object_object_array_key in array_object_object_array_keys:
                            array_object_object_array_inputs = input_js[array_obj_obj_array_len].get(
                                array_object_object_array_key)
                            if array_object_object_array_inputs is not None:
                                schema_values_object_object_arrays = array_array_object_array_schema.get(
                                    array_object_object_array_key)

                                if schema_values_object_object_arrays.get('enum'):
                                    if array_object_object_array_inputs not in schema_values_object_object_arrays.get(
                                            'enum'):
                                        line_no = jsoncfg.node_location(
                                            line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                arr_obj_obj_property_key][array_obj_obj_array_len][
                                                array_object_object_array_key]).line
                                        error_json = {"file_name": bundle_name,
                                                      "resource_name": resource_name,
                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                          input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/[" + str(
                                                          array_obj_obj_array_len) + "]/" + array_object_object_array_key,
                                                      "error": "Array incorrect value",
                                                      "error_line_no": line_no,
                                                      "resource_id": resource_id
                                                      }
                                        error_list.append(error_json)
                                    # type check
                                if schema_values_object_object_arrays.get('type'):
                                    if type(array_object_object_array_inputs).__name__.lower().replace(
                                            'str', 'string').replace('list', 'array').replace('bool',
                                                                                              'boolean').replace(
                                        "int",
                                        "number").replace(
                                        "dict", "object").replace("float", "number") == get_array_key.get('type'):

                                        if schema_values_object_object_arrays.get("items"):
                                            if schema_values_object_object_arrays.get("items").get('enum'):
                                                if not array_choice_validation(array_object_object_array_inputs,
                                                                               schema_values_object_object_arrays.get(
                                                                                   "items").get(
                                                                                   'enum')):
                                                    line_no = jsoncfg.node_location(
                                                        line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                            arr_obj_obj_property_key][array_obj_obj_array_len][
                                                            array_object_object_array_key]).line
                                                    error_json = {"file_name": bundle_name,
                                                                  "resource_name": resource_name,
                                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                                      input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/[" + str(
                                                                      array_obj_obj_array_len) + "]/" + array_object_object_array_key,
                                                                  "error": "Array incorrect value",
                                                                  "error_line_no": line_no,
                                                                  "resource_id": resource_id
                                                                  }
                                                    error_list.append(error_json)
                                            if schema_values_object_object_arrays.get("items").get('type'):
                                                if type(array_object_object_array_inputs).__name__.lower().replace(
                                                        'str', 'string').replace('list', 'array').replace('bool',
                                                                                                          'boolean').replace(
                                                    "int",
                                                    "number").replace(
                                                    "dict", "object").replace("float",
                                                                              "number") == schema_values_object_object_arrays.get(
                                                    "items").get(
                                                    'type'):

                                                    if schema_values_object_object_arrays.get("items").get('pattern'):
                                                        if not re.match(
                                                                str(schema_values_object_object_arrays.get("items").get(
                                                                    'pattern')),
                                                                str(array_object_object_array_inputs)):
                                                            line_no = jsoncfg.node_location(
                                                                line_no_input[definitions_key][input_len][array_key][
                                                                    array_obj_key][
                                                                    arr_obj_obj_property_key][array_obj_obj_array_len][
                                                                    array_object_object_array_key]).line
                                                            error_json = {"file_name": bundle_name,
                                                                          "resource_name": resource_name,
                                                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                                                              input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/[" + str(
                                                                              array_obj_obj_array_len) + "]/" + array_object_object_array_key,
                                                                          "error": "Array pattern is not match.",
                                                                          "error_line_no": line_no,
                                                                          "resource_id": resource_id
                                                                          }
                                                            error_list.append(error_json)
                                                else:
                                                    line_no = jsoncfg.node_location(
                                                        line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                            arr_obj_obj_property_key][array_obj_obj_array_len][
                                                            array_object_object_array_key]).line
                                                    error_json = {"file_name": bundle_name,
                                                                  "resource_name": resource_name,
                                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                                      input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/[" + str(
                                                                      array_obj_obj_array_len) + "]/" + array_object_object_array_key,
                                                                  "error": "Array datatype is not valid.",
                                                                  "error_line_no": line_no,
                                                                  "resource_id": resource_id
                                                                  }
                                                    error_list.append(error_json)
                                            elif schema_values_object_object_arrays.get("items").get('$ref'):
                                                pass
                                        if schema_values_object_object_arrays.get('pattern'):
                                            if not re.match(str(schema_values_object_object_arrays.get('pattern')),
                                                            str(array_object_object_array_inputs[
                                                                array_obj_obj_array_len].get(
                                                                array_object_object_array_key))):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                        arr_obj_obj_property_key][array_obj_obj_array_len][
                                                        array_object_object_array_key]).line
                                                error_json = {"file_name": bundle_name,
                                                              "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/[" + str(
                                                                  array_obj_obj_array_len) + "]/" + array_object_object_array_key,
                                                              "error": "Array pattern is not match.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                    else:
                                        line_no = jsoncfg.node_location(
                                            line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                arr_obj_obj_property_key][array_obj_obj_array_len][
                                                array_object_object_array_key]).line
                                        error_json = {"file_name": bundle_name,
                                                      "resource_name": resource_name,
                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                          input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/[" + str(
                                                          array_obj_obj_array_len) + "]/" + array_object_object_array_key,
                                                      "error": "Array datatype is not valid.",
                                                      "error_line_no": line_no,
                                                      "resource_id": resource_id
                                                      }
                                        error_list.append(error_json)
                                if schema_values_object_object_arrays.get('$ref'):
                                    # array of data type
                                    array_ref = get_router(schema_values_object_object_arrays.get('$ref'), rule)
                                    if array_ref.get("type"):
                                        if type(array_object_object_array_inputs).__name__.lower().replace(
                                                'str', 'string').replace('list', 'array').replace('bool',
                                                                                                  'boolean').replace(
                                            "int",
                                            "number").replace(
                                            "dict", "object").replace("float", "number") == array_ref.get("type"):
                                            if array_ref.get("pattern"):
                                                if not re.match(str(array_ref.get("pattern")),
                                                                str(array_object_object_array_inputs)):
                                                    line_no = jsoncfg.node_location(
                                                        line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                            arr_obj_obj_property_key][array_obj_obj_array_len][
                                                            array_object_object_array_key]).line
                                                    error_json = {"file_name": bundle_name,
                                                                  "resource_name": resource_name,
                                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                                      input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/[" + str(
                                                                      array_obj_obj_array_len) + "]/" + array_object_object_array_key,
                                                                  "error": "Array pattern is not match.",
                                                                  "error_line_no": line_no,
                                                                  "resource_id": resource_id
                                                                  }
                                                    error_list.append(error_json)
                                        else:
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                    arr_obj_obj_property_key][array_obj_obj_array_len][
                                                    array_object_object_array_key]).line
                                            error_json = {"file_name": bundle_name,
                                                          "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                                              input_len) + "]/" + array_key + "/" + array_obj_key + "/" + arr_obj_obj_property_key + "/[" + str(
                                                              array_obj_obj_array_len) + "]/" + array_object_object_array_key,
                                                          "error": "Array datatype is not valid.",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)


                                    elif schema_values_object_object_arrays.get('$ref'):
                                        pass

    def array_array_validation(get_array_key, rule, input_array_valids, definitions_key, input_len, array_key,
                               bundle_name,
                               resource_name, resource_id, line_no_input):
        if get_array_key.get("items"):
            get_array_array_data = get_router(get_array_key.get("items").get('$ref'), rule)
            if get_array_array_data.get('properties'):
                array_array_keys = list(get_array_array_data.get('properties').keys())
                array_array_schema = get_array_array_data.get('properties')
                for array_array_len in range(len(input_array_valids)):
                    if isinstance(input_array_valids[array_array_len],dict):
                        if get_array_array_data.get('required'):
                            for definitions_required in get_array_array_data.get('required'):
                                if input_array_valids[array_array_len].get(definitions_required) is None:
                                    error_json = {"file_name": bundle_name,
                                                  "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                      input_len) + "]/" + array_key + "/[" + str(
                                                      array_array_len) + "]/" + definitions_required,
                                                  "error": "Array required field is not available.",
                                                  "error_line_no": "N/A",
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                        for array_array_key in array_array_keys:
                            if isinstance(input_array_valids[array_array_len], dict):
                                array_array_inputs = input_array_valids[array_array_len].get(array_array_key)
                                if array_array_inputs is not None:
                                    schema_values = array_array_schema.get(array_array_key)
                                    if schema_values.get('enum'):
                                        if array_array_inputs not in schema_values.get('enum'):
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][input_len][array_key][array_array_len][
                                                    array_array_key]).line
                                            error_json = {"file_name": bundle_name,
                                                          "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                                              input_len) + "]/" + array_key + "/[" + str(
                                                              array_array_len) + "]/" + array_array_key,
                                                          "error": "Array incorrect value",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)
                                    # type check
                                    if schema_values.get('type'):
                                        if type(array_array_inputs).__name__.lower().replace(
                                                'str', 'string').replace('list', 'array').replace('bool',
                                                                                                  'boolean').replace(
                                            "int",
                                            "number").replace(
                                            "dict", "object").replace("float", "number") == schema_values.get('type'):
                                            if schema_values.get("items"):
                                                if schema_values.get("items").get('type'):
                                                    if type(array_array_inputs).__name__.lower().replace(
                                                            'str', 'string').replace('list', 'array').replace('bool',
                                                                                                              'boolean').replace(
                                                        "int",
                                                        "number").replace(
                                                        "dict", "object").replace("float", "number") == schema_values.get(
                                                        "items").get('type'):
                                                        if schema_values.get("items").get('enum'):
                                                            if not array_choice_validation(array_array_inputs,
                                                                                           schema_values.get("items").get(
                                                                                               'enum')):
                                                                line_no = jsoncfg.node_location(
                                                                    line_no_input[definitions_key][input_len][array_key][
                                                                        array_array_len][array_array_key]).line
                                                                error_json = {"file_name": bundle_name,
                                                                              "resource_name": resource_name,
                                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                                  input_len) + "]/" + array_key + "/[" + str(
                                                                                  array_array_len) + "]/" + array_array_key,
                                                                              "error": "Array incorrect value",
                                                                              "error_line_no": line_no,
                                                                              "resource_id": resource_id
                                                                              }
                                                                error_list.append(error_json)
                                                        if schema_values.get("items").get('pattern'):
                                                            if not re.match(str(schema_values.get("items").get('pattern')),
                                                                            str(array_array_inputs)):
                                                                line_no = jsoncfg.node_location(
                                                                    line_no_input[definitions_key][input_len][array_key][
                                                                        array_array_len][array_array_key]).line
                                                                error_json = {"file_name": bundle_name,
                                                                              "resource_name": resource_name,
                                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                                  input_len) + "]/" + array_key + "/[" + str(
                                                                                  array_array_len) + "]/" + array_array_key,
                                                                              "error": "Array pattern is not match.",
                                                                              "error_line_no": line_no,
                                                                              "resource_id": resource_id
                                                                              }
                                                                error_list.append(error_json)
                                                    else:
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][input_len][array_key][
                                                                array_array_len][
                                                                array_array_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                                          input_len) + "]/" + array_key + "/[" + str(
                                                                          array_array_len) + "]/" + array_array_key,
                                                                      "error": "Array datatype is not valid.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                                elif schema_values.get("items").get('$ref'):
                                                    array_array_array_validation(schema_values, rule, array_array_inputs,
                                                                                 definitions_key, input_len,
                                                                                 array_key, array_array_len,
                                                                                 array_array_key,
                                                                                 bundle_name, resource_name, resource_id,
                                                                                 line_no_input)
                                            if schema_values.get('pattern'):
                                                if not re.match(str(schema_values.get('pattern')),
                                                                str(array_array_inputs)):
                                                    line_no = jsoncfg.node_location(
                                                        line_no_input[definitions_key][input_len][array_key][
                                                            array_array_len][
                                                            array_array_key]).line
                                                    error_json = {"file_name": bundle_name,
                                                                  "resource_name": resource_name,
                                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                                      input_len) + "]/" + array_key + "/[" + str(
                                                                      array_array_len) + "]/" + array_array_key,
                                                                  "error": "Array pattern is not match.",
                                                                  "error_line_no": line_no,
                                                                  "resource_id": resource_id
                                                                  }
                                                    error_list.append(error_json)


                                        else:
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][input_len][array_key][array_array_len][
                                                    array_array_key]).line
                                            error_json = {"file_name": bundle_name,
                                                          "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                                              input_len) + "]/" + array_key + "/[" + str(
                                                              array_array_len) + "]/" + array_array_key,
                                                          "error": "Array datatype is not valid.",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)

                                    if schema_values.get('$ref'):
                                        # array of data type
                                        array_ref = get_router(schema_values.get('$ref'), rule)
                                        if array_ref.get("type"):
                                            if type(array_array_inputs).__name__.lower().replace(
                                                    'str', 'string').replace('list', 'array').replace('bool',
                                                                                                      'boolean').replace(
                                                "int",
                                                "number").replace(
                                                "dict", "object").replace("float", "number") == array_ref.get("type"):
                                                if array_ref.get("pattern"):
                                                    if not re.match(str(array_ref.get("pattern")),
                                                                    str(array_array_inputs)):
                                                        # error pattern
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][input_len][array_key][
                                                                array_array_len][
                                                                array_array_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                                          input_len) + "]/" + array_key + "/[" + str(
                                                                          array_array_len) + "]/" + array_array_key,
                                                                      "error": "Array pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][array_array_len][
                                                        array_array_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/[" + str(
                                                                  array_array_len) + "]/" + array_array_key,
                                                              "error": "Array datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)

                                        elif schema_values.get('$ref'):
                                            array_array_object_validation(schema_values.get('$ref'), rule,
                                                                          array_array_inputs,
                                                                          definitions_key, input_len,
                                                                          array_key, array_array_len, array_array_key,
                                                                          bundle_name,
                                                                          resource_name, resource_id, line_no_input)

    def array_array_object_validation(get_object_key, rule, input_json, definitions_key, input_len,
                                      array_key, array_array_len, array_array_key, bundle_name, resource_name,
                                      resource_id, line_no_input):
        if get_object_key:
            get_array_array_object_data = get_router(get_object_key, rule)
            arr_arry_obj_property = get_array_array_object_data.get("properties")
            arr_arry_obj_property_keys = list(arr_arry_obj_property.keys())
            if isinstance(input_json, dict):

                if get_array_array_object_data.get("required"):
                    for definitions_required in get_array_array_object_data.get("required"):
                        if input_json.get(definitions_required) is None:
                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                              input_len) + "]/" + array_key + "/[" + str(
                                              array_array_len) + "]/" + array_array_key + "/" + definitions_required,
                                          "error": "Array required field is not available.",
                                          "error_line_no": "N/A",
                                          "resource_id": resource_id
                                          }
                            error_list.append(error_json)
                if isinstance(input_json, dict):
                    for arr_arr_obj_property_key in arr_arry_obj_property_keys:
                        if input_json.get(arr_arr_obj_property_key) is not None:
                            arr_arr_object_datatype = arr_arry_obj_property.get(arr_arr_obj_property_key)
                            if arr_arr_object_datatype.get('enum'):
                                if str(input_json.get(arr_arr_obj_property_key)) is not arr_arr_object_datatype.get(
                                        'enum'):
                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][input_len][array_key][array_array_len][
                                            array_array_key][arr_arr_obj_property_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                      input_len) + "]/" + array_key + "/[" + str(
                                                      array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key,
                                                  "error": "Array incorrect value",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                            if arr_arr_object_datatype.get('type'):
                                if arr_arr_object_datatype.get('type') == (type(input_json.get(
                                        arr_arr_obj_property_key)).__name__.lower().replace(
                                    'str',
                                    'string').replace(
                                    'list', 'array').replace('bool', 'boolean').replace("int",
                                                                                        "number").replace(
                                    "dict", "object").replace("float", "number")):

                                    if arr_arr_object_datatype.get("items"):
                                        if arr_arr_object_datatype.get("items").get('enum'):
                                            if not array_choice_validation(input_json.get(arr_arr_obj_property_key),
                                                                           arr_arr_object_datatype.get("items").get(
                                                                               'enum')):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][
                                                        array_array_len][
                                                        array_array_key][arr_arr_obj_property_key]).line
                                                error_json = {"file_name": bundle_name,
                                                              "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/[" + str(
                                                                  array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key,
                                                              "error": "Array incorrect value",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        if arr_arr_object_datatype.get("items").get('type'):
                                            if type(input_json.get(arr_arr_obj_property_key)).__name__.lower().replace(
                                                    'str', 'string').replace('list', 'array').replace('bool',
                                                                                                      'boolean').replace(
                                                "int",
                                                "number").replace(
                                                "dict", "object").replace("float",
                                                                          "number") == arr_arr_object_datatype.get(
                                                "items").get('type'):

                                                if arr_arr_object_datatype.get("items").get('pattern'):
                                                    if not re.match(
                                                            str(arr_arr_object_datatype.get("items").get('pattern')),
                                                            str(input_json.get(arr_arr_obj_property_key))):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][input_len][array_key][
                                                                array_array_len][
                                                                array_array_key][arr_arr_obj_property_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                                          input_len) + "]/" + array_key + "/[" + str(
                                                                          array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key,
                                                                      "error": "Array pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][
                                                        array_array_len][
                                                        array_array_key][arr_arr_obj_property_key]).line
                                                error_json = {"file_name": bundle_name,
                                                              "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/[" + str(
                                                                  array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key,
                                                              "error": "Array datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        elif arr_arr_object_datatype.get("items").get('$ref'):
                                            array_array_object_array_validation(arr_arr_object_datatype.get('items'),
                                                                                rule,
                                                                                input_json.get(
                                                                                    arr_arr_obj_property_key),
                                                                                definitions_key, input_len,
                                                                                array_key, array_array_len,
                                                                                array_array_key,
                                                                                arr_arr_obj_property_key, bundle_name,
                                                                                resource_name, resource_id,
                                                                                line_no_input)

                                    if arr_arr_object_datatype.get('pattern'):
                                        if not re.match(str(arr_arr_object_datatype.get('pattern')),
                                                        str(input_json.get(
                                                            arr_arr_obj_property_key))):
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][input_len][array_key][array_array_len][
                                                    array_array_key][arr_arr_obj_property_key]).line
                                            error_json = {"file_name": bundle_name,
                                                          "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                                              input_len) + "]/" + array_key + "/[" + str(
                                                              array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key,
                                                          "error": "Array pattern is not match.",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)
                                else:
                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][input_len][array_key][array_array_len][
                                            array_array_key][arr_arr_obj_property_key]).line
                                    error_json = {"file_name": bundle_name,
                                                  "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                      input_len) + "]/" + array_key + "/[" + str(
                                                      array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key,
                                                  "error": "Array datatype is not valid.",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                            if arr_arr_object_datatype.get('$ref'):
                                if arr_arry_obj_property.get(arr_arr_obj_property_key):
                                    getobj_path = arr_arr_object_datatype.get('$ref')
                                    if getobj_path:

                                        obj_path_split = getobj_path.split("/")
                                        path_get = rule.get(obj_path_split[1]).get(obj_path_split[2])
                                        # ref->path->type
                                        if path_get.get("type"):
                                            if path_get.get("type") == (type(input_json.get(
                                                    arr_arr_obj_property_key)).__name__.lower().replace(
                                                'str',
                                                'string').replace(
                                                'list', 'array').replace('bool', 'boolean').replace("int",
                                                                                                    "number").replace(
                                                "dict", "object").replace("float", "number")):
                                                if path_get.get("pattern"):
                                                    if not re.compile(str(path_get.get("pattern"))).match(
                                                            str(input_json.get(
                                                                arr_arr_obj_property_key))):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][input_len][array_key][
                                                                array_array_len][
                                                                array_array_key][arr_arr_obj_property_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                                          input_len) + "]/" + array_key + "/[" + str(
                                                                          array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key,
                                                                      "error": "Array pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][
                                                        array_array_len][
                                                        array_array_key][arr_arr_obj_property_key]).line
                                                error_json = {"file_name": bundle_name,
                                                              "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/[" + str(
                                                                  array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key,
                                                              "error": "Array datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        elif arr_arr_object_datatype.get('$ref'):
                                            # array array obj_obj_validation
                                            input_json = input_json.get(arr_arr_obj_property_key)
                                            array_array_obj_obj_validation(arr_arr_object_datatype.get('$ref'), rule,
                                                                           input_json, definitions_key, input_len,
                                                                           array_key, array_array_len, array_array_key,
                                                                           arr_arr_obj_property_key, bundle_name,
                                                                           resource_name, resource_id, line_no_input)
            else:
                line_no = jsoncfg.node_location(
                    line_no_input[definitions_key][input_len][array_key][array_array_len][
                        array_array_key]).line
                error_json = {"file_name": bundle_name,
                              "resource_name": resource_name,
                              "path": "root" + "/" + definitions_key + "/[" + str(
                                  input_len) + "]/" + array_key + "/[" + str(
                                  array_array_len) + "]/" + array_array_key,
                              "error": "Array datatype is not valid.",
                              "error_line_no": line_no,
                              "resource_id": resource_id
                              }
                error_list.append(error_json)

    def array_obj_array_validation(schema_type, rule, definitions_key, input_js, input_len, array_key, array_obj_key,
                                   bundle_name,
                                   resource_name, resource_id, line_no_input):
        get_array_obj_array_data = get_router(schema_type.get('$ref'), rule)
        if get_array_obj_array_data.get('properties'):
            array_obj_array_keys = list(get_array_obj_array_data.get('properties').keys())
            array_obj_array_schema = get_array_obj_array_data.get('properties')
            for array_obj_array_len in range(len(input_js)):
                if isinstance(input_js[array_obj_array_len],dict):
                    if get_array_obj_array_data.get("required"):
                        for definitions_required in get_array_obj_array_data.get("required"):
                            if input_js[array_obj_array_len].get(definitions_required) is None:
                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                  input_len) + "]/" + array_key + "/" + array_obj_key + "/[" + str(
                                                  array_obj_array_len) + "]/" + definitions_required,
                                              "error": "array required field is not available.",
                                              "error_line_no": "N/A",
                                              "resource_id": resource_id
                                              }
                                error_list.append(error_json)

                    for array_obj_array_key in array_obj_array_keys:
                        array_obj_array_inputs = input_js[array_obj_array_len].get(array_obj_array_key)
                        if array_obj_array_inputs is not None:
                            schema_values_obj_array = array_obj_array_schema.get(array_obj_array_key)

                            if schema_values_obj_array.get('enum'):
                                if array_obj_array_inputs not in schema_values_obj_array.get('enum'):
                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                            array_obj_array_len][array_obj_array_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                      input_len) + "]/" + array_key + "/" + array_obj_key + "/[" + str(
                                                      array_obj_array_len) + "]/" + array_obj_array_key,
                                                  "error": "Array incorrect value",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                            # type check
                            if schema_values_obj_array.get('type'):
                                if type(array_obj_array_inputs).__name__.lower().replace(
                                        'str', 'string').replace('list', 'array').replace('bool',
                                                                                          'boolean').replace(
                                    "int",
                                    "number").replace(
                                    "dict", "object").replace("float", "number") == schema_values_obj_array.get('type'):

                                    if schema_values_obj_array.get("items"):
                                        if schema_values_obj_array.get("items").get('enum'):
                                            if not array_choice_validation(array_obj_array_inputs,
                                                                           schema_values_obj_array.get("items").get(
                                                                               'enum')):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                        array_obj_array_len][array_obj_array_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/" + array_obj_key + "/[" + str(
                                                                  array_obj_array_len) + "]/" + array_obj_array_key,
                                                              "error": "array Incorrect value",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        if schema_values_obj_array.get("items").get('type'):
                                            if type(array_obj_array_inputs).__name__.lower().replace(
                                                    'str', 'string').replace('list', 'array').replace('bool',
                                                                                                      'boolean').replace(
                                                "int",
                                                "number").replace(
                                                "dict", "object").replace("float", "number") == schema_values_obj_array.get(
                                                "items").get('type'):

                                                if schema_values_obj_array.get("items").get('pattern'):
                                                    if not re.match(
                                                            str(schema_values_obj_array.get("items").get('pattern')),
                                                            str(array_obj_array_inputs)):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][input_len][array_key][
                                                                array_obj_key][
                                                                array_obj_array_len][array_obj_array_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                                          input_len) + "]/" + array_key + "/" + array_obj_key + "/[" + str(
                                                                          array_obj_array_len) + "]/" + array_obj_array_key,
                                                                      "error": "Array pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:

                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                        array_obj_array_len][array_obj_array_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/" + array_obj_key + "/[" + str(
                                                                  array_obj_array_len) + "]/" + array_obj_array_key,
                                                              "error": "array datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        elif schema_values_obj_array.get("items").get('$ref'):
                                            pass

                                    if schema_values_obj_array.get('pattern'):
                                        if not re.match(str(schema_values_obj_array.get('pattern')),
                                                        str(array_obj_array_inputs)):
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                    array_obj_array_len][array_obj_array_key]).line
                                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                                              input_len) + "]/" + array_key + "/" + array_obj_key + "/[" + str(
                                                              array_obj_array_len) + "]/" + array_obj_array_key,
                                                          "error": "Array pattern is not match.",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)
                                else:

                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                            array_obj_array_len][array_obj_array_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                      input_len) + "]/" + array_key + "/" + array_obj_key + "/[" + str(
                                                      array_obj_array_len) + "]/" + array_obj_array_key,
                                                  "error": "Array datatype is not valid.",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)

                            if schema_values_obj_array.get('$ref'):
                                # array of data type
                                array_ref = get_router(schema_values_obj_array.get('$ref'), rule)
                                if array_ref.get("type"):
                                    if type(array_obj_array_inputs).__name__.lower().replace(
                                            'str', 'string').replace('list', 'array').replace('bool',
                                                                                              'boolean').replace(
                                        "int",
                                        "number").replace(
                                        "dict", "object").replace("float", "number") == array_ref.get("type"):
                                        if array_ref.get("pattern"):
                                            if not re.match(str(array_ref.get("pattern")),
                                                            str(array_obj_array_inputs)):
                                                # error pattern

                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                        array_obj_array_len][array_obj_array_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/" + array_obj_key + "/[" + str(
                                                                  array_obj_array_len) + "]/" + array_obj_array_key,
                                                              "error": "Array pattern is not match.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                    else:

                                        line_no = jsoncfg.node_location(
                                            line_no_input[definitions_key][input_len][array_key][array_obj_key][
                                                array_obj_array_len][array_obj_array_key]).line
                                        error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                          input_len) + "]/" + array_key + "/" + array_obj_key + "/[" + str(
                                                          array_obj_array_len) + "]/" + array_obj_array_key,
                                                      "error": "Array datatype is not valid.",
                                                      "error_line_no": line_no,
                                                      "resource_id": resource_id
                                                      }
                                        error_list.append(error_json)

                                elif schema_values_obj_array.get('$ref'):
                                    input_json = array_obj_array_inputs

    def array_array_obj_obj_validation(get_object_key, rule, input_json, definitions_key, input_len,
                                       array_key, array_array_len, array_array_key, arr_arr_obj_property_key,
                                       bundle_name,
                                       resource_name, resource_id, line_no_input):
        if get_object_key:
            get_array_array_object_object_data = get_router(get_object_key, rule)
            arr_arr_obj_obj_property = get_array_array_object_object_data.get("properties")
            arr_arr_obj_obj_property_keys = list(arr_arr_obj_obj_property.keys())
            if isinstance(input_json, dict):
                if get_array_array_object_object_data.get("required"):
                    for definitions_required in get_array_array_object_object_data.get("required"):
                        if input_json.get(definitions_required) is None:
                            error_json = {"file_name": bundle_name,
                                          "resource_name": resource_name,
                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                              input_len) + "]/" + array_key + "/[" + str(
                                              array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key + "/" + definitions_required,
                                          "error": "Array required field is not available.",
                                          "error_line_no": "N/A",
                                          "resource_id": resource_id
                                          }
                            error_list.append(error_json)

                for arr_arr_obj_obj_property_key in arr_arr_obj_obj_property_keys:
                    if input_json.get(arr_arr_obj_obj_property_key) is not None:
                        arr_arr_object_object_datatype = arr_arr_obj_obj_property.get(arr_arr_obj_obj_property_key)
                        if input_json.get(arr_arr_obj_obj_property_key):
                            if arr_arr_object_object_datatype.get('enum'):
                                if str(input_json.get(
                                        arr_arr_obj_obj_property_key)) is not arr_arr_object_object_datatype.get(
                                    'enum'):
                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][input_len][array_key][array_array_len][
                                            array_array_key][arr_arr_obj_property_key][
                                            arr_arr_obj_obj_property_key]).line
                                    error_json = {"file_name": bundle_name,
                                                  "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                      input_len) + "]/" + array_key + "/[" + str(
                                                      array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key + "/" + arr_arr_obj_obj_property_key,
                                                  "error": "Array incorrect value",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)

                            if arr_arr_object_object_datatype.get('type'):
                                if arr_arr_object_object_datatype.get('type') == (type(input_json.get(
                                        arr_arr_obj_obj_property_key)).__name__.lower().replace(
                                    'str',
                                    'string').replace(
                                    'list', 'array').replace('bool', 'boolean').replace("int",
                                                                                        "number").replace(
                                    "dict", "object").replace("float", "number")):
                                    if arr_arr_object_object_datatype.get("items"):
                                        if arr_arr_object_object_datatype.get("items").get('enum'):
                                            if not array_choice_validation(input_json.get(arr_arr_obj_obj_property_key),
                                                                           arr_arr_object_object_datatype.get(
                                                                               "items").get(
                                                                               'enum')):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][
                                                        array_array_len][
                                                        array_array_key][arr_arr_obj_property_key][
                                                        arr_arr_obj_obj_property_key]).line
                                                error_json = {"file_name": bundle_name,
                                                              "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/[" + str(
                                                                  array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key + "/" + arr_arr_obj_obj_property_key,
                                                              "error": "Array incorrect value",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        if arr_arr_object_object_datatype.get("items").get('type'):
                                            if type(input_json.get(
                                                    arr_arr_obj_obj_property_key)).__name__.lower().replace(
                                                'str', 'string').replace('list', 'array').replace('bool',
                                                                                                  'boolean').replace(
                                                "int",
                                                "number").replace(
                                                "dict", "object").replace("float",
                                                                          "number") == arr_arr_object_object_datatype.get(
                                                "items").get('type'):

                                                if arr_arr_object_object_datatype.get("items").get('pattern'):
                                                    if not re.match(
                                                            str(arr_arr_object_object_datatype.get("items").get(
                                                                'pattern')),
                                                            str(input_json.get(arr_arr_obj_obj_property_key))):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][input_len][array_key][
                                                                array_array_len][
                                                                array_array_key][arr_arr_obj_property_key][
                                                                arr_arr_obj_obj_property_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                                          input_len) + "]/" + array_key + "/[" + str(
                                                                          array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key + "/" + arr_arr_obj_obj_property_key,
                                                                      "error": "Array pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][
                                                        array_array_len][
                                                        array_array_key][arr_arr_obj_property_key][
                                                        arr_arr_obj_obj_property_key]).line
                                                error_json = {"file_name": bundle_name,
                                                              "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/[" + str(
                                                                  array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key + "/" + arr_arr_obj_obj_property_key,
                                                              "error": "Array datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        elif arr_arr_object_object_datatype.get("items").get('$ref'):
                                            pass

                                    if arr_arr_object_object_datatype.get('pattern'):
                                        if not re.match(str(arr_arr_object_object_datatype.get('pattern')),
                                                        str(input_json.get(
                                                            arr_arr_obj_obj_property_key))):
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][input_len][array_key][array_array_len][
                                                    array_array_key][arr_arr_obj_property_key][
                                                    arr_arr_obj_obj_property_key]).line
                                            error_json = {"file_name": bundle_name,
                                                          "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                                              input_len) + "]/" + array_key + "/[" + str(
                                                              array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key + "/" + arr_arr_obj_obj_property_key,
                                                          "error": "Array pattern is not match.",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)
                                else:
                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][input_len][array_key][array_array_len][
                                            array_array_key][arr_arr_obj_property_key][
                                            arr_arr_obj_obj_property_key]).line
                                    error_json = {"file_name": bundle_name,
                                                  "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                      input_len) + "]/" + array_key + "/[" + str(
                                                      array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key + "/" + arr_arr_obj_obj_property_key,
                                                  "error": "Array datatype is not valid.",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                            if arr_arr_object_object_datatype.get('$ref'):
                                if arr_arr_obj_obj_property.get(arr_arr_obj_obj_property_key):
                                    getobj_path = arr_arr_object_object_datatype.get('$ref')
                                    if getobj_path:
                                        obj_path_split = getobj_path.split("/")
                                        path_get = rule.get(obj_path_split[1]).get(obj_path_split[2])
                                        # ref->path->type
                                        if path_get.get("type"):
                                            if path_get.get("type") == (type(input_json.get(
                                                    arr_arr_obj_obj_property_key)).__name__.lower().replace(
                                                'str',
                                                'string').replace(
                                                'list', 'array').replace('bool', 'boolean').replace("int",
                                                                                                    "number").replace(
                                                "dict", "object").replace("float", "number")):
                                                if path_get.get("pattern"):
                                                    if not re.compile(str(path_get.get("pattern"))).match(
                                                            str(input_json.get(
                                                                arr_arr_obj_obj_property_key))):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][input_len][array_key][
                                                                array_array_len][
                                                                array_array_key][arr_arr_obj_property_key][
                                                                arr_arr_obj_obj_property_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                                          input_len) + "]/" + array_key + "/[" + str(
                                                                          array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key + "/" + arr_arr_obj_obj_property_key,
                                                                      "error": "Array pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:
                                                # ref->path->type error
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][
                                                        array_array_len][
                                                        array_array_key][arr_arr_obj_property_key][
                                                        arr_arr_obj_obj_property_key]).line
                                                error_json = {"file_name": bundle_name,
                                                              "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/[" + str(
                                                                  array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key + "/" + arr_arr_obj_obj_property_key,
                                                              "error": "Array datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        elif arr_arr_object_object_datatype.get('$ref'):
                                            # array array obj_obj_objvalidation
                                            input_json = input_json.get(arr_arr_obj_obj_property_key)
            else:
                line_no = jsoncfg.node_location(
                    line_no_input[definitions_key][input_len][array_key][
                        array_array_len][
                        array_array_key][arr_arr_obj_property_key]).line
                error_json = {"file_name": bundle_name,
                              "resource_name": resource_name,
                              "path": "root" + "/" + definitions_key + "/[" + str(
                                  input_len) + "]/" + array_key + "/[" + str(
                                  array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key ,
                              "error": "Array datatype is not valid.",
                              "error_line_no": line_no,
                              "resource_id": resource_id
                              }
                error_list.append(error_json)

    def array_array_object_array_validation(get_array_key, rule, input_json, definitions_key, input_len,
                                            array_key, array_array_len, array_array_key, arr_arr_obj_property_key,
                                            bundle_name, resource_name, resource_id, line_no_input):
        if get_array_key:
            get_array_array_object_array_data = get_router(get_array_key.get('$ref'), rule)
            if get_array_array_object_array_data.get('properties'):
                array_array_object_array_keys = list(get_array_array_object_array_data.get('properties').keys())
                array_array_object_array_schema = get_array_array_object_array_data.get('properties')
                for array_array_array_len in range(len(input_json)):
                    if isinstance(input_json[array_array_array_len],dict):
                        if get_array_array_object_array_data.get("required"):
                            for definitions_required in get_array_array_object_array_data.get("required"):
                                if input_json[array_array_array_len].get(definitions_required) is None:
                                    error_json = {"file_name": bundle_name,
                                                  "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                      input_len) + "]/" + array_key + "/[" + str(
                                                      array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key + "/[" + str(
                                                      array_array_array_len) + "]/" + definitions_required,
                                                  "error": "Array required field is not available.",
                                                  "error_line_no": "N/A",
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                        for array_array_object_array_key in array_array_object_array_keys:
                            array_array_object_array_inputs = input_json[array_array_array_len].get(
                                array_array_object_array_key)
                            if array_array_object_array_inputs is not None:
                                schema_values_object_arrays = array_array_object_array_schema.get(
                                    array_array_object_array_key)
                                if schema_values_object_arrays.get('enum'):
                                    if array_array_object_array_inputs not in schema_values_object_arrays.get('enum'):
                                        line_no = jsoncfg.node_location(
                                            line_no_input[definitions_key][input_len][array_key][array_array_len][
                                                array_array_key][arr_arr_obj_property_key][array_array_array_len][
                                                array_array_object_array_key]).line
                                        error_json = {"file_name": bundle_name,
                                                      "resource_name": resource_name,
                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                          input_len) + "]/" + array_key + "/[" + str(
                                                          array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key + "/[" + str(
                                                          array_array_array_len) + "]/" + array_array_object_array_key,
                                                      "error": "Array incorrect value",
                                                      "error_line_no": line_no,
                                                      "resource_id": resource_id
                                                      }
                                        error_list.append(error_json)
                                    # type check
                                if schema_values_object_arrays.get('type'):
                                    if type(array_array_object_array_inputs).__name__.lower().replace(
                                            'str', 'string').replace('list', 'array').replace('bool',
                                                                                              'boolean').replace(
                                        "int",
                                        "number").replace(
                                        "dict", "object").replace("float", "number") == get_array_key.get('type'):
                                        # array is checking

                                        if schema_values_object_arrays.get("items").get('enum'):
                                            if not array_choice_validation(array_array_object_array_inputs,
                                                                           schema_values_object_arrays.get("items").get(
                                                                               'enum')):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][
                                                        array_array_len][
                                                        array_array_key][arr_arr_obj_property_key][
                                                        array_array_array_len][
                                                        array_array_object_array_key]).line
                                                error_json = {"file_name": bundle_name,
                                                              "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/[" + str(
                                                                  array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key + "/[" + str(
                                                                  array_array_array_len) + "]/" + array_array_object_array_key,
                                                              "error": "Array incorrect value",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        if schema_values_object_arrays.get("items"):
                                            if schema_values_object_arrays.get("items").get('type'):
                                                if type(array_array_object_array_inputs).__name__.lower().replace(
                                                        'str', 'string').replace('list', 'array').replace('bool',
                                                                                                          'boolean').replace(
                                                    "int",
                                                    "number").replace(
                                                    "dict", "object").replace("float",
                                                                              "number") == schema_values_object_arrays.get(
                                                    "items").get('type'):

                                                    if schema_values_object_arrays.get("items").get('pattern'):
                                                        if not re.match(
                                                                str(schema_values_object_arrays.get("items").get(
                                                                    'pattern')),
                                                                str(array_array_object_array_inputs)):
                                                            line_no = jsoncfg.node_location(
                                                                line_no_input[definitions_key][input_len][array_key][
                                                                    array_array_len][
                                                                    array_array_key][arr_arr_obj_property_key][
                                                                    array_array_array_len][
                                                                    array_array_object_array_key]).line
                                                            error_json = {"file_name": bundle_name,
                                                                          "resource_name": resource_name,
                                                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                                                              input_len) + "]/" + array_key + "/[" + str(
                                                                              array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key + "/[" + str(
                                                                              array_array_array_len) + "]/" + array_array_object_array_key,
                                                                          "error": "Array pattern is not match.",
                                                                          "error_line_no": line_no,
                                                                          "resource_id": resource_id
                                                                          }
                                                            error_list.append(error_json)
                                                else:
                                                    line_no = jsoncfg.node_location(
                                                        line_no_input[definitions_key][input_len][array_key][
                                                            array_array_len][
                                                            array_array_key][arr_arr_obj_property_key][
                                                            array_array_array_len][
                                                            array_array_object_array_key]).line
                                                    error_json = {"file_name": bundle_name,
                                                                  "resource_name": resource_name,
                                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                                      input_len) + "]/" + array_key + "/[" + str(
                                                                      array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key + "/[" + str(
                                                                      array_array_array_len) + "]/" + array_array_object_array_key,
                                                                  "error": "Array datatype is not valid.",
                                                                  "error_line_no": line_no,
                                                                  "resource_id": resource_id
                                                                  }
                                                    error_list.append(error_json)
                                            elif schema_values_object_arrays.get("items").get('$ref'):
                                                pass

                                        if schema_values_object_arrays.get('pattern'):
                                            if not re.match(str(schema_values_object_arrays.get('pattern')),
                                                            str(array_array_object_array_inputs[
                                                                array_array_array_len].get(
                                                                array_array_object_array_key))):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][
                                                        array_array_len][
                                                        array_array_key][arr_arr_obj_property_key][
                                                        array_array_array_len][
                                                        array_array_object_array_key]).line
                                                error_json = {"file_name": bundle_name,
                                                              "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/[" + str(
                                                                  array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key + "/[" + str(
                                                                  array_array_array_len) + "]/" + array_array_object_array_key,
                                                              "error": "Array pattern is not match.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                    else:
                                        line_no = jsoncfg.node_location(
                                            line_no_input[definitions_key][input_len][array_key][array_array_len][
                                                array_array_key][arr_arr_obj_property_key][array_array_array_len][
                                                array_array_object_array_key]).line
                                        error_json = {"file_name": bundle_name,
                                                      "resource_name": resource_name,
                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                          input_len) + "]/" + array_key + "/[" + str(
                                                          array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key + "/[" + str(
                                                          array_array_array_len) + "]/" + array_array_object_array_key,
                                                      "error": "Array datatype is not valid.",
                                                      "error_line_no": line_no,
                                                      "resource_id": resource_id
                                                      }
                                        error_list.append(error_json)
                                if schema_values_object_arrays.get('$ref'):
                                    # array of data type
                                    array_ref = get_router(schema_values_object_arrays.get('$ref'), rule)
                                    if array_ref.get("type"):
                                        if type(array_array_object_array_inputs).__name__.lower().replace(
                                                'str', 'string').replace('list', 'array').replace('bool',
                                                                                                  'boolean').replace(
                                            "int",
                                            "number").replace(
                                            "dict", "object").replace("float", "number") == array_ref.get("type"):
                                            if array_ref.get("pattern"):
                                                if not re.match(str(array_ref.get("pattern")),
                                                                str(array_array_object_array_inputs)):
                                                    line_no = jsoncfg.node_location(
                                                        line_no_input[definitions_key][input_len][array_key][
                                                            array_array_len][
                                                            array_array_key][arr_arr_obj_property_key][
                                                            array_array_array_len][
                                                            array_array_object_array_key]).line
                                                    error_json = {"file_name": bundle_name,
                                                                  "resource_name": resource_name,
                                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                                      input_len) + "]/" + array_key + "/[" + str(
                                                                      array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key + "/[" + str(
                                                                      array_array_array_len) + "]/" + array_array_object_array_key,
                                                                  "error": "Array pattern is not match.",
                                                                  "error_line_no": line_no,
                                                                  "resource_id": resource_id
                                                                  }
                                                    error_list.append(error_json)
                                        else:
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][input_len][array_key][array_array_len][
                                                    array_array_key][arr_arr_obj_property_key][array_array_array_len][
                                                    array_array_object_array_key]).line
                                            error_json = {"file_name": bundle_name,
                                                          "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                                              input_len) + "]/" + array_key + "/[" + str(
                                                              array_array_len) + "]/" + array_array_key + "/" + arr_arr_obj_property_key + "/[" + str(
                                                              array_array_array_len) + "]/" + array_array_object_array_key,
                                                          "error": "Array datatype is not valid.",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)

                                    elif get_array_key.get('$ref'):
                                        input_json = array_array_object_array_inputs

    def array_array_array_validation(schema_values, rule, array_array_inputs, definitions_key, input_len,
                                     array_key, array_array_len, array_array_key, bundle_name, resource_name,
                                     resource_id, line_no_input):
        if schema_values.get("items"):
            get_array_array_array_data = get_router(schema_values.get("items").get('$ref'), rule)
            if get_array_array_array_data.get('properties'):
                array_array_array_keys = list(get_array_array_array_data.get('properties').keys())
                array_array_array_schema = get_array_array_array_data.get('properties')
                for array_array_array_len in range(len(array_array_inputs)):
                    if isinstance(array_array_inputs[array_array_array_len],dict):
                        if get_array_array_array_data.get("required"):
                            for definitions_required in get_array_array_array_data.get("required"):
                                if isinstance(array_array_inputs[array_array_array_len], dict):
                                    if array_array_inputs[array_array_array_len].get(definitions_required) is None:
                                        error_json = {"file_name": bundle_name,
                                                      "resource_name": resource_name,
                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                          input_len) + "]/" + array_key + "/[" + str(
                                                          array_array_len) + "]/" + array_array_key + "/[" + str(
                                                          array_array_array_len) + "]/" + definitions_required,
                                                      "error": "Array required field is not available.",
                                                      "error_line_no": "N/A",
                                                      "resource_id": resource_id
                                                      }
                                        error_list.append(error_json)
                        for array_array_array_key in array_array_array_keys:
                            if isinstance(array_array_inputs[array_array_array_len], dict):
                                array_array_array_inputs = array_array_inputs[array_array_array_len].get(
                                    array_array_array_key)
                                if array_array_array_inputs is not None:
                                    schema_values_arrays = array_array_array_schema.get(array_array_array_key)
                                    if schema_values_arrays.get('enum'):
                                        if array_array_array_inputs not in schema_values_arrays.get('enum'):
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][input_len][array_key][array_array_len][
                                                    array_array_key][array_array_array_len][array_array_array_key]).line
                                            error_json = {"file_name": bundle_name,
                                                          "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                                              input_len) + "]/" + array_key + "/[" + str(
                                                              array_array_len) + "]/" + array_array_key + "/[" + str(
                                                              array_array_array_len) + "]/" + array_array_array_key,
                                                          "error": "Array incorrect value",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)
                                    # type check
                                    if schema_values_arrays.get('type'):
                                        if type(array_array_array_inputs).__name__.lower().replace(
                                                'str', 'string').replace('list', 'array').replace('bool',
                                                                                                  'boolean').replace(
                                            "int",
                                            "number").replace(
                                            "dict", "object").replace("float", "number") == schema_values.get('type'):

                                            if schema_values_arrays.get("items"):
                                                if schema_values_arrays.get("items").get('enum'):
                                                    if not array_choice_validation(array_array_array_inputs,
                                                                                   schema_values_arrays.get(
                                                                                       "items").get(
                                                                                       'enum')):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][input_len][array_key][
                                                                array_array_len][
                                                                array_array_key][array_array_array_len][
                                                                array_array_array_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                                          input_len) + "]/" + array_key + "/[" + str(
                                                                          array_array_len) + "]/" + array_array_key + "/[" + str(
                                                                          array_array_array_len) + "]/" + array_array_array_key,
                                                                      "error": "Array incorrect value",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                                if schema_values_arrays.get("items").get('type'):
                                                    if type(array_array_array_inputs).__name__.lower().replace(
                                                            'str', 'string').replace('list', 'array').replace('bool',
                                                                                                              'boolean').replace(
                                                        "int",
                                                        "number").replace(
                                                        "dict", "object").replace("float",
                                                                                  "number") == schema_values_arrays.get(
                                                        "items").get('type'):

                                                        if schema_values_arrays.get("items").get('pattern'):
                                                            if not re.match(
                                                                    str(schema_values_arrays.get("items").get(
                                                                        'pattern')),
                                                                    str(array_array_array_inputs)):
                                                                line_no = jsoncfg.node_location(
                                                                    line_no_input[definitions_key][input_len][
                                                                        array_key][
                                                                        array_array_len][
                                                                        array_array_key][array_array_array_len][
                                                                        array_array_array_key]).line
                                                                error_json = {"file_name": bundle_name,
                                                                              "resource_name": resource_name,
                                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                                  input_len) + "]/" + array_key + "/[" + str(
                                                                                  array_array_len) + "]/" + array_array_key + "/[" + str(
                                                                                  array_array_array_len) + "]/" + array_array_array_key,
                                                                              "error": "Array pattern is not match.",
                                                                              "error_line_no": line_no,
                                                                              "resource_id": resource_id
                                                                              }
                                                                error_list.append(error_json)
                                                    else:
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][input_len][array_key][
                                                                array_array_len][
                                                                array_array_key][array_array_array_len][
                                                                array_array_array_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                                          input_len) + "]/" + array_key + "/[" + str(
                                                                          array_array_len) + "]/" + array_array_key + "/[" + str(
                                                                          array_array_array_len) + "]/" + array_array_array_key,
                                                                      "error": "Array datatype is not valid.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                                elif schema_values_arrays.get("items").get('$ref'):
                                                    pass

                                            if schema_values_arrays.get('pattern'):
                                                if not re.match(str(schema_values_arrays.get('pattern')),
                                                                str(array_array_array_inputs[array_array_array_len].get(
                                                                    array_array_array_key))):
                                                    line_no = jsoncfg.node_location(
                                                        line_no_input[definitions_key][input_len][array_key][
                                                            array_array_len][
                                                            array_array_key][array_array_array_len][
                                                            array_array_array_key]).line
                                                    error_json = {"file_name": bundle_name,
                                                                  "resource_name": resource_name,
                                                                  "path": "root" + "/" + definitions_key + "/[" + str(
                                                                      input_len) + "]/" + array_key + "/[" + str(
                                                                      array_array_len) + "]/" + array_array_key + "/[" + str(
                                                                      array_array_array_len) + "]/" + array_array_array_key,
                                                                  "error": "Array pattern is not match.",
                                                                  "error_line_no": line_no,
                                                                  "resource_id": resource_id
                                                                  }
                                                    error_list.append(error_json)
                                        else:
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][input_len][array_key][array_array_len][
                                                    array_array_key][array_array_array_len][array_array_array_key]).line
                                            error_json = {"file_name": bundle_name,
                                                          "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/[" + str(
                                                              input_len) + "]/" + array_key + "/[" + str(
                                                              array_array_len) + "]/" + array_array_key + "/[" + str(
                                                              array_array_array_len) + "]/" + array_array_array_key,
                                                          "error": "Array datatype is not valid.",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)

                                    if schema_values_arrays.get('$ref'):
                                        array_ref = get_router(schema_values_arrays.get('$ref'), rule)
                                        if array_ref.get("type"):
                                            if type(array_array_array_inputs).__name__.lower().replace(
                                                    'str', 'string').replace('list', 'array').replace('bool',
                                                                                                      'boolean').replace(
                                                "int",
                                                "number").replace(
                                                "dict", "object").replace("float", "number") == array_ref.get("type"):
                                                if array_ref.get("pattern"):
                                                    if not re.match(str(array_ref.get("pattern")),
                                                                    str(array_array_array_inputs)):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][input_len][array_key][
                                                                array_array_len][
                                                                array_array_key][array_array_array_len][
                                                                array_array_array_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/[" + str(
                                                                          input_len) + "]/" + array_key + "/[" + str(
                                                                          array_array_len) + "]/" + array_array_key + "/[" + str(
                                                                          array_array_array_len) + "]/" + array_array_array_key,
                                                                      "error": "Array pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][input_len][array_key][
                                                        array_array_len][
                                                        array_array_key][array_array_array_len][
                                                        array_array_array_key]).line
                                                error_json = {"file_name": bundle_name,
                                                              "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/[" + str(
                                                                  input_len) + "]/" + array_key + "/[" + str(
                                                                  array_array_len) + "]/" + array_array_key + "/[" + str(
                                                                  array_array_array_len) + "]/" + array_array_array_key,
                                                              "error": "Array datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)

                                        elif schema_values.get('$ref'):
                                            input_json = array_array_array_inputs

                                        # array array array object validation

    # object_start
    def obj_validation(schema_path_get, rule, definitions_key, input_js, bundle_name, resource_name, resource_id,
                       line_no_input):
        if schema_path_get.get("$ref"):
            ref_path_obj = get_router(schema_path_get.get("$ref"), rule)
            obj_property = ref_path_obj.get("properties")
            if isinstance(input_js.get(definitions_key), dict):
                if ref_path_obj.get("required"):
                    for definitions_required in ref_path_obj.get("required"):
                        if input_js.get(definitions_key).get(definitions_required) is None:
                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                          "path": "root" + "/" + definitions_key + "/" + definitions_required,
                                          "error": "Object required field is not available.",
                                          "error_line_no": "N/A",
                                          "resource_id": resource_id
                                          }
                            error_list.append(error_json)
                obj_property_keys = list(obj_property.keys())
                if isinstance(input_js.get(definitions_key), dict):
                    for obj_property_key in obj_property_keys:
                        if input_js.get(definitions_key).get(obj_property_key) is not None:
                            input_obj = input_js.get(definitions_key).get(obj_property_key)
                            object_datatype = obj_property.get(obj_property_key)
                            if object_datatype.get("const"):
                                if input_obj != schema_path_get.get("const"):
                                    line_no = jsoncfg.node_location(line_no_input[definitions_key][obj_property_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/" + obj_property_key,
                                                  "error": "Object const value not match",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)

                            if object_datatype.get('enum'):
                                if not array_choice_validation(input_obj,
                                                               object_datatype.get('enum')):
                                    line_no = jsoncfg.node_location(line_no_input[definitions_key][obj_property_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/" + obj_property_key,
                                                  "error": "Object incorrect value",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                            # obj ->type validatin
                            if object_datatype.get('type'):
                                if object_datatype.get('type') == (type(input_obj).__name__.lower().replace(
                                        'str',
                                        'string').replace(
                                    'list', 'array').replace('bool', 'boolean').replace("int",
                                                                                        "number").replace(
                                    "dict", "object").replace("float", "number")):

                                    if object_datatype.get("items"):
                                        if object_datatype.get("items").get('enum'):
                                            if not array_choice_validation(input_obj,
                                                                           object_datatype.get("items").get('enum')):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][obj_property_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/" + obj_property_key,
                                                              "error": "Object incorrect value",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        if object_datatype.get("items").get('type'):
                                            if type(input_obj).__name__.lower().replace(
                                                    'str', 'string').replace('list', 'array').replace('bool',
                                                                                                      'boolean').replace(
                                                "int",
                                                "number").replace(
                                                "dict", "object").replace("float", "number") == object_datatype.get(
                                                "items").get('type'):

                                                if object_datatype.get("items").get('pattern'):
                                                    if not re.match(str(object_datatype.get("items").get('pattern')),
                                                                    str(input_obj)):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][obj_property_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/" + obj_property_key,
                                                                      "error": "Object pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][obj_property_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/" + obj_property_key,
                                                              "error": "Object datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        elif object_datatype.get("items").get('$ref'):
                                            obj_array_Validation(object_datatype.get("items"), rule, definitions_key,
                                                                 input_obj,
                                                                 obj_property_key, bundle_name, resource_name, resource_id,
                                                                 line_no_input)

                                    if object_datatype.get('pattern'):
                                        if not re.match(str(object_datatype.get('pattern')),
                                                        str(input_obj)):
                                            # pattern error
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][obj_property_key]).line
                                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/" + obj_property_key,
                                                          "error": "Object pattern is not match.",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)
                                else:
                                    line_no = jsoncfg.node_location(line_no_input[definitions_key][obj_property_key]).line
                                    # object datatype error
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/" + obj_property_key,
                                                  "error": "Object datatype is not valid.",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                            if object_datatype.get('$ref'):
                                if ref_path_obj.get("properties").get(obj_property_key):
                                    getobj_path = ref_path_obj.get("properties").get(obj_property_key).get(
                                        "$ref")
                                    if getobj_path:
                                        obj_path_split = getobj_path.split("/")
                                        path_get = rule.get(obj_path_split[1]).get(obj_path_split[2])
                                        # ref->path->type
                                        if path_get.get("type"):
                                            if path_get.get("type") == (type(input_js.get(definitions_key).get(
                                                    obj_property_key)).__name__.lower().replace(
                                                'str',
                                                'string').replace(
                                                'list', 'array').replace('bool', 'boolean').replace("int",
                                                                                                    "number").replace(
                                                "dict", "object").replace("float", "number")):
                                                if path_get.get("pattern"):
                                                    if not re.compile(str(path_get.get("pattern"))).match(
                                                            str(input_js.get(definitions_key).get(
                                                                obj_property_key))):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][obj_property_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/" + obj_property_key,
                                                                      "error": "Object pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:
                                                # ref->path->type error
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][obj_property_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/" + obj_property_key,
                                                              "error": "Object datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        else:
                                            pass
                                            object_obj_validation(getobj_path, rule,
                                                                  input_js.get(definitions_key).get(
                                                                      obj_property_key), definitions_key, obj_property_key,
                                                                  bundle_name, resource_name, resource_id, line_no_input)
            else:
                line_no = jsoncfg.node_location(line_no_input[definitions_key]).line
                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                              "path": "root" + "/" + definitions_key,
                              "error": "Datatype is not valid.",
                              "error_line_no": line_no,
                              "resource_id": resource_id
                              }
                error_list.append(error_json)

    def obj_array_Validation(schema_type, rule, definitions_key, input_js, obj_property_key,
                             bundle_name, resource_name, resource_id, line_no_input):
        if schema_type.get('$ref'):
            get_array_obj_array_data = get_router(schema_type.get('$ref'), rule)
            if get_array_obj_array_data.get('properties'):
                array_obj_array_keys = list(get_array_obj_array_data.get('properties').keys())
                array_obj_array_schema = get_array_obj_array_data.get('properties')
                for array_obj_array_len in range(len(input_js)):
                    if isinstance(input_js[array_obj_array_len], dict):
                        if get_array_obj_array_data.get("required"):
                            for definitions_required in get_array_obj_array_data.get("required"):
                                if input_js[array_obj_array_len].get(definitions_required) is None:
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/[" + str(
                                                      array_obj_array_len) + "]/" + definitions_required,
                                                  "error": "Object required field is not available.",
                                                  "error_line_no": "N/A",
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)

                        for array_obj_array_key in array_obj_array_keys:
                            if isinstance(input_js[array_obj_array_len], dict):
                                array_obj_array_inputs = input_js[array_obj_array_len].get(array_obj_array_key)
                                if array_obj_array_inputs is not None:
                                    schema_values_obj_array = array_obj_array_schema.get(array_obj_array_key)

                                    if schema_values_obj_array.get('enum'):
                                        if array_obj_array_inputs not in schema_values_obj_array.get('enum'):
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][obj_property_key][
                                                    array_obj_array_len][array_obj_array_key]).line
                                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/[" + str(
                                                              array_obj_array_len) + "]/" + array_obj_array_key,
                                                          "error": "Object incorrect value",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)
                                    # type check
                                    if schema_values_obj_array.get('type'):
                                        if type(array_obj_array_inputs).__name__.lower().replace(
                                                'str', 'string').replace('list', 'array').replace('bool',
                                                                                                  'boolean').replace(
                                            "int",
                                            "number").replace(
                                            "dict", "object").replace("float", "number") == schema_values_obj_array.get(
                                            'type'):

                                            if schema_values_obj_array.get("items"):
                                                if schema_values_obj_array.get("items").get('enum'):
                                                    if not array_choice_validation(array_obj_array_inputs,
                                                                                   schema_values_obj_array.get("items").get(
                                                                                       'enum')):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][obj_property_key][
                                                                array_obj_array_len][array_obj_array_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/[" + str(
                                                                          array_obj_array_len) + "]/" + array_obj_array_key,
                                                                      "error": "Object Incorrect value",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                                if schema_values_obj_array.get("items").get('type'):
                                                    if type(array_obj_array_inputs).__name__.lower().replace(
                                                            'str', 'string').replace('list', 'array').replace('bool',
                                                                                                              'boolean').replace(
                                                        "int",
                                                        "number").replace(
                                                        "dict", "object").replace("float",
                                                                                  "number") == schema_values_obj_array.get(
                                                        "items").get('type'):

                                                        if schema_values_obj_array.get("items").get('pattern'):
                                                            if not re.match(
                                                                    str(schema_values_obj_array.get("items").get(
                                                                        'pattern')),
                                                                    str(array_obj_array_inputs)):
                                                                line_no = jsoncfg.node_location(
                                                                    line_no_input[definitions_key][obj_property_key][
                                                                        array_obj_array_len][array_obj_array_key]).line
                                                                error_json = {"file_name": bundle_name,
                                                                              "resource_name": resource_name,
                                                                              "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/[" + str(
                                                                                  array_obj_array_len) + "]/" + array_obj_array_key,
                                                                              "error": "Object pattern is not match.",
                                                                              "error_line_no": line_no,
                                                                              "resource_id": resource_id
                                                                              }
                                                                error_list.append(error_json)
                                                    else:

                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][obj_property_key][
                                                                array_obj_array_len][array_obj_array_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/[" + str(
                                                                          array_obj_array_len) + "]/" + array_obj_array_key,
                                                                      "error": "Object datatype is not valid.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                                elif schema_values_obj_array.get("items").get('$ref'):
                                                    pass

                                            if schema_values_obj_array.get('pattern'):
                                                if not re.match(str(schema_values_obj_array.get('pattern')),
                                                                str(array_obj_array_inputs)):
                                                    line_no = jsoncfg.node_location(
                                                        line_no_input[definitions_key][obj_property_key][
                                                            array_obj_array_len][array_obj_array_key]).line
                                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                                  "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/[" + str(
                                                                      array_obj_array_len) + "]/" + array_obj_array_key,
                                                                  "error": "Object pattern is not match.",
                                                                  "error_line_no": line_no,
                                                                  "resource_id": resource_id
                                                                  }
                                                    error_list.append(error_json)
                                        else:

                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][obj_property_key][
                                                    array_obj_array_len][array_obj_array_key]).line
                                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/[" + str(
                                                              array_obj_array_len) + "]/" + array_obj_array_key,
                                                          "error": "Object datatype is not valid.",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)

                                    if schema_values_obj_array.get('$ref'):
                                        # array of data type
                                        array_ref = get_router(schema_values_obj_array.get('$ref'), rule)
                                        if array_ref.get("type"):
                                            if type(array_obj_array_inputs).__name__.lower().replace(
                                                    'str', 'string').replace('list', 'array').replace('bool',
                                                                                                      'boolean').replace(
                                                "int",
                                                "number").replace(
                                                "dict", "object").replace("float", "number") == array_ref.get("type"):
                                                if array_ref.get("pattern"):
                                                    if not re.match(str(array_ref.get("pattern")),
                                                                    str(array_obj_array_inputs)):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][obj_property_key][
                                                                array_obj_array_len][array_obj_array_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/[" + str(
                                                                          array_obj_array_len) + "]/" + array_obj_array_key,
                                                                      "error": "Object pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:

                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][obj_property_key][
                                                        array_obj_array_len][array_obj_array_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/[" + str(
                                                                  array_obj_array_len) + "]/" + array_obj_array_key,
                                                              "error": "Object datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)

                                        elif schema_values_obj_array.get('$ref'):
                                            input_json = array_obj_array_inputs

    def object_obj_validation(getobj_path, rule, input_js, definitions_key, obj_property_key, bundle_name,
                              resource_name,
                              resource_id, line_no_input):
        if getobj_path:
            obj_obj_path_split = getobj_path.split("/")
            obj_path_get = rule.get(obj_obj_path_split[1]).get(obj_obj_path_split[2])
            obj_obj_property = obj_path_get.get("properties")
            obj_obj_property_keys = list(obj_obj_property.keys())
            if isinstance(input_js, dict):
                if obj_path_get.get("required"):
                    for definitions_required in obj_path_get.get("required"):
                        if input_js.get(definitions_required) is None:
                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                          "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + definitions_required,
                                          "error": "Object required field is not available.",
                                          "error_line_no": "N/A",
                                          "resource_id": resource_id
                                          }
                            error_list.append(error_json)
                for obj_obj_key in obj_obj_property_keys:
                    if isinstance(input_js, dict):
                        input_obj_obj = input_js.get(obj_obj_key)
                        if input_obj_obj is not None:
                            obj_obj_datatypes = obj_obj_property.get(obj_obj_key)
                            if obj_obj_datatypes.get('enum'):
                                if input_obj_obj not in obj_obj_datatypes.get('enum'):
                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][obj_property_key][obj_obj_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key,
                                                  "error": "Object incorrect value..",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                            if obj_obj_datatypes.get("type"):
                                if obj_obj_datatypes.get("type") == (type(input_obj_obj).__name__.lower().replace('str',
                                                                                                                  'string').replace(
                                    'list', 'array').replace('bool', 'boolean').replace("int", "number").replace(
                                    "dict", "object").replace("float", "number")):

                                    if obj_obj_datatypes.get("items"):
                                        if obj_obj_datatypes.get("items").get('enum'):
                                            if not array_choice_validation(input_obj_obj,
                                                                           obj_obj_datatypes.get("items").get('enum')):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][obj_property_key][obj_obj_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key,
                                                              "error": "Object incorrect value.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        if obj_obj_datatypes.get("items").get('type'):
                                            if type(input_obj_obj).__name__.lower().replace(
                                                    'str', 'string').replace('list', 'array').replace('bool',
                                                                                                      'boolean').replace(
                                                "int",
                                                "number").replace(
                                                "dict", "object").replace("float", "number") == obj_obj_datatypes.get(
                                                "items").get('type'):

                                                if obj_obj_datatypes.get("items").get('pattern'):
                                                    if not re.match(str(obj_obj_datatypes.get("items").get('pattern')),
                                                                    str(input_obj_obj)):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][obj_property_key][
                                                                obj_obj_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key,
                                                                      "error": "Object pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][obj_property_key][obj_obj_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key,
                                                              "error": "Object datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        elif obj_obj_datatypes.get("items").get('$ref'):

                                            obj_obj_array(obj_obj_datatypes.get("items"), rule, input_obj_obj,
                                                          definitions_key,
                                                          obj_property_key, obj_obj_key, bundle_name, resource_name,
                                                          resource_id, line_no_input)

                                    if obj_obj_datatypes.get("pattern"):
                                        if not re.compile(str(obj_obj_datatypes.get("pattern"))).match(
                                                (str(input_obj_obj))):
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][obj_property_key][obj_obj_key]).line
                                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key,
                                                          "error": "Object pattern is not match.",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)

                                    if obj_obj_datatypes.get('enum'):
                                        line_no = jsoncfg.node_location(
                                            line_no_input[definitions_key][obj_property_key][obj_obj_key]).line
                                        if input_obj_obj not in obj_obj_datatypes.get('enum'):
                                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key,
                                                          "error": "Object incorrect value.",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)
                                else:
                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][obj_property_key][obj_obj_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key,
                                                  "error": "Object datatype is not match.",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)

                            if obj_obj_datatypes.get('$ref'):
                                obj_obj_datatype_split = obj_obj_datatypes.get('$ref').split("/")
                                obj_obj_datatype_get_obj = rule.get(obj_obj_datatype_split[1]).get(
                                    obj_obj_datatype_split[2])
                                if obj_obj_datatype_get_obj.get("type"):
                                    if obj_obj_datatype_get_obj.get("type") == (
                                            type(input_obj_obj).__name__.lower().replace(
                                                'str',
                                                'string').replace(
                                                'list', 'array').replace('bool', 'boolean').replace("int",
                                                                                                    "number").replace(
                                                "dict", "object").replace("float", "number")):
                                        if obj_obj_datatype_get_obj.get("pattern"):
                                            if not re.compile(str(obj_obj_datatype_get_obj.get("pattern"))).match(
                                                    (str(input_obj_obj))):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][obj_property_key][obj_obj_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key,
                                                              "error": "Object Pattern is not match.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                    else:
                                        line_no = jsoncfg.node_location(
                                            line_no_input[definitions_key][obj_property_key][obj_obj_key]).line
                                        error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                      "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key,
                                                      "error": "Object datatype is not match.",
                                                      "error_line_no": line_no,
                                                      "resource_id": resource_id
                                                      }
                                        error_list.append(error_json)

                                elif obj_obj_datatypes.get('$ref'):
                                    object_obj_obj_validation(obj_obj_datatypes.get('$ref'), rule, input_obj_obj,
                                                              definitions_key,
                                                              obj_property_key, obj_obj_key, bundle_name, resource_name,
                                                              resource_id, line_no_input)
            else:
                line_no = jsoncfg.node_location(
                    line_no_input[definitions_key][obj_property_key]).line
                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                              "path": "root" + "/" + definitions_key + "/" + obj_property_key,
                              "error": "Object datatype is not match.",
                              "error_line_no": line_no,
                              "resource_id": resource_id
                              }
                error_list.append(error_json)

    def object_obj_obj_validation(getobj_path, rule, input_js, definitions_key, obj_property_key, obj_obj_key,
                                  bundle_name,
                                  resource_name, resource_id, line_no_input):

        if getobj_path:
            obj_path_split = getobj_path.split("/")
            obj_path_get = rule.get(obj_path_split[1]).get(obj_path_split[2])
            obj_property = obj_path_get.get('properties')
            obj_property_keys = list(obj_property.keys())
            if isinstance(input_js, dict):
                if obj_path_get.get('required'):
                    for definitions_required in obj_path_get.get('required'):
                        if input_js.get(definitions_required) is None:
                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                          "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + definitions_required,
                                          "error": "Object required datatype is not valid.",
                                          "error_line_no": "N/A",
                                          "resource_id": resource_id
                                          }
                            error_list.append(error_json)
                for obj_key in obj_property_keys:
                    if isinstance(input_js, dict):
                        input_obj = input_js.get(obj_key)
                        if input_obj is not None:
                            obj_datatypes = obj_property.get(obj_key)
                            if obj_datatypes.get('enum'):
                                if input_obj not in obj_datatypes.get('enum'):

                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][obj_property_key][obj_obj_key][obj_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_key,
                                                  "error": "Object incorrect value..",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                            if obj_datatypes.get("type"):

                                if obj_datatypes.get("type") == (type(input_obj).__name__.lower().replace('str',
                                                                                                          'string').replace(
                                    'list', 'array').replace('bool', 'boolean').replace("int", "number").replace(
                                    "dict", "object").replace("float", "number")):

                                    if obj_datatypes.get("items"):
                                        if obj_datatypes.get("items").get('enum'):
                                            if not array_choice_validation(input_obj,
                                                                           obj_datatypes.get("items").get('enum')):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                        obj_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_key,
                                                              "error": "Object incorrect value",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        if obj_datatypes.get("items").get('type'):
                                            if type(input_obj).__name__.lower().replace(
                                                    'str', 'string').replace('list', 'array').replace('bool',
                                                                                                      'boolean').replace(
                                                "int",
                                                "number").replace(
                                                "dict", "object").replace("float", "number") == obj_datatypes.get(
                                                "items").get('type'):

                                                if obj_datatypes.get("items").get('pattern'):
                                                    if not re.match(str(obj_datatypes.get("items").get('pattern')),
                                                                    str(input_obj)):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                                obj_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_key,
                                                                      "error": "Object Pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                        obj_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_key,
                                                              "error": "Object datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        elif obj_datatypes.get("items").get('$ref'):
                                            obj_obj_obj_array_validation(obj_datatypes.get("items"), rule, input_obj,
                                                                         definitions_key, obj_property_key, obj_obj_key,
                                                                         obj_key,
                                                                         bundle_name,
                                                                         resource_name, resource_id, line_no_input)
                                    # obj -array
                                    if obj_datatypes.get("pattern"):
                                        if not re.compile(str(obj_datatypes.get("pattern"))).match(
                                                (str(input_obj))):
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][obj_property_key][obj_obj_key][obj_key]).line
                                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_key,
                                                          "error": "Object pattern is not match.",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)

                                    if obj_datatypes.get('enum'):
                                        if input_obj not in obj_datatypes.get('enum'):
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][obj_property_key][obj_obj_key][obj_key]).line
                                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_key,
                                                          "error": "Object incorrect value.",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)
                                else:
                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][obj_property_key][obj_obj_key][obj_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_key,
                                                  "error": "Object datatype is not valid.",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                            if obj_datatypes.get('$ref'):
                                obj_datatype_split = obj_datatypes.get('$ref').split("/")
                                obj_datatype_get = rule.get(obj_datatype_split[1]).get(obj_datatype_split[2])
                                if obj_datatypes.get('enum'):
                                    if input_obj not in obj_datatypes.get('enum'):
                                        line_no = jsoncfg.node_location(
                                            line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                obj_key]).line
                                        error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                      "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_key,
                                                      "error": "Object incorrect value..",
                                                      "error_line_no": line_no,
                                                      "resource_id": resource_id
                                                      }
                                        error_list.append(error_json)
                                if obj_datatype_get.get('type'):
                                    if obj_datatype_get.get('type') == (
                                            type(input_obj).__name__.lower().replace('str', 'string').replace('list',
                                                                                                              'array')
                                                    .replace('bool', 'boolean').replace("int", "number").replace("dict",
                                                                                                                 "object").replace(
                                                "float", "number")):
                                        if obj_datatype_get.get("pattern"):
                                            if not re.compile(str(obj_datatype_get.get("pattern"))).match(
                                                    (str(input_obj))):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                        obj_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/" + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_key,
                                                              "error": "Object pattern is not match.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)

                                    else:
                                        line_no = jsoncfg.node_location(
                                            line_no_input[definitions_key][obj_property_key][obj_obj_key][obj_key]).line
                                        error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                      "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_key,
                                                      "error": "Object datatype is not match.",
                                                      "error_line_no": line_no,
                                                      "resource_id": resource_id
                                                      }
                                        error_list.append(error_json)
                                elif obj_datatypes.get('$ref'):
                                    object_obj_obj_obj_validation(obj_datatypes.get('$ref'), rule, input_obj,
                                                                  definitions_key,
                                                                  obj_property_key, bundle_name, resource_name, resource_id,
                                                                  line_no_input, obj_obj_key, obj_key)
            else:
                line_no = jsoncfg.node_location(
                    line_no_input[definitions_key][obj_property_key][obj_obj_key]).line
                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                              "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key,
                              "error": "Object datatype is not match.",
                              "error_line_no": line_no,
                              "resource_id": resource_id
                              }
                error_list.append(error_json)

    def object_obj_obj_obj_validation(get_obj_path, rule, input_js, definitions_key, obj_property_key, bundle_name,
                                      resource_name, resource_id, line_no_input, obj_obj_key, obj_schema_key):
        if get_obj_path:
            obj_path_split = get_obj_path.split("/")
            obj_path_get = rule.get(obj_path_split[1]).get(obj_path_split[2])
            obj_property = obj_path_get.get('properties')
            obj_property_keys = list(obj_property.keys())
            if isinstance(input_js, dict):
                if obj_path_get.get("required"):
                    for definitions_required in obj_path_get.get("required"):
                        if input_js.get(definitions_required) is None:
                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                          "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_schema_key + "/" + definitions_required,
                                          "error": "Object required field is not available.",
                                          "error_line_no": "N/A",
                                          "resource_id": resource_id
                                          }
                            error_list.append(error_json)
                for obj_key in obj_property_keys:
                    if isinstance(input_js, dict):
                        input_obj = input_js.get(obj_key)
                        if input_obj is not None:
                            obj_datatypes = obj_property.get(obj_key)
                            if obj_datatypes.get('enum'):
                                if input_obj not in obj_datatypes.get('enum'):
                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][obj_property_key][obj_obj_key][obj_schema_key][
                                            obj_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_schema_key + "/" + obj_key,
                                                  "error": "Object incorrect value",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                            if obj_datatypes.get("type"):
                                if obj_datatypes.get("type") == (type(input_obj).__name__.lower().replace('str',
                                                                                                          'string').replace(
                                    'list', 'array').replace('bool', 'boolean').replace("int", "number").replace(
                                    "dict", "object").replace("float", "number")):

                                    if obj_datatypes.get("items"):
                                        if obj_datatypes.get("items").get('enum'):
                                            if not array_choice_validation(input_obj,
                                                                           obj_datatypes.get("items").get('enum')):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                        obj_schema_key][obj_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_schema_key + "/" + obj_key,
                                                              "error": "Object incorrect value",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        if obj_datatypes.get("items").get('type'):
                                            if type(input_obj).__name__.lower().replace(
                                                    'str', 'string').replace('list', 'array').replace('bool',
                                                                                                      'boolean').replace(
                                                "int",
                                                "number").replace(
                                                "dict", "object").replace("float", "number") == obj_datatypes.get(
                                                "items").get(
                                                'type'):

                                                if obj_datatypes.get("items").get('pattern'):
                                                    if not re.match(str(obj_datatypes.get("items").get('pattern')),
                                                                    str(input_obj)):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                                obj_schema_key][obj_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_schema_key + "/" + obj_key,
                                                                      "error": "Object pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                        obj_schema_key][obj_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_schema_key + "/" + obj_key,
                                                              "error": "Object datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                        elif obj_datatypes.get("items").get('$ref'):
                                            pass

                                    # obj -array
                                    if obj_datatypes.get("pattern"):
                                        if re.compile(str(obj_datatypes.get("pattern"))).match(
                                                (str(input_obj))):
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                    obj_schema_key][obj_key]).line
                                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_schema_key + "/" + obj_key,
                                                          "error": "Object pattern is not match.",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)

                                    if obj_datatypes.get('enum'):
                                        if input_obj not in obj_datatypes.get('enum'):
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                    obj_schema_key][obj_key]).line
                                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_schema_key + "/" + obj_key,
                                                          "error": "Object incorrect value",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)
                                else:
                                    line_no = jsoncfg.node_location(
                                        line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                            obj_schema_key][obj_key]).line
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_schema_key + "/" + obj_key,
                                                  "error": "Object datatype is not valid.",
                                                  "error_line_no": line_no,
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)

                            if obj_datatypes.get('$ref'):
                                obj_datatype_split = obj_datatypes.get('$ref').split("/")
                                obj_datatype_get = rule.get(obj_datatype_split[1]).get(obj_datatype_split[2])
                                if obj_datatype_get.get('type'):
                                    if obj_datatype_get.get('type') == (
                                            type(input_obj).__name__.lower().replace('str', 'string').replace('list',
                                                                                                              'array')
                                                    .replace('bool', 'boolean').replace("int", "number").replace("dict",
                                                                                                                 "object").replace(
                                                "float", "number")):
                                        if obj_datatype_get.get('pattern'):
                                            if not re.compile(str(obj_datatype_get.get('pattern'))).match(
                                                    (str(input_obj))):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                        obj_schema_key][obj_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_schema_key + "/" + obj_key,
                                                              "error": "Object pattern is not match.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)


                                        if obj_datatypes.get('enum'):
                                            print(obj_datatypes.get('enum'))
                                            if input_obj not in obj_datatypes.get('enum'):
                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                        obj_schema_key][obj_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_schema_key + "/" + obj_key,
                                                              "error": "Object incorrect value",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)
                                    else:
                                        line_no = jsoncfg.node_location(
                                            line_no_input[definitions_key][obj_property_key][obj_obj_key][obj_schema_key][
                                                obj_key]).line
                                        error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                      "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_schema_key + "/" + obj_key,
                                                      "error": "Object datatype is not match.",
                                                      "error_line_no": line_no,
                                                      "resource_id": resource_id
                                                      }
                                        error_list.append(error_json)
            else:
                line_no = jsoncfg.node_location(
                    line_no_input[definitions_key][obj_property_key][obj_obj_key][obj_schema_key]).line
                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                              "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_schema_key,
                              "error": "Object datatype is not match.",
                              "error_line_no": line_no,
                              "resource_id": resource_id
                              }
                error_list.append(error_json)

    def obj_obj_array(schema_type, rule, definitions_key, input_js,
                      obj_property_key, obj_obj_key, bundle_name, resource_name, resource_id, line_no_input):
        if schema_type.get('$ref'):
            get_array_obj_array_data = get_router(schema_type.get('$ref'), rule)
            if get_array_obj_array_data.get('properties'):
                array_obj_array_keys = list(get_array_obj_array_data.get('properties').keys())
                array_obj_array_schema = get_array_obj_array_data.get('properties')
                for array_obj_array_len in range(len(input_js)):
                    if isinstance(input_js[array_obj_array_len], dict):
                        if get_array_obj_array_data.get("required"):
                            for definitions_required in get_array_obj_array_data.get("required"):

                                if input_js[array_obj_array_len].get(definitions_required) is None:
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/[" + str(
                                                      array_obj_array_len) + "]/" + definitions_required,
                                                  "error": "Object required field is not available.",
                                                  "error_line_no": "N/A",
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                        for array_obj_array_key in array_obj_array_keys:
                            if isinstance(input_js[array_obj_array_len], dict):
                                array_obj_array_inputs = input_js[array_obj_array_len].get(array_obj_array_key)
                                if array_obj_array_inputs is not None:
                                    schema_values_obj_array = array_obj_array_schema.get(array_obj_array_key)

                                    if schema_values_obj_array.get('enum'):
                                        if array_obj_array_inputs not in schema_values_obj_array.get('enum'):
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                    array_obj_array_len][array_obj_array_key]).line
                                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/[" + str(
                                                              array_obj_array_len) + "]/" + array_obj_array_key,
                                                          "error": "Object incorrect value",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)
                                    # type check
                                    if schema_values_obj_array.get('type'):
                                        if type(array_obj_array_inputs).__name__.lower().replace(
                                                'str', 'string').replace('list', 'array').replace('bool',
                                                                                                  'boolean').replace(
                                            "int",
                                            "number").replace(
                                            "dict", "object").replace("float", "number") == schema_values_obj_array.get(
                                            'type'):

                                            if schema_values_obj_array.get("items"):
                                                if schema_values_obj_array.get("items").get('enum'):
                                                    if not array_choice_validation(array_obj_array_inputs,
                                                                                   schema_values_obj_array.get(
                                                                                       "items").get(
                                                                                       'enum')):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][obj_property_key][
                                                                obj_obj_key][
                                                                array_obj_array_len][array_obj_array_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/[" + str(
                                                                          array_obj_array_len) + "]/" + array_obj_array_key,
                                                                      "error": "Object Incorrect value",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                                if schema_values_obj_array.get("items").get('type'):
                                                    if type(array_obj_array_inputs).__name__.lower().replace(
                                                            'str', 'string').replace('list', 'array').replace('bool',
                                                                                                              'boolean').replace(
                                                        "int",
                                                        "number").replace(
                                                        "dict", "object").replace("float",
                                                                                  "number") == schema_values_obj_array.get(
                                                        "items").get('type'):

                                                        if schema_values_obj_array.get("items").get('pattern'):
                                                            if not re.match(
                                                                    str(schema_values_obj_array.get("items").get(
                                                                        'pattern')),
                                                                    str(array_obj_array_inputs)):
                                                                line_no = jsoncfg.node_location(
                                                                    line_no_input[definitions_key][obj_property_key][
                                                                        obj_obj_key][
                                                                        array_obj_array_len][array_obj_array_key]).line
                                                                error_json = {"file_name": bundle_name,
                                                                              "resource_name": resource_name,
                                                                              "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/[" + str(
                                                                                  array_obj_array_len) + "]/" + array_obj_array_key,
                                                                              "error": "Object pattern is not match.",
                                                                              "error_line_no": line_no,
                                                                              "resource_id": resource_id
                                                                              }
                                                                error_list.append(error_json)
                                                    else:

                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][obj_property_key][
                                                                obj_obj_key][
                                                                array_obj_array_len][array_obj_array_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/[" + str(
                                                                          array_obj_array_len) + "]/" + array_obj_array_key,
                                                                      "error": "Object datatype is not valid.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                                elif schema_values_obj_array.get("items").get('$ref'):
                                                    pass

                                            if schema_values_obj_array.get('pattern'):
                                                if not re.match(str(schema_values_obj_array.get('pattern')),
                                                                str(array_obj_array_inputs)):
                                                    line_no = jsoncfg.node_location(
                                                        line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                            array_obj_array_len][array_obj_array_key]).line
                                                    error_json = {"file_name": bundle_name,
                                                                  "resource_name": resource_name,
                                                                  "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/[" + str(
                                                                      array_obj_array_len) + "]/" + array_obj_array_key,
                                                                  "error": "Object pattern is not match.",
                                                                  "error_line_no": line_no,
                                                                  "resource_id": resource_id
                                                                  }
                                                    error_list.append(error_json)
                                        else:

                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                    array_obj_array_len][array_obj_array_key]).line
                                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/[" + str(
                                                              array_obj_array_len) + "]/" + array_obj_array_key,
                                                          "error": "Object datatype is not valid.",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)

                                    if schema_values_obj_array.get('$ref'):
                                        # array of data type
                                        array_ref = get_router(schema_values_obj_array.get('$ref'), rule)
                                        if array_ref.get("type"):
                                            if type(array_obj_array_inputs).__name__.lower().replace(
                                                    'str', 'string').replace('list', 'array').replace('bool',
                                                                                                      'boolean').replace(
                                                "int",
                                                "number").replace(
                                                "dict", "object").replace("float", "number") == array_ref.get("type"):
                                                if array_ref.get("pattern"):
                                                    if not re.match(str(array_ref.get("pattern")),
                                                                    str(array_obj_array_inputs)):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][obj_property_key][
                                                                obj_obj_key][
                                                                array_obj_array_len][array_obj_array_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/[" + str(
                                                                          array_obj_array_len) + "]/" + array_obj_array_key,
                                                                      "error": "Object pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:

                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                        array_obj_array_len][array_obj_array_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/[" + str(
                                                                  array_obj_array_len) + "]/" + array_obj_array_key,
                                                              "error": "Object datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)

                                        elif schema_values_obj_array.get('$ref'):
                                            input_json = array_obj_array_inputs

    def obj_obj_obj_array_validation(schema_type, rule, input_js, definitions_key, obj_property_key, obj_obj_key,
                                     obj_key,
                                     bundle_name,
                                     resource_name, resource_id, line_no_input):
        if schema_type.get('$ref'):
            get_array_obj_array_data = get_router(schema_type.get('$ref'), rule)
            if get_array_obj_array_data.get('properties'):
                array_obj_array_keys = list(get_array_obj_array_data.get('properties').keys())
                array_obj_array_schema = get_array_obj_array_data.get('properties')
                for array_obj_array_len in range(len(input_js)):
                    if isinstance(input_js[array_obj_array_len], dict):
                        if get_array_obj_array_data.get("required"):
                            for definitions_required in get_array_obj_array_data.get("required"):
                                if input_js[array_obj_array_len].get(definitions_required) is None:
                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                  "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_key + "/[" + str(
                                                      array_obj_array_len) + "]/" + definitions_required,
                                                  "error": "Object required field is not available.",
                                                  "error_line_no": "N/A",
                                                  "resource_id": resource_id
                                                  }
                                    error_list.append(error_json)
                        for array_obj_array_key in array_obj_array_keys:
                            if isinstance(input_js[array_obj_array_len], dict):
                                array_obj_array_inputs = input_js[array_obj_array_len].get(array_obj_array_key)
                                if array_obj_array_inputs is not None:
                                    schema_values_obj_array = array_obj_array_schema.get(array_obj_array_key)

                                    if schema_values_obj_array.get('enum'):
                                        if array_obj_array_inputs not in schema_values_obj_array.get('enum'):
                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][obj_property_key][obj_obj_key][obj_key][
                                                    array_obj_array_len][array_obj_array_key]).line
                                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_key + "/[" + str(
                                                              array_obj_array_len) + "]/" + array_obj_array_key,
                                                          "error": "Object incorrect value",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)
                                    # type check
                                    if schema_values_obj_array.get('type'):
                                        if type(array_obj_array_inputs).__name__.lower().replace(
                                                'str', 'string').replace('list', 'array').replace('bool',
                                                                                                  'boolean').replace(
                                            "int",
                                            "number").replace(
                                            "dict", "object").replace("float", "number") == schema_values_obj_array.get(
                                            'type'):

                                            if schema_values_obj_array.get("items"):
                                                if schema_values_obj_array.get("items").get('enum'):
                                                    if not array_choice_validation(array_obj_array_inputs,
                                                                                   schema_values_obj_array.get("items").get(
                                                                                       'enum')):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                                obj_key][
                                                                array_obj_array_len][array_obj_array_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_key + "/[" + str(
                                                                          array_obj_array_len) + "]/" + array_obj_array_key,
                                                                      "error": "Object Incorrect value",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                                if schema_values_obj_array.get("items").get('type'):
                                                    if type(array_obj_array_inputs).__name__.lower().replace(
                                                            'str', 'string').replace('list', 'array').replace('bool',
                                                                                                              'boolean').replace(
                                                        "int",
                                                        "number").replace(
                                                        "dict", "object").replace("float",
                                                                                  "number") == schema_values_obj_array.get(
                                                        "items").get('type'):

                                                        if schema_values_obj_array.get("items").get('pattern'):
                                                            if not re.match(
                                                                    str(schema_values_obj_array.get("items").get(
                                                                        'pattern')),
                                                                    str(array_obj_array_inputs)):
                                                                line_no = jsoncfg.node_location(
                                                                    line_no_input[definitions_key][obj_property_key][
                                                                        obj_obj_key][obj_key][
                                                                        array_obj_array_len][array_obj_array_key]).line
                                                                error_json = {"file_name": bundle_name,
                                                                              "resource_name": resource_name,
                                                                              "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_key + "/[" + str(
                                                                                  array_obj_array_len) + "]/" + array_obj_array_key,
                                                                              "error": "Object pattern is not match.",
                                                                              "error_line_no": line_no,
                                                                              "resource_id": resource_id
                                                                              }
                                                                error_list.append(error_json)
                                                    else:

                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                                obj_key][
                                                                array_obj_array_len][array_obj_array_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_key + "/[" + str(
                                                                          array_obj_array_len) + "]/" + array_obj_array_key,
                                                                      "error": "Object datatype is not valid.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                                elif schema_values_obj_array.get("items").get('$ref'):
                                                    pass

                                            if schema_values_obj_array.get('pattern'):
                                                if not re.match(str(schema_values_obj_array.get('pattern')),
                                                                str(array_obj_array_inputs)):
                                                    line_no = jsoncfg.node_location(
                                                        line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                            obj_key][
                                                            array_obj_array_len][array_obj_array_key]).line
                                                    error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                                  "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_key + "/[" + str(
                                                                      array_obj_array_len) + "]/" + array_obj_array_key,
                                                                  "error": "Object pattern is not match.",
                                                                  "error_line_no": line_no,
                                                                  "resource_id": resource_id
                                                                  }
                                                    error_list.append(error_json)
                                        else:

                                            line_no = jsoncfg.node_location(
                                                line_no_input[definitions_key][obj_property_key][obj_obj_key][obj_key][
                                                    array_obj_array_len][array_obj_array_key]).line
                                            error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                          "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_key + "/[" + str(
                                                              array_obj_array_len) + "]/" + array_obj_array_key,
                                                          "error": "Object datatype is not valid.",
                                                          "error_line_no": line_no,
                                                          "resource_id": resource_id
                                                          }
                                            error_list.append(error_json)

                                    if schema_values_obj_array.get('$ref'):
                                        # array of data type
                                        array_ref = get_router(schema_values_obj_array.get('$ref'), rule)
                                        if array_ref.get("type"):
                                            if type(array_obj_array_inputs).__name__.lower().replace(
                                                    'str', 'string').replace('list', 'array').replace('bool',
                                                                                                      'boolean').replace(
                                                "int",
                                                "number").replace(
                                                "dict", "object").replace("float", "number") == array_ref.get("type"):
                                                if array_ref.get("pattern"):
                                                    if not re.match(str(array_ref.get("pattern")),
                                                                    str(array_obj_array_inputs)):
                                                        line_no = jsoncfg.node_location(
                                                            line_no_input[definitions_key][obj_property_key][obj_obj_key][
                                                                obj_key][
                                                                array_obj_array_len][array_obj_array_key]).line
                                                        error_json = {"file_name": bundle_name,
                                                                      "resource_name": resource_name,
                                                                      "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_key + "/[" + str(
                                                                          array_obj_array_len) + "]/" + array_obj_array_key,
                                                                      "error": "Object pattern is not match.",
                                                                      "error_line_no": line_no,
                                                                      "resource_id": resource_id
                                                                      }
                                                        error_list.append(error_json)
                                            else:

                                                line_no = jsoncfg.node_location(
                                                    line_no_input[definitions_key][obj_property_key][obj_obj_key][obj_key][
                                                        array_obj_array_len][array_obj_array_key]).line
                                                error_json = {"file_name": bundle_name, "resource_name": resource_name,
                                                              "path": "root" + "/" + definitions_key + "/" + obj_property_key + "/" + obj_obj_key + "/" + obj_key + "/[" + str(
                                                                  array_obj_array_len) + "]/" + array_obj_array_key,
                                                              "error": "Object datatype is not valid.",
                                                              "error_line_no": line_no,
                                                              "resource_id": resource_id
                                                              }
                                                error_list.append(error_json)

                                        elif schema_values_obj_array.get('$ref'):
                                            input_json = array_obj_array_inputs

    def start_resource_based_validate(bundle_name, resource_name, input_json, resource_id, line_no_input):

        # file_name = r"Deployments/fhirunbundle/fhir_schema.json"
        # file = open('fhir_schema.json', encoding="utf8")
        data = _get_fhir_schema_blob_data(error_analytics_container_client, 'FHIR_Schema\\fhir_schema.json')
        rule = json.loads(data)
        # rule = json.load(file)

        json_mapping = rule.get("discriminator").get("mapping")
        mapping_check = json_mapping.get(resource_name)
        if mapping_check:
            json_oneOf = rule.get("oneOf")
            for oneOf in json_oneOf:
                oneOf_value = oneOf.get("$ref")
                if str(oneOf_value) == str(mapping_check):
                    list_split = oneOf_value.split("/")
                    definitions = rule.get(list_split[1]).get(list_split[2])

                    # validation level function
                    if input_json.get("resource"):
                        datatype_validation(definitions, input_json.get("resource"), rule, bundle_name, resource_name,
                                            resource_id,
                                            line_no_input)
                    if input_json.get("resourceType") == "Bundle":
                        datatype_validation(definitions, input_json, rule, bundle_name, resource_name,
                                            resource_id,
                                            line_no_input)

    def check_duplicates_id(input_json):
        id_array = []
        for inputdata in input_json:
            id_array.append(inputdata.get("resource").get("id"))
        id_check = set([x for x in id_array if id_array.count(x) > 1])
        return len(id_check)

    def start_validation_report(json_file, file_name):
        try:
            total_json_files = []
            Filename = file_name
            loaded_data = json_file
            dumps_json = json.dumps(json_file)
            bundle_no_entry_key = json.loads(dumps_json)
            del bundle_no_entry_key["entry"]
            bundle_and_resource = []
            bundle_and_resource.append(bundle_no_entry_key)
            for full_json in loaded_data.get('entry'):
                bundle_and_resource.append(full_json)
            for input_json in bundle_and_resource:

                if input_json.get("resource"):
                    # line number function
                    dumped_inputjson = json.dumps(input_json.get("resource"), indent=4)
                    line_no_input = jsoncfg.loads_config((dumped_inputjson))

                    if input_json.get("resource").get("resourceType"):
                        if input_json.get("resource").get("id"):
                            if check_duplicates_id(loaded_data.get('entry')) == 0:
                                resource_name = input_json.get("resource").get("resourceType")
                                resource_id = input_json.get("resource").get("id")
                                start_resource_based_validate(Filename, resource_name, input_json, resource_id,
                                                              line_no_input)

                                total_resource_with_file = {
                                    "file_name": file_name,
                                    "resources": resource_name
                                }
                                total_json_files.append(total_resource_with_file)

            print(json.dumps(error_list, indent=4))
            logging.error(error_list)


        except Exception as e:
            logging.error(e)


    start_validation_report(json_file, file_name)
    logging.error("error list before")
    return error_list
