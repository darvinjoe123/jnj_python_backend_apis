import logging
import os
import json
import traceback
import ast
from azure.storage.blob import BlobServiceClient
from ._save_db import  get_date
from .constants import constants_obj
from .Adl_Helper import Adl_Helper_Obj
from .Helper import Helper_obj
from .Db_Helper import db_helper_obj
from .dsp_constants import *
def _get_fhir_schema_blob_data(container_client, blob_name):
    blob_client = container_client.get_blob_client(blob=blob_name)
    fhir_schema = blob_client.download_blob().readall()
    return fhir_schema


def fhir_practitioner_unbundle(resource, resource_type, id, transaction_id, oid, dsep, file_format
                               , practitioner_id, national_provider_id,practitioner_bool, is_single_resource, vendor_name, full_url = None, client_data = None, docspera_id= None):
    seperator = "_"
    dsep_path = client_data[f'{vendor_name}_DSP_PATH']
    
    if practitioner_bool:
        enriched_data = constants_obj.enrich(resource, practitioner_id, is_single_resource, oid, client_data, vendor_name)
        enriched_data_swap = Helper_obj.replace_dsep_practitioner_client_id(enriched_data, id, practitioner_id, vendor_name, client_data)
        values = (oid, id, docspera_id, practitioner_id, national_provider_id, resource_type, json.dumps(enriched_data_swap, indent=2), transaction_id,vendor_name, get_date(),get_date())
        db_helper_obj.insert_other_data(insert_d4cfhir_practitioner_query, values, True)
        Adl_Helper_Obj.adl_upload_blob(client_data[f'{vendor_name}_CLIENT_CONNECTION_STRING'], client_data[f'{vendor_name}_DSP_CONTAINER_CLIENT'], "/".join((dsep_path + oid, resource_type, f'{resource_type}{seperator}{national_provider_id}{file_format}')),json.dumps(enriched_data_swap, indent=2))
        Adl_Helper_Obj.adl_upload_blob(client_data[f'{vendor_name}_CLIENT_CONNECTION_STRING'], client_data[f'{vendor_name}_DSP_CONTAINER_CLIENT'],"/".join((dsep_path + oid, resource_type, "dsep", f'{resource_type}{seperator}{practitioner_id}{file_format}')),json.dumps(enriched_data_swap, indent=2))
    else:
        if ast.literal_eval(client_data[f"{vendor_name}_ENRICH_UPDATE"]):
            resource = constants_obj.enrich(resource, practitioner_id, is_single_resource, oid, client_data, vendor_name)
        enrich_data_update = Helper_obj.replace_dsep_practitioner_client_id(resource, id, practitioner_id, vendor_name, client_data)
        values = (oid, id, docspera_id, practitioner_id, national_provider_id, resource_type, json.dumps(enrich_data_update, indent=2), transaction_id,vendor_name, get_date(),get_date())
        db_helper_obj.insert_other_data(insert_d4cfhir_practitioner_query, values , True)
        Adl_Helper_Obj.adl_upload_blob(client_data[f'{vendor_name}_CLIENT_CONNECTION_STRING'], client_data[f'{vendor_name}_DSP_CONTAINER_CLIENT'],"/".join((dsep_path + oid, resource_type, f'{resource_type}{seperator}{national_provider_id}{file_format}')),json.dumps(enrich_data_update, indent=2))
        Adl_Helper_Obj.adl_upload_blob(client_data[f'{vendor_name}_CLIENT_CONNECTION_STRING'], client_data[f'{vendor_name}_DSP_CONTAINER_CLIENT'],"/".join((dsep_path + oid, resource_type, "dsep", f'{resource_type}{seperator}{practitioner_id}{file_format}')),json.dumps(enrich_data_update, indent=2))

def _create_blob_client(storage_account_name, connection_string):
    account_url = f'https://{storage_account_name}.blob.core.windows.net/'
    blob_service_client = BlobServiceClient.from_connection_string(connection_string)
    return blob_service_client

def unbundle_to_folder(resource, resource_type, id, transaction_id, oid, dsep, file_format, practitioner_id, national_provider_id,
                       practitioner_bool, is_single_resource, patient_bool, db_connection, docspera_id, vendor_name, full_url = None, client_data = None):
    
    get_resource_dsp_id = Helper_obj.get_new_patient_id(client_data['DSEP_PATIENT_ID_GENERATOR_URL'])
    seperator = "_"
    dsep_path = client_data[f'{vendor_name}_DSP_PATH']
    master_folder = client_data['COMMON_DSP_MASTER_PATH']
    patient_mrn = ""
    dsp_resource_id =  ""
    resource_types_list = client_data['ALL_RESOURCE_TYPES'].lower().split(",")
    if id and resource_type in resource_types_list:
        if resource_type == "practitioner":
            if oid == client_data['REDOX_OID']:
                try:practitioner_id = json.loads(practitioner_id) 
                except:pass
                
                logging.info("******************************  practitioner_id  ******************************")
                logging.info(practitioner_id)
                logging.info("******************************  practitioner_id  ******************************")

                practitioner_id_fhir = practitioner_id[full_url]
                fhir_practitioner_unbundle(resource, resource_type, id, transaction_id, oid, dsep, file_format, practitioner_id_fhir, national_provider_id,
                       practitioner_bool, is_single_resource, vendor_name, full_url, client_data)
            else:
                fhir_practitioner_unbundle(resource, resource_type, id, transaction_id, oid, dsep, file_format, practitioner_id, national_provider_id,
                       practitioner_bool, is_single_resource, vendor_name, full_url, client_data, docspera_id)
        elif resource_type == "patient":
            patient_mrn , patient_oid = Helper_obj.get_mrn_oid(resource)
            full_url = Helper_obj.get_full_url(resource)
            if patient_bool:
                enriched_data_patient = constants_obj.enrich_patient(resource, dsep, is_single_resource, oid, client_data, vendor_name) 
                enrich_data_add = Helper_obj.replace_dsep_client_id(enriched_data_patient, id, dsep, vendor_name, client_data)
                values =(oid, patient_oid, dsep, id, docspera_id, patient_mrn, resource_type, json.dumps(enrich_data_add, indent=2), transaction_id,  vendor_name, get_date(),get_date(), full_url)
                db_helper_obj.insert_other_data(insert_d4cfhir_patient_query, values, True)
                Adl_Helper_Obj.adl_upload_blob(client_data[f'{vendor_name}_CLIENT_CONNECTION_STRING'], client_data[f'{vendor_name}_DSP_CONTAINER_CLIENT'], "/".join((dsep_path + oid, dsep, resource_type, f'{resource_type}{seperator}{dsep}{seperator}{patient_mrn}{seperator}{patient_oid}{file_format}')),json.dumps(enrich_data_add, indent=2))
            else:
                if client_data[f"{vendor_name}_ENRICH_UPDATE"]:
                    resource =constants_obj.enrich_patient(resource, dsep, is_single_resource, oid, client_data, vendor_name) 
                enrich_data_update = Helper_obj.replace_dsep_client_id(resource, id, dsep, vendor_name, client_data)
                values = (oid, patient_oid, dsep, id, docspera_id, patient_mrn, resource_type, json.dumps(enrich_data_update, indent=2), transaction_id,  vendor_name, get_date(),get_date(), full_url)
                db_helper_obj.insert_other_data(insert_d4cfhir_patient_query, values, True)
                Adl_Helper_Obj.adl_upload_blob(client_data[f'{vendor_name}_CLIENT_CONNECTION_STRING'], client_data[f'{vendor_name}_DSP_CONTAINER_CLIENT'], "/".join((dsep_path + oid, dsep, resource_type, f'{resource_type}{seperator}{dsep}{seperator}{patient_mrn}{seperator}{patient_oid}{file_format}')),json.dumps(enrich_data_update, indent=2))

        elif resource_type in client_data['COMMON_MASTER_FHIR_RESOURCES']:
            enriched_dsp , dsp_resource_id = constants_obj.add_resource_id(resource, oid, resource_type, id, get_resource_dsp_id, vendor_name, client_data, full_url, None, True)
            insert_d4cfhir_org_query_ = insert_d4cfhir_org_query.format(resource_type)
            values = (id, oid,  resource_type, json.dumps(enriched_dsp, indent=2), transaction_id, dsp_resource_id, vendor_name, get_date(), get_date(),full_url)
            db_helper_obj.insert_other_data(insert_d4cfhir_org_query_, values , True)
            Adl_Helper_Obj.adl_upload_blob(client_data[f'{vendor_name}_CLIENT_CONNECTION_STRING'], client_data[f'{vendor_name}_DSP_CONTAINER_CLIENT'],"/".join((dsep_path + master_folder, resource_type, f'{resource_type}{seperator}{id}{file_format}')),json.dumps(resource, indent=2))

        else:
            enriched_dsp, dsp_resource_id = constants_obj.add_resource_id(resource, oid,  resource_type, id, get_resource_dsp_id, vendor_name, client_data, full_url, dsep, False)
            if dsp_resource_id:
                insert_d4cfhir_other_resource_query_ = insert_d4cfhir_other_resource_query.format(resource_type)
                values = (oid, "", id, dsep, resource_type,  json.dumps(enriched_dsp, indent =2), transaction_id, dsp_resource_id, vendor_name,get_date(),get_date(), full_url)
                db_helper_obj.insert_other_data(insert_d4cfhir_other_resource_query_, values, True)
                Adl_Helper_Obj.adl_upload_blob(client_data[f'{vendor_name}_CLIENT_CONNECTION_STRING'], client_data[f'{vendor_name}_DSP_CONTAINER_CLIENT'],"/".join((dsep_path + oid, dsep, resource_type, f'{resource_type}{seperator}{id}{file_format}')),json.dumps(enriched_dsp, indent=2))
            else:
                Adl_Helper_Obj.adl_upload_blob(client_data[f'{vendor_name}_CLIENT_CONNECTION_STRING'], client_data[f'{vendor_name}_ERROR_CONTAINER_CLIENT'],f'{transaction_id}{file_format}',json.dumps(resource, indent=2))
                values = (resource, transaction_id, "error", 'Error during unbundling, dsp resource id mismatch')
                db_helper_obj.insert_data(insert_into_error_processing, values , True)
                Adl_Helper_Obj.adl_upload_error_blob(client_data[f'{vendor_name}_CLIENT_CONNECTION_STRING'], client_data[f'{vendor_name}_ERROR_CONTAINER_CLIENT'],f"{transaction_id}-ERR.txt",'Error during unbundling. Id is not present')
                
    else:
        if not id:
            Adl_Helper_Obj.adl_upload_blob(client_data[f'{vendor_name}_CLIENT_CONNECTION_STRING'], client_data[f'{vendor_name}_ERROR_CONTAINER_CLIENT'],f'{transaction_id}{file_format}',json.dumps(resource, indent=2))
            values = (json.dumps(resource), transaction_id, "error", 'Error during unbundling. Id is not present', get_date())
            db_helper_obj.insert_other_data(insert_dsp_error_query, values)
            Adl_Helper_Obj.adl_upload_error_blob(client_data[f'{vendor_name}_CLIENT_CONNECTION_STRING'], client_data[f'{vendor_name}_ERROR_CONTAINER_CLIENT'],f"{transaction_id}-ERR.txt",'Error during unbundling. Id is not present')
            logging.info('Error during unbundling. Id is not present')
        if resource_type not in resource_types_list:
            values = (json.dumps(resource), transaction_id, "error", f'Error during unbundling. Invalid Resource Type: {resource_type}', get_date())
            db_helper_obj.insert_other_data(insert_dsp_error_query, values)
            Adl_Helper_Obj.adl_upload_blob(client_data[f'{vendor_name}_CLIENT_CONNECTION_STRING'], client_data[f'{vendor_name}_ERROR_CONTAINER_CLIENT'],f'{transaction_id}{file_format}',json.dumps(resource, indent=2))
            Adl_Helper_Obj.adl_upload_error_blob(client_data[f'{vendor_name}_CLIENT_CONNECTION_STRING'], client_data[f'{vendor_name}_ERROR_CONTAINER_CLIENT'],f"{transaction_id}-ERR.txt",
                                'Error during unbundling. Id is not present')
            logging.info(f'Error during unbundling. Invalid Resource Type: {resource_type}')

async def unbundle_json(data, transaction_id, oid, dsep, practitioner_id,
                        national_provider_id, practitioner_bool, patient_bool, db_connection, docspera_id, vendor_name, client_data, unbundle_audit_json):
    is_single_resource = False
    data = json.loads(data)
    file_format = ".json"
    full_url =""
    unbundle_start_timestamp=unbundle_end_timestamp=error_unbundle_timestamp=unbundle_error_message=None
    try:
        try:
            resources = data["entry"]
        except:
            resources = data["body"]["entry"]
            
        for resource in resources:
            resource = json.loads(json.dumps(resource))
            try:
                resource_type = resource["resource"]["resourceType"].lower()
                if oid == os.environ["FHIR_OID"]:
                    client_resource_id, full_url = Helper_obj.get_vendor_resource_id(resource,db_connection, resource_type, client_data["DSEP_PATIENT_ID_GENERATOR_URL"])
                    resource['resource']["id"] = full_url
                    
                id = resource["resource"]["id"]
                unbundle_start_timestamp = get_date()
                unbundle_to_folder(resource, resource_type, id, transaction_id,
                                   oid, dsep, file_format, practitioner_id, national_provider_id, practitioner_bool,
                                   is_single_resource, patient_bool, db_connection, docspera_id, vendor_name, full_url, client_data)
                unbundle_end_timestamp = get_date()
            except Exception as e:
                values = (json.dumps(resource), transaction_id, f'Error during unbundling. Key is not present \n{traceback.format_exc()}', "error",  get_date())
                db_helper_obj.insert_other_data(insert_dsp_error_query, values)
                error_unbundle_timestamp = get_date()
                unbundle_error_message = f'Error during unbundling. Key is not present \n{traceback.format_exc()}'
                Adl_Helper_Obj.adl_upload_blob(client_data[f'{vendor_name}_CLIENT_CONNECTION_STRING'], client_data[f'{vendor_name}_ERROR_CONTAINER_CLIENT'],f'{transaction_id}{file_format}',json.dumps(resource, indent=2))
                Adl_Helper_Obj.adl_upload_blob(client_data[f'{vendor_name}_CLIENT_CONNECTION_STRING'], client_data[f'{vendor_name}_ERROR_CONTAINER_CLIENT'], f"{transaction_id}-ERR.txt",f'Error during unbundling. Key is not present \n{traceback.format_exc()}')
                logging.exception(f"Error Message: {e} ")
        try:
            unbundle_audit_json['unbundle_start_timestamp'] = unbundle_start_timestamp
            unbundle_audit_json['unbundle_end_timestamp'] = unbundle_end_timestamp
            unbundle_audit_json['unbundle_error_message'] = unbundle_error_message
            unbundle_audit_json['error_unbundle_timestamp'] = error_unbundle_timestamp
            values = (unbundle_start_timestamp, unbundle_end_timestamp, unbundle_error_message, error_unbundle_timestamp, json.dumps(unbundle_audit_json), transaction_id)
            db_helper_obj.insert_other_data(audit_insert_fhir_main,values)
        except Exception as e:
            logging.info(e)
    except KeyError:
        is_single_resource = True
        resource_type = data["resourceType"].lower()
        logging.exception("Error Message: ")
        try:
            full_url = ""
            id = data["id"]
            unbundle_start_timestamp = get_date()
            unbundle_to_folder(data, resource_type, id, transaction_id,oid, dsep, file_format, practitioner_id, national_provider_id, practitioner_bool,
                               is_single_resource, patient_bool, db_connection, docspera_id, vendor_name, full_url, client_data)
            unbundle_end_timestamp = get_date()
        except KeyError:
            values = (json.dumps(data), transaction_id, "error", f'Error during unbundling. Key is not present \n{traceback.format_exc()}', get_date())
            db_helper_obj.insert_other_data(insert_dsp_error_query, values)
            error_unbundle_timestamp = get_date()
            unbundle_error_message = "Error during unbundling. Key is not present"
            Adl_Helper_Obj.adl_upload_blob(client_data[f'{vendor_name}_CLIENT_CONNECTION_STRING'], client_data[f'{vendor_name}_ERROR_CONTAINER_CLIENT'],f'{transaction_id}{file_format}',json.dumps(resource, indent=2))
            Adl_Helper_Obj.adl_upload_blob(client_data[f'{vendor_name}_CLIENT_CONNECTION_STRING'], client_data[f'{vendor_name}_ERROR_CONTAINER_CLIENT'], f"{transaction_id}-ERR.txt",f'Error during unbundling. Key is not present \n{traceback.format_exc()}')
            logging.exception("Error Message: ")
        try:
            unbundle_audit_json['unbundle_start_timestamp'] = unbundle_start_timestamp
            unbundle_audit_json['unbundle_end_timestamp'] = unbundle_end_timestamp
            unbundle_audit_json['unbundle_error_message'] = unbundle_error_message
            unbundle_audit_json['error_unbundle_timestamp'] = error_unbundle_timestamp
            values = (unbundle_start_timestamp, unbundle_end_timestamp, unbundle_error_message, error_unbundle_timestamp,unbundle_audit_json, transaction_id)
            db_helper_obj.insert_other_data(audit_insert_fhir_main,values)
        except Exception as e:
            logging.info(e)
