from asyncio import constants
from http import client
import logging
from benedict import benedict
from .Db_Helper import db_helper_obj

ALL_RESOURCE_TYPES = 'AllergyIntolerance,Appointment,Account,Condition,Coverage,Device,DiagnosticReport,Encounter,Immunization,Medication,MedicationAdministration,MedicationRequest,MedicationStatement,Observation,Organization,Patient,Practitioner,RelatedPerson,PractitionerRole,Procedure,ServiceRequest,Specimen,Location'

class Constants:
    def __init__(self):
        logging.warn("this is constants")
        
    def enrich_patient(self, resource, patient_id, is_single_resource, oid, cc, vendor):
        logging.warn(f'Enrich resource: {resource}')
        logging.warn(f'patient_id: {patient_id}')
        new_dsep_identifier =  {
                    "type": {
                        "text": str(cc[f"ENRICH_{vendor}_PATIENT_ID"]),
                        "coding": [
                            {
                                "code": "DSEPPATID",
                                "system": "urn:oid:" + str(oid),
                                "display": str(cc[f"ENRICH_{vendor}_PATIENT_ID"])
                            }
                        ]
                    },
                    "value": str(patient_id)
                }
        logging.warn(f'Enriched data: {new_dsep_identifier}')
        if is_single_resource:
            resource['identifier'].insert(0, new_dsep_identifier)
        else:
            resource["resource"]['identifier'].insert(0, new_dsep_identifier)
        return resource

    def enrich(self, resource, practitioner_id, is_single_resource, oid, cc, vendor):
        logging.warn(f'Enrich resource: {resource}')
        logging.warn(f'practitioner_id: {practitioner_id}')
        new_dsep_identifier =  {
            "type": {
                "text": str(cc[f"{vendor}_PRACTITIONER_ID"]),
                "coding": [
                    {
                        "code": "DSEPPRACID",
                        "system": "urn:oid:" + str(oid),
                        "display": str(cc[f"{vendor}_PRACTITIONER_ID"])
                    }
                ]
            },
            "value": str(practitioner_id)
        }
        logging.warn(f'Enriched data: {new_dsep_identifier}')
        if is_single_resource:
            resource['identifier'].insert(0, new_dsep_identifier)
        else:
            resource["resource"]['identifier'].insert(0, new_dsep_identifier)
        return resource

    def add_resource_id(self, resource, oid ,resource_type, resource_id, new_dsp_resource_id, vendor_name, client_data, full_url, dsep, common_resource):
        cal_id = ""
        d = benedict(resource)
        if "identifier" not in resource["resource"]:
            resource["resource"]["identifier"] = []
        for i in client_data['ALL_RESOURCE_TYPES'].split(','):
            if resource_type.lower() == i.lower():
                resource_name = i 
        for j  in client_data[f"DSP_{vendor_name}_OTHER_RESOURCE_IDENTIFIER"].split(','):
            if resource_name in j.split('_'):
                dsp_resource_key = j
        resource_identifier_exists =  d.search(dsp_resource_key, in_keys=False, in_values=True, exact=True, case_sensitive=False)                 
        # resource_identifier_exists =  d.search(f"DSP_{resource_name}_ID", in_keys=False, in_values=True, exact=True, case_sensitive=False) 
        if resource_identifier_exists:
            dsp_id = resource_identifier_exists[0][0]["value"]
            dsp_exists = db_helper_obj.check_dsp_resource_id_exists(dsp_id, resource_type)
            if not dsp_exists:
                return resource, dsp_exists
        else:
            check_dsp_id = db_helper_obj.check_dsp_id_exist_db(resource_id, resource_type, dsep, common_resource)
            if check_dsp_id:
                dsp_id = check_dsp_id
                resource_identifier = {
                        "system": dsp_resource_key,
                        "value": f"{check_dsp_id}",
                        "assigner": {
                            "reference": "DSP"
                        }
                    }
                resource["resource"]['identifier'].append(resource_identifier)
            else:
                dsp_id = new_dsp_resource_id
                resource_identifier = {
                        "system": dsp_resource_key,
                        "value": f"{dsp_id}",
                        "assigner": {
                            "reference": "DSP"
                        }
                    }
                resource["resource"]['identifier'].append(resource_identifier)
        resource["resource"]["id"] = dsp_id  
        if oid == client_data['REDOX_OID']:resource_id = full_url
        client_identifier = {
                    "system": f"{vendor_name}_{resource_name}_ID",
                    "value": str(resource_id)
                } 
        if(f"{vendor_name}_{resource_name}_ID" not in str(resource["resource"]["identifier"])):
            resource["resource"]['identifier'].append(client_identifier)
        logging.warn(resource)
        return resource, dsp_id

constants_obj = Constants()