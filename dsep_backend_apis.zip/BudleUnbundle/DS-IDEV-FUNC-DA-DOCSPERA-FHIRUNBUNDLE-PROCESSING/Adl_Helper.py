import logging
from azure.storage.blob import BlobServiceClient, ContentSettings

class Adl_Helper:
    def __init__(self):
        logging.warn("this is adl helper")

    def adl_connect_conn_string(self, source_container_connection_string,source_container_name):
        try:
            blob_source_service_client = BlobServiceClient.from_connection_string(source_container_connection_string)
            source_container_client = blob_source_service_client.get_container_client(source_container_name)
            return source_container_client  
        except Exception as ex:
            logging.info(ex)
        
        
    def adl_list_blobs(self, source_container_connection_string_, source_conatiner_name, list_prefix):
        container_instance = self.adl_connect_conn_string(source_container_connection_string_, source_conatiner_name)
        return container_instance.list_blobs(name_starts_with=list_prefix)

    def adl_get_blobs(self, source_container_connection_string_, source_conatiner_name, blob_name):
        try:
            container_instance = self.adl_connect_conn_string(source_container_connection_string_, source_conatiner_name)
            return (container_instance.get_blob_client(blob=blob_name)).download_blob().readall()
        except Exception as e:
            logging.warn(e)

    def adl_delete_blob(self, source_container_connection_string_, source_conatiner_name, blob_name):
        container_instance = self.adl_connect_conn_string(source_container_connection_string_, source_conatiner_name)
        container_instance.delete_blob(blob_name)

    def adl_upload_blob(self, source_container_connection_string_, source_conatiner_name, blob_name, blob_data):
        container_instance = self.adl_connect_conn_string(source_container_connection_string_, source_conatiner_name)
        (container_instance.get_blob_client(blob=blob_name)).upload_blob(blob_data, content_settings=ContentSettings(content_type='application/json'), overwrite=True)

    def adl_upload_error_blob(self, source_container_connection_string_, source_conatiner_name, blob_name, blob_data):
        container_instance = self.adl_connect_conn_string(source_container_connection_string_, source_conatiner_name)
        (container_instance.get_blob_client(blob=blob_name)).upload_blob(blob_data, content_settings=ContentSettings(content_type=''), overwrite=True)


Adl_Helper_Obj = Adl_Helper()