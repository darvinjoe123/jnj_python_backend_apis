import logging
from textwrap import indent
from types import resolve_bases
from attr import resolve_types
import requests
from benedict import benedict
from .dsp_constants import *
from .Db_Helper import db_helper_obj
class Helper:
    def __init__(self):
        logging.warn("this is helper")
    
    def get_full_url(self, resource):
        try:
            d = benedict(resource)
            client_id = d.search("urn:uuid", in_keys=False, in_values=True,
                        exact=False, case_sensitive=False)
            full_url = client_id[0][0]['fullUrl'][9:]
            return full_url
        except:
            return ""

    def get_new_patient_id(self, url):
        try:
            patient_id_gen_url = url
            response = requests.get(patient_id_gen_url, timeout=30)
            response.raise_for_status()
            new_id = response.text
            return new_id
        except requests.exceptions.RequestException as exception:
            logging.error("There was an error when generating a new UUID using API endpoint: %s", patient_id_gen_url)
            raise SystemExit(exception)


    def get_mrn_and_oid(self, data, search_for):
        d = benedict(data)
        b = benedict(d, keypath_separator='/')
        id_list = []
        try:
            if search_for == 'mrn': 
                id_list = b.match('resource/identifier[*]/value')
                if len(id_list) > 1:
                    return id_list[1]
                return '<>'
            else:
                id_list = b.match('resource/identifier[*]/system')
                if id_list:
                    orn_oid = id_list[0]
                    return orn_oid[8:]
                return '<>'
        except KeyError:
            logging.exception("Error Message: No MRN or OID found")
        

    def replace_dsep_practitioner_client_id(self, patient_data, id, dsep, vendor_name, cc):
        patient_data["resource"]["id"] = dsep
        # docspera_identifier = {
        #             "system": f"{vendor_name}_Practitioner_ID",
        #             "value": str(id)
        #         }
        docspera_identifier = {
                    "system": cc[f"{vendor_name}_CLIENT_PRACTITIONER_ID"],
                    "value": str(id)
                }
        if "identifier" not in patient_data["resource"]:
            print("identifier not exist")
            patient_data["resource"]["identifier"] = []
        if(cc[f"{vendor_name}_CLIENT_PRACTITIONER_ID"] not in str(patient_data["resource"]["identifier"])):
            patient_data["resource"]['identifier'].append(docspera_identifier)
        return patient_data

    def replace_dsep_client_id(self, patient_data, id, dsep, vendor_name, cc):
        patient_data["resource"]["id"] = dsep
        docspera_identifier = {
                    "system": cc[f"{vendor_name}_CLIENT_PATIENT_ID"],
                    "value": str(id)
                }
        if "identifier" not in patient_data["resource"]:
            print("identifier not exist")
            patient_data["resource"]["identifier"] = []
        if(cc[f"{vendor_name}_CLIENT_PATIENT_ID"] not in str(patient_data["resource"]["identifier"])):
            patient_data["resource"]['identifier'].append(docspera_identifier)
        return patient_data
    

    def get_mrn_oid(self, data):
        try:
            d = benedict(data)
            mrn = ""
            urn_oid  = ""
            oid =  d.search("urn:oid", in_keys=False, in_values=True, exact=False, case_sensitive=False)
            if oid:
                mrn = oid[0][0]['value']
                urn_oid = oid[0][0]['system']
            return mrn, urn_oid[8:]
        except:
            return "", ""

    def get_vendor_resource_id(self, resource,db_connection, resource_type, dsep_patient_gen_url):
        try:
            d = benedict(resource)
            client_id = d.search("urn:uuid", in_keys=False, in_values=True,exact=False, case_sensitive=False)
            full_url = client_id[0][0]['fullUrl'][9:]
            query = get_vendor_resource_id_query.format(resource_type,str("'") + full_url + str("'"))
            result = db_helper_obj.fetch_all(query)
            for row in result:
                return row["lmi_resource_id"], full_url
            vendor_resource_id = self.get_new_patient_id(dsep_patient_gen_url)
            return vendor_resource_id, full_url
        except Exception as e:
            logging.info(e)
            return ""
    

Helper_obj = Helper()